#pragma once
#include "hkbComputeRotationFromAxisAngleModifier.h"

hkbComputeRotationFromAxisAngleModifier* hkbComputeRotationFromAxisAngleModifier::hkbComputeRotationFromAxisAngleModifierRead(MEM* src)
{
	hkbComputeRotationFromAxisAngleModifier* x = new hkbComputeRotationFromAxisAngleModifier;

	x->base = *hkbModifier::hkbModifierRead(src);
	mread(&x->rotationOut,sizeof(TYPE_QUATERNION),1,src);
	mread(&x->axis,16,1,src);
	mread(&x->angleDegrees,4,1,src);
	mseek(src,12,SEEK_CUR);
	mseek(src,96,SEEK_CUR);

	return x;
};
