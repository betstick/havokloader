#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkSetunsignedlonglonghkContainerHeapAllocatorhkMapOperationsunsignedlonglong
{
	public:
	unsigned long* elem;
	int numElems;

	static hkSetunsignedlonglonghkContainerHeapAllocatorhkMapOperationsunsignedlonglong* hkSetunsignedlonglonghkContainerHeapAllocatorhkMapOperationsunsignedlonglongRead(MEM* src);
};
