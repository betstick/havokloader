#pragma once
#include "hkbPoseStoringGeneratorOutputListener.h"

hkbPoseStoringGeneratorOutputListener* hkbPoseStoringGeneratorOutputListener::hkbPoseStoringGeneratorOutputListenerRead(MEM* src)
{
	hkbPoseStoringGeneratorOutputListener* x = new hkbPoseStoringGeneratorOutputListener;

	x->base = *hkbGeneratorOutputListener::hkbGeneratorOutputListenerRead(src);
	mread(&x->storedPoses,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->dirty,1,1,src);
	mseek(src,7,SEEK_CUR);
	mread(&x->nodeToIndexMap,8,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
