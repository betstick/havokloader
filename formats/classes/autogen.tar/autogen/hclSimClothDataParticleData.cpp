#pragma once
#include "hclSimClothDataParticleData.h"

hclSimClothDataParticleData* hclSimClothDataParticleData::hclSimClothDataParticleDataRead(MEM* src)
{
	hclSimClothDataParticleData* x = new hclSimClothDataParticleData;

	mread(&x->mass,4,1,src);
	mread(&x->invMass,4,1,src);
	mread(&x->radius,4,1,src);
	mread(&x->friction,4,1,src);

	return x;
};
