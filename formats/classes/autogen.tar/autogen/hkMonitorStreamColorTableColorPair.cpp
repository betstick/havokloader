#pragma once
#include "hkMonitorStreamColorTableColorPair.h"

hkMonitorStreamColorTableColorPair* hkMonitorStreamColorTableColorPair::hkMonitorStreamColorTableColorPairRead(MEM* src)
{
	hkMonitorStreamColorTableColorPair* x = new hkMonitorStreamColorTableColorPair;

	mread(&x->colorName,8,1,src);
	mread(&x->color,4,1,src);
	mseek(src,4,SEEK_CUR);

	return x;
};
