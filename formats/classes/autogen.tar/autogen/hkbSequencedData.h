#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbSequencedData
{
	public:
	hkReferencedObject base;

	static hkbSequencedData* hkbSequencedDataRead(MEM* src);
};
