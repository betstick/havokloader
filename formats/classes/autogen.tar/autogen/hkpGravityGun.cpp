#pragma once
#include "hkpGravityGun.h"

hkpGravityGun* hkpGravityGun::hkpGravityGunRead(MEM* src)
{
	hkpGravityGun* x = new hkpGravityGun;

	x->base = *hkpFirstPersonGun::hkpFirstPersonGunRead(src);
	mread(&x->grabbedBodies,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->maxNumObjectsPicked,4,1,src);
	mread(&x->maxMassOfObjectPicked,4,1,src);
	mread(&x->maxDistOfObjectPicked,4,1,src);
	mread(&x->impulseAppliedWhenObjectNotPicked,4,1,src);
	mread(&x->throwVelocity,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->capturedObjectPosition,16,1,src);
	mread(&x->capturedObjectsOffset,16,1,src);
	mseek(src,56,SEEK_CUR);

	return x;
};
