#pragma once
#include "hkGizmoAttribute.h"

hkGizmoAttribute* hkGizmoAttribute::hkGizmoAttributeRead(MEM* src)
{
	hkGizmoAttribute* x = new hkGizmoAttribute;

	mread(&x->visible,1,1,src);
	mseek(src,7,SEEK_CUR);
	mread(&x->label,sizeof(TYPE_CSTRING),1,src);
	mread(&x->type,1,1,src);
	mseek(src,7,SEEK_CUR);

	return x;
};
