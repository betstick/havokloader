#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbClientCharacterState
{
	public:
	hkReferencedObject base;
	unsigned long* deformableSkinIds;
	unsigned long* rigidSkinIds;
	short* externalEventIds;
	unsigned long* auxiliaryInfo;
	short* activeEventIds;
	short* activeVariableIds;
	unsigned long characterId;
	unsigned long instanceName;
	unsigned long templateName;
	unsigned long fullPathToProject;
	unsigned long localScriptsPath;
	unsigned long remoteScriptsPath;
	unsigned long behaviorData;
	unsigned long behaviorInternalState;
	unsigned long nodeIdToInternalStateMap;
	bool visible;
	float elapsedSimulationTime;
	unsigned long skeleton;
	qstransform worldFromModel;
	qstransform* poseModelSpace;
	qstransform* rigidAttachmentTransforms;

	static hkbClientCharacterState* hkbClientCharacterStateRead(MEM* src);
};
