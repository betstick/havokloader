#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpConvexTransformShapeBase.h"

class hkpConvexTransformShape
{
	public:
	hkpConvexTransformShapeBase base;
	qstransform transform;
	vec4 extraScale;

	static hkpConvexTransformShape* hkpConvexTransformShapeRead(MEM* src);
};
