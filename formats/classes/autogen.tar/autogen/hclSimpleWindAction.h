#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclAction.h"

class hclSimpleWindAction
{
	public:
	hclAction base;
	vec4 windDirection;
	float windMinSpeed;
	float windMaxSpeed;
	float windFrequency;
	float maximumDrag;
	vec4 airVelocity;
	float currentTime;

	static hclSimpleWindAction* hclSimpleWindActionRead(MEM* src);
};
