#pragma once
#include "hkpLinConstraintAtom.h"

hkpLinConstraintAtom* hkpLinConstraintAtom::hkpLinConstraintAtomRead(MEM* src)
{
	hkpLinConstraintAtom* x = new hkpLinConstraintAtom;

	x->base = *hkpConstraintAtom::hkpConstraintAtomRead(src);
	mread(&x->axisIndex,1,1,src);
	mread(&x->padding,1,1,src);
	mseek(src,12,SEEK_CUR);
	mseek(src,2,SEEK_CUR);

	return x;
};
