#pragma once
#include "hkpSerializedAgentNnEntry.h"

hkpSerializedAgentNnEntry* hkpSerializedAgentNnEntry::hkpSerializedAgentNnEntryRead(MEM* src)
{
	hkpSerializedAgentNnEntry* x = new hkpSerializedAgentNnEntry;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->bodyA,8,1,src);
	mread(&x->bodyB,8,1,src);
	mread(&x->bodyAId,8,1,src);
	mread(&x->bodyBId,8,1,src);
	mread(&x->useEntityIds,1,1,src);
	mread(&x->agentType,1,1,src);
	mseek(src,14,SEEK_CUR);
	mread(&x->atom,sizeof(hkpSimpleContactConstraintAtom),1,src);
	mread(&x->propertiesStream,1,1,src);
	mseek(src,15,SEEK_CUR);
	mread(&x->contactPoints,sizeof(hkContactPoint),1,src);
	mread(&x->cpIdMgr,1,1,src);
	mseek(src,15,SEEK_CUR);
	mread(&x->nnEntryData,1,1,src);
	mseek(src,191,SEEK_CUR);
	mread(&x->trackInfo,sizeof(hkpSerializedTrack1nInfo),1,src);
	mread(&x->endianCheckBuffer,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->version,4,1,src);
	mseek(src,8,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
