#pragma once
#include "hkcdDynamicTreeTreehkcdDynamicTreeDynamicStorageInt16.h"

hkcdDynamicTreeTreehkcdDynamicTreeDynamicStorageInt16* hkcdDynamicTreeTreehkcdDynamicTreeDynamicStorageInt16::hkcdDynamicTreeTreehkcdDynamicTreeDynamicStorageInt16Read(MEM* src)
{
	hkcdDynamicTreeTreehkcdDynamicTreeDynamicStorageInt16* x = new hkcdDynamicTreeTreehkcdDynamicTreeDynamicStorageInt16;

	x->base = *hkcdDynamicTreeDynamicStorageInt16::hkcdDynamicTreeDynamicStorageInt16Read(src);
	mread(&x->numLeaves,4,1,src);
	mread(&x->path,4,1,src);
	mread(&x->root,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,24,SEEK_CUR);

	return x;
};
