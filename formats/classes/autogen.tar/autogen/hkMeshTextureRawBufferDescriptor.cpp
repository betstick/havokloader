#pragma once
#include "hkMeshTextureRawBufferDescriptor.h"

hkMeshTextureRawBufferDescriptor* hkMeshTextureRawBufferDescriptor::hkMeshTextureRawBufferDescriptorRead(MEM* src)
{
	hkMeshTextureRawBufferDescriptor* x = new hkMeshTextureRawBufferDescriptor;

	mread(&x->offset,8,1,src);
	mread(&x->stride,4,1,src);
	mread(&x->numElements,4,1,src);

	return x;
};
