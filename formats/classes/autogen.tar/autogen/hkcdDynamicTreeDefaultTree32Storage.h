#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkcdDynamicTreeTreehkcdDynamicTreeDynamicStorage16.h"

class hkcdDynamicTreeDefaultTree32Storage
{
	public:
	hkcdDynamicTreeTreehkcdDynamicTreeDynamicStorage16 base;

	static hkcdDynamicTreeDefaultTree32Storage* hkcdDynamicTreeDefaultTree32StorageRead(MEM* src);
};
