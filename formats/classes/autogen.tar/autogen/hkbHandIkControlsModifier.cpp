#pragma once
#include "hkbHandIkControlsModifier.h"

hkbHandIkControlsModifier* hkbHandIkControlsModifier::hkbHandIkControlsModifierRead(MEM* src)
{
	hkbHandIkControlsModifier* x = new hkbHandIkControlsModifier;

	x->base = *hkbModifier::hkbModifierRead(src);
	mread(&x->hands,sizeof(hkbHandIkControlsModifierHand),1,src);
	mseek(src,88,SEEK_CUR);

	return x;
};
