#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclObjectSpaceSkinOperator.h"

class hclObjectSpaceSkinPOperator
{
	public:
	hclObjectSpaceSkinOperator base;
	hclObjectSpaceDeformerLocalBlockP* localPs;
	hclObjectSpaceDeformerLocalBlockUnpackedP* localUnpackedPs;

	static hclObjectSpaceSkinPOperator* hclObjectSpaceSkinPOperatorRead(MEM* src);
};
