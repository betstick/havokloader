#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbBehaviorGraphInternalStateInfo
{
	public:
	hkReferencedObject base;
	unsigned long characterId;
	unsigned long internalState;
	unsigned long* auxiliaryNodeInfo;
	short* activeEventIds;
	short* activeVariableIds;

	static hkbBehaviorGraphInternalStateInfo* hkbBehaviorGraphInternalStateInfoRead(MEM* src);
};
