#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"
enum Event
{
	REMOVED_FROM_WORLD = 0,
	SHOWN = 1,
	HIDDEN = 2,
	ACTIVATED = 3,
	DEACTIVATED = 4,
};

class hkbCharacterInfo
{
	public:
	hkReferencedObject base;
	unsigned long characterId;
	unsigned char event;
	int padding;

	static hkbCharacterInfo* hkbCharacterInfoRead(MEM* src);
};
