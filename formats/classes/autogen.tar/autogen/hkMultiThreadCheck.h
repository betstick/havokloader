#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
enum AccessType
{
	HK_ACCESS_IGNORE = 0,
	HK_ACCESS_RO = 1,
	HK_ACCESS_RW = 2,
};
enum ReadMode
{
	THIS_OBJECT_ONLY = 0,
	RECURSIVE = 1,
};

class hkMultiThreadCheck
{
	public:
	unsigned int threadId;
	int stackTraceId;
	unsigned short markCount;
	unsigned short markBitStack;

	static hkMultiThreadCheck* hkMultiThreadCheckRead(MEM* src);
};
