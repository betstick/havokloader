#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hclBendLinkConstraintSetMxBatch
{
	public:
	float bendMinLengths;
	float stretchMaxLengths;
	float stretchStiffnesses;
	float bendStiffnesses;
	float invMassesA;
	float invMassesB;
	unsigned short particlesA;
	unsigned short particlesB;

	static hclBendLinkConstraintSetMxBatch* hclBendLinkConstraintSetMxBatchRead(MEM* src);
};
