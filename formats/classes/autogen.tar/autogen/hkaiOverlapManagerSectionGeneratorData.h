#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkaiOverlapManagerSectionGeneratorData
{
	public:
	hkReferencedObject base;
	hkaiSilhouetteGeneratorSectionContext context;
	int* overlappedFaces;

	static hkaiOverlapManagerSectionGeneratorData* hkaiOverlapManagerSectionGeneratorDataRead(MEM* src);
};
