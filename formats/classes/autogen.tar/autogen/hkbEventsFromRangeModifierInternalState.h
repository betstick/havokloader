#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbEventsFromRangeModifierInternalState
{
	public:
	hkReferencedObject base;
	bool* wasActiveInPreviousFrame;

	static hkbEventsFromRangeModifierInternalState* hkbEventsFromRangeModifierInternalStateRead(MEM* src);
};
