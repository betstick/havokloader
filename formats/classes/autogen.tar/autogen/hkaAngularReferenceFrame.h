#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkaParameterizedReferenceFrame.h"

class hkaAngularReferenceFrame
{
	public:
	hkaParameterizedReferenceFrame base;
	float topAngle;
	float radius;

	static hkaAngularReferenceFrame* hkaAngularReferenceFrameRead(MEM* src);
};
