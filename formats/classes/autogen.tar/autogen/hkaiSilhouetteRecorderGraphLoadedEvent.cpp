#pragma once
#include "hkaiSilhouetteRecorderGraphLoadedEvent.h"

hkaiSilhouetteRecorderGraphLoadedEvent* hkaiSilhouetteRecorderGraphLoadedEvent::hkaiSilhouetteRecorderGraphLoadedEventRead(MEM* src)
{
	hkaiSilhouetteRecorderGraphLoadedEvent* x = new hkaiSilhouetteRecorderGraphLoadedEvent;

	x->base = *hkaiSilhouetteRecorderReplayEvent::hkaiSilhouetteRecorderReplayEventRead(src);
	mread(&x->graph,8,1,src);
	mseek(src,24,SEEK_CUR);

	return x;
};
