#pragma once
#include "hclObjectSpaceDeformerLocalBlockPNTB.h"

hclObjectSpaceDeformerLocalBlockPNTB* hclObjectSpaceDeformerLocalBlockPNTB::hclObjectSpaceDeformerLocalBlockPNTBRead(MEM* src)
{
	hclObjectSpaceDeformerLocalBlockPNTB* x = new hclObjectSpaceDeformerLocalBlockPNTB;

	mread(&x->localPosition,2,1,src);
	mseek(src,126,SEEK_CUR);
	mread(&x->localNormal,2,1,src);
	mseek(src,126,SEEK_CUR);
	mread(&x->localTangent,2,1,src);
	mseek(src,126,SEEK_CUR);
	mread(&x->localBiTangent,2,1,src);
	mseek(src,126,SEEK_CUR);

	return x;
};
