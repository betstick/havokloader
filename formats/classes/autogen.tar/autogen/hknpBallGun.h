#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hknpFirstPersonGun.h"

class hknpBallGun
{
	public:
	hknpFirstPersonGun base;
	float bulletRadius;
	float bulletVelocity;
	float bulletMass;
	float damageMultiplier;
	int maxBulletsInWorld;
	vec4 bulletOffsetFromCenter;
	unsigned long addedBodyIds;
	unsigned short materialId;
	unsigned short motionPropertiesId;
	unsigned long bulletShape;
	unsigned int raiseContactEvents;

	static hknpBallGun* hknpBallGunRead(MEM* src);
};
