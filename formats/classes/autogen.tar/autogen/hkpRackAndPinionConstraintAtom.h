#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpConstraintAtom.h"

class hkpRackAndPinionConstraintAtom
{
	public:
	hkpConstraintAtom base;
	float pinionRadiusOrScrewPitch;
	bool isScrew;
	signed char memOffsetToInitialAngleOffset;
	signed char memOffsetToPrevAngle;
	signed char memOffsetToRevolutionCounter;
	unsigned char padding;

	static hkpRackAndPinionConstraintAtom* hkpRackAndPinionConstraintAtomRead(MEM* src);
};
