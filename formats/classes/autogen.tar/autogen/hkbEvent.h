#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbEventBase.h"

class hkbEvent
{
	public:
	hkbEventBase base;
	unsigned long sender;

	static hkbEvent* hkbEventRead(MEM* src);
};
