#pragma once
#include "hkaiUserEdgeUtilsUserEdgePair.h"

hkaiUserEdgeUtilsUserEdgePair* hkaiUserEdgeUtilsUserEdgePair::hkaiUserEdgeUtilsUserEdgePairRead(MEM* src)
{
	hkaiUserEdgeUtilsUserEdgePair* x = new hkaiUserEdgeUtilsUserEdgePair;

	mread(&x->x,16,1,src);
	mread(&x->y,16,1,src);
	mread(&x->z,16,1,src);
	mread(&x->instanceUidA,4,1,src);
	mread(&x->instanceUidB,4,1,src);
	mread(&x->faceA,4,1,src);
	mread(&x->faceB,4,1,src);
	mread(&x->userDataA,4,1,src);
	mread(&x->userDataB,4,1,src);
	mread(&x->costAtoB,sizeof(TYPE_HALF),1,src);
	mread(&x->costBtoA,sizeof(TYPE_HALF),1,src);
	mread(&x->direction,1,1,src);
	mseek(src,3,SEEK_CUR);

	return x;
};
