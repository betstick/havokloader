#pragma once
#include "hkxVertexBufferVertexData.h"

hkxVertexBufferVertexData* hkxVertexBufferVertexData::hkxVertexBufferVertexDataRead(MEM* src)
{
	hkxVertexBufferVertexData* x = new hkxVertexBufferVertexData;

	mread(&x->vectorData,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->floatData,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->uint32Data,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->uint16Data,2,1,src);
	mseek(src,14,SEEK_CUR);
	mread(&x->uint8Data,1,1,src);
	mseek(src,15,SEEK_CUR);
	mread(&x->numVerts,4,1,src);
	mread(&x->vectorStride,4,1,src);
	mread(&x->floatStride,4,1,src);
	mread(&x->uint32Stride,4,1,src);
	mread(&x->uint16Stride,4,1,src);
	mread(&x->uint8Stride,4,1,src);

	return x;
};
