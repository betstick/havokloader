#pragma once
#include "hkaiLineOfSightUtilLineOfSightInput.h"

hkaiLineOfSightUtilLineOfSightInput* hkaiLineOfSightUtilLineOfSightInput::hkaiLineOfSightUtilLineOfSightInputRead(MEM* src)
{
	hkaiLineOfSightUtilLineOfSightInput* x = new hkaiLineOfSightUtilLineOfSightInput;

	x->base = *hkaiLineOfSightUtilInputBase::hkaiLineOfSightUtilInputBaseRead(src);
	mread(&x->goalPoint,16,1,src);
	mread(&x->goalFaceKey,4,1,src);
	mseek(src,12,SEEK_CUR);
	mseek(src,80,SEEK_CUR);

	return x;
};
