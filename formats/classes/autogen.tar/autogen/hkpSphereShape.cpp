#pragma once
#include "hkpSphereShape.h"

hkpSphereShape* hkpSphereShape::hkpSphereShapeRead(MEM* src)
{
	hkpSphereShape* x = new hkpSphereShape;

	x->base = *hkpConvexShape::hkpConvexShapeRead(src);
	mread(&x->pad16,4,1,src);
	mseek(src,12,SEEK_CUR);
	mseek(src,40,SEEK_CUR);

	return x;
};
