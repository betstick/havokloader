#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkxMesh
{
	public:
	hkReferencedObject base;
	unsigned long* sections;
	unsigned long* userChannelInfos;

	static hkxMesh* hkxMeshRead(MEM* src);
};
