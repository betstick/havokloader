#pragma once
#include "hkaiUserEdgeUtilsObb.h"

hkaiUserEdgeUtilsObb* hkaiUserEdgeUtilsObb::hkaiUserEdgeUtilsObbRead(MEM* src)
{
	hkaiUserEdgeUtilsObb* x = new hkaiUserEdgeUtilsObb;

	mread(&x->transform,sizeof(TYPE_TRANSFORM),1,src);
	mread(&x->halfExtents,16,1,src);

	return x;
};
