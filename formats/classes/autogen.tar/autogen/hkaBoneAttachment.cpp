#pragma once
#include "hkaBoneAttachment.h"

hkaBoneAttachment* hkaBoneAttachment::hkaBoneAttachmentRead(MEM* src)
{
	hkaBoneAttachment* x = new hkaBoneAttachment;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->originalSkeletonName,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->boneFromAttachment,sizeof(TYPE_MATRIX4),1,src);
	mread(&x->attachment,8,1,src);
	mread(&x->name,8,1,src);
	mread(&x->boneIndex,2,1,src);
	mseek(src,14,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
