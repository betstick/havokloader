#pragma once
#include "hkcdShape.h"

hkcdShape* hkcdShape::hkcdShapeRead(MEM* src)
{
	hkcdShape* x = new hkcdShape;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->type,1,1,src);
	mread(&x->dispatchType,1,1,src);
	mread(&x->bitsPerKey,1,1,src);
	mread(&x->shapeInfoCodecType,1,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
