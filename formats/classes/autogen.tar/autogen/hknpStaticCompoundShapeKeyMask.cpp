#pragma once
#include "hknpStaticCompoundShapeKeyMask.h"

hknpStaticCompoundShapeKeyMask* hknpStaticCompoundShapeKeyMask::hknpStaticCompoundShapeKeyMaskRead(MEM* src)
{
	hknpStaticCompoundShapeKeyMask* x = new hknpStaticCompoundShapeKeyMask;

	x->base = *hknpCompoundShapeInternalsKeyMask::hknpCompoundShapeInternalsKeyMaskRead(src);
	mseek(src,48,SEEK_CUR);

	return x;
};
