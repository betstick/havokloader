#pragma once
#include "hclClothSetupObject.h"

hclClothSetupObject* hclClothSetupObject::hclClothSetupObjectRead(MEM* src)
{
	hclClothSetupObject* x = new hclClothSetupObject;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->name,8,1,src);
	mread(&x->bufferSetupObjects,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->transformSetSetupObjects,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->simClothSetupObjects,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->operatorSetupObjects,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->clothStateSetupObjects,8,1,src);
	mseek(src,8,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
