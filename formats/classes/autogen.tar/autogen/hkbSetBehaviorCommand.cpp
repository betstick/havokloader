#pragma once
#include "hkbSetBehaviorCommand.h"

hkbSetBehaviorCommand* hkbSetBehaviorCommand::hkbSetBehaviorCommandRead(MEM* src)
{
	hkbSetBehaviorCommand* x = new hkbSetBehaviorCommand;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->characterId,8,1,src);
	mread(&x->behavior,8,1,src);
	mread(&x->rootGenerator,8,1,src);
	mread(&x->referencedBehaviors,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->startStateIndex,4,1,src);
	mread(&x->randomizeSimulation,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->padding,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
