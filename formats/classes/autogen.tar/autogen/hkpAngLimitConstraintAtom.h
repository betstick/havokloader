#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpConstraintAtom.h"

class hkpAngLimitConstraintAtom
{
	public:
	hkpConstraintAtom base;
	unsigned char isEnabled;
	unsigned char limitAxis;
	float minAngle;
	float maxAngle;
	float angularLimitsTauFactor;

	static hkpAngLimitConstraintAtom* hkpAngLimitConstraintAtomRead(MEM* src);
};
