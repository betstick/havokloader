#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkaiTraversalAnnotationLibraryAnnotation
{
	public:
	vec4 tEquation;
	unsigned int userdata;
	unsigned int firstPartitionIndex;
	unsigned int firstVectorIndex;
	unsigned char numPartitions;
	unsigned char numVectors;
	unsigned char traversalType;

	static hkaiTraversalAnnotationLibraryAnnotation* hkaiTraversalAnnotationLibraryAnnotationRead(MEM* src);
};
