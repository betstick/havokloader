#pragma once
#include "hclStorageSetupMeshEdgeChannel.h"

hclStorageSetupMeshEdgeChannel* hclStorageSetupMeshEdgeChannel::hclStorageSetupMeshEdgeChannelRead(MEM* src)
{
	hclStorageSetupMeshEdgeChannel* x = new hclStorageSetupMeshEdgeChannel;

	mread(&x->name,8,1,src);
	mread(&x->type,4,1,src);
	mseek(src,4,SEEK_CUR);

	return x;
};
