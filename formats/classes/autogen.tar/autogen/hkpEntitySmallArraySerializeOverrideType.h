#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkpEntitySmallArraySerializeOverrideType
{
	public:
	unsigned long data;
	unsigned short size;
	unsigned short capacityAndFlags;

	static hkpEntitySmallArraySerializeOverrideType* hkpEntitySmallArraySerializeOverrideTypeRead(MEM* src);
};
