#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbMoveCharacterModifierInternalState
{
	public:
	hkReferencedObject base;
	float timeSinceLastModify;

	static hkbMoveCharacterModifierInternalState* hkbMoveCharacterModifierInternalStateRead(MEM* src);
};
