#pragma once
#include "hclVolumeConstraintMxApplyBatchData.h"

hclVolumeConstraintMxApplyBatchData* hclVolumeConstraintMxApplyBatchData::hclVolumeConstraintMxApplyBatchDataRead(MEM* src)
{
	hclVolumeConstraintMxApplyBatchData* x = new hclVolumeConstraintMxApplyBatchData;

	mread(&x->frameVector,16,1,src);
	mseek(src,240,SEEK_CUR);
	mread(&x->particleIndex,2,1,src);
	mseek(src,30,SEEK_CUR);
	mread(&x->stiffness,4,1,src);
	mseek(src,60,SEEK_CUR);

	return x;
};
