#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"
enum ConvexListCollisionType
{
	TREAT_CONVEX_LIST_AS_NORMAL = 0,
	TREAT_CONVEX_LIST_AS_LIST = 1,
	TREAT_CONVEX_LIST_AS_CONVEX = 2,
};

class hkpConvexListFilter
{
	public:
	hkReferencedObject base;

	static hkpConvexListFilter* hkpConvexListFilterRead(MEM* src);
};
