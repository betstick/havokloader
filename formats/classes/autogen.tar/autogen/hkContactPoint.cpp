#pragma once
#include "hkContactPoint.h"

hkContactPoint* hkContactPoint::hkContactPointRead(MEM* src)
{
	hkContactPoint* x = new hkContactPoint;

	mread(&x->position,16,1,src);
	mread(&x->separatingNormal,16,1,src);

	return x;
};
