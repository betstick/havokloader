#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkxVertexBufferVertexData
{
	public:
	unsigned int* vectorData;
	unsigned int* floatData;
	unsigned int* uint32Data;
	unsigned short* uint16Data;
	unsigned char* uint8Data;
	unsigned int numVerts;
	unsigned int vectorStride;
	unsigned int floatStride;
	unsigned int uint32Stride;
	unsigned int uint16Stride;
	unsigned int uint8Stride;

	static hkxVertexBufferVertexData* hkxVertexBufferVertexDataRead(MEM* src);
};
