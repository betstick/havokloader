#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclObjectSpaceMeshMeshDeformOperator.h"

class hclObjectSpaceMeshMeshDeformPOperator
{
	public:
	hclObjectSpaceMeshMeshDeformOperator base;
	hclObjectSpaceDeformerLocalBlockP* localPs;
	hclObjectSpaceDeformerLocalBlockUnpackedP* localUnpackedPs;

	static hclObjectSpaceMeshMeshDeformPOperator* hclObjectSpaceMeshMeshDeformPOperatorRead(MEM* src);
};
