#pragma once
#include "hkbRadialSelectorGenerator.h"

hkbRadialSelectorGenerator* hkbRadialSelectorGenerator::hkbRadialSelectorGeneratorRead(MEM* src)
{
	hkbRadialSelectorGenerator* x = new hkbRadialSelectorGenerator;

	x->base = *hkbGenerator::hkbGeneratorRead(src);
	mread(&x->generatorPairs,sizeof(hkbRadialSelectorGeneratorGeneratorPair),1,src);
	mread(&x->angle,4,1,src);
	mread(&x->radius,4,1,src);
	mread(&x->currentGeneratorPairIndex,4,1,src);
	mread(&x->currentEndpointIndex,4,1,src);
	mread(&x->currentFraction,4,1,src);
	mread(&x->hasSetLocalTime,1,1,src);
	mread(&x->pad,1,1,src);
	mseek(src,10,SEEK_CUR);
	mseek(src,136,SEEK_CUR);

	return x;
};
