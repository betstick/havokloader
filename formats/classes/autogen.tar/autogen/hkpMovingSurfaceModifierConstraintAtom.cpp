#pragma once
#include "hkpMovingSurfaceModifierConstraintAtom.h"

hkpMovingSurfaceModifierConstraintAtom* hkpMovingSurfaceModifierConstraintAtom::hkpMovingSurfaceModifierConstraintAtomRead(MEM* src)
{
	hkpMovingSurfaceModifierConstraintAtom* x = new hkpMovingSurfaceModifierConstraintAtom;

	x->base = *hkpModifierConstraintAtom::hkpModifierConstraintAtomRead(src);
	mread(&x->velocity,16,1,src);
	mseek(src,48,SEEK_CUR);

	return x;
};
