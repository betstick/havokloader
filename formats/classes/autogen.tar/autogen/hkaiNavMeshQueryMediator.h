#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkaiNavMeshQueryMediator
{
	public:
	hkReferencedObject base;

	static hkaiNavMeshQueryMediator* hkaiNavMeshQueryMediatorRead(MEM* src);
};
