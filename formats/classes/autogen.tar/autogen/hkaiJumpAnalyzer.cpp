#pragma once
#include "hkaiJumpAnalyzer.h"

hkaiJumpAnalyzer* hkaiJumpAnalyzer::hkaiJumpAnalyzerRead(MEM* src)
{
	hkaiJumpAnalyzer* x = new hkaiJumpAnalyzer;

	x->base = *hkaiTraversalAnalyzer::hkaiTraversalAnalyzerRead(src);
	mread(&x->maxHorizontalDistance,4,1,src);
	mread(&x->maxUpHeight,4,1,src);
	mread(&x->maxDownHeight,4,1,src);
	mread(&x->verticalApex,4,1,src);
	mseek(src,32,SEEK_CUR);

	return x;
};
