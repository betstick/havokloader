#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclBufferSetupObject.h"

class hclDisplayBufferSetupObject
{
	public:
	hclBufferSetupObject base;
	unsigned long setupMesh;
	unsigned long name;

	static hclDisplayBufferSetupObject* hclDisplayBufferSetupObjectRead(MEM* src);
};
