#pragma once
#include "hkpStiffSpringConstraintAtom.h"

hkpStiffSpringConstraintAtom* hkpStiffSpringConstraintAtom::hkpStiffSpringConstraintAtomRead(MEM* src)
{
	hkpStiffSpringConstraintAtom* x = new hkpStiffSpringConstraintAtom;

	x->base = *hkpConstraintAtom::hkpConstraintAtomRead(src);
	mread(&x->length,4,1,src);
	mread(&x->maxLength,4,1,src);
	mseek(src,4,SEEK_CUR);

	return x;
};
