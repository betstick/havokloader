#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpCharacterControllerCinfo.h"

class hkpCharacterProxyCinfo
{
	public:
	hkpCharacterControllerCinfo base;
	vec4 position;
	vec4 velocity;
	float dynamicFriction;
	float staticFriction;
	float keepContactTolerance;
	vec4 up;
	float extraUpStaticFriction;
	float extraDownStaticFriction;
	unsigned long shapePhantom;
	float keepDistance;
	float contactAngleSensitivity;
	unsigned int userPlanes;
	float maxCharacterSpeedForSolver;
	float characterStrength;
	float characterMass;
	float maxSlope;
	float penetrationRecoverySpeed;
	int maxCastIterations;
	bool refreshManifoldInCheckSupport;

	static hkpCharacterProxyCinfo* hkpCharacterProxyCinfoRead(MEM* src);
};
