#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbModifier.h"

class hkbPoweredRagdollControlsModifier
{
	public:
	hkbModifier base;
	hkbPoweredRagdollControlData controlData;
	unsigned long bones;
	hkbWorldFromModelModeData worldFromModelModeData;
	unsigned long boneWeights;
	float animationBlendFraction;

	static hkbPoweredRagdollControlsModifier* hkbPoweredRagdollControlsModifierRead(MEM* src);
};
