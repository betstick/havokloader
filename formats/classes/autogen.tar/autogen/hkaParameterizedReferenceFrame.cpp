#pragma once
#include "hkaParameterizedReferenceFrame.h"

hkaParameterizedReferenceFrame* hkaParameterizedReferenceFrame::hkaParameterizedReferenceFrameRead(MEM* src)
{
	hkaParameterizedReferenceFrame* x = new hkaParameterizedReferenceFrame;

	x->base = *hkaDefaultAnimatedReferenceFrame::hkaDefaultAnimatedReferenceFrameRead(src);
	mseek(src,96,SEEK_CUR);

	return x;
};
