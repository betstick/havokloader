#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkpCharacterControllerCinfo
{
	public:
	hkReferencedObject base;

	static hkpCharacterControllerCinfo* hkpCharacterControllerCinfoRead(MEM* src);
};
