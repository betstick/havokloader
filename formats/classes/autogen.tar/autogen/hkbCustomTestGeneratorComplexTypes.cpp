#pragma once
#include "hkbCustomTestGeneratorComplexTypes.h"

hkbCustomTestGeneratorComplexTypes* hkbCustomTestGeneratorComplexTypes::hkbCustomTestGeneratorComplexTypesRead(MEM* src)
{
	hkbCustomTestGeneratorComplexTypes* x = new hkbCustomTestGeneratorComplexTypes;

	x->base = *hkbCustomTestGeneratorSimpleTypes::hkbCustomTestGeneratorSimpleTypesRead(src);
	mread(&x->complexTypeHkObjectPtr,8,1,src);
	mread(&x->complexHiddenTypeCopyStart,1,1,src);
	mseek(src,7,SEEK_CUR);
	mread(&x->complexTypeHkQuaternion,sizeof(TYPE_QUATERNION),1,src);
	mread(&x->complexTypeHkVector4,16,1,src);
	mread(&x->complexTypeEnumHkInt8,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->complexTypeEnumHkInt16,2,1,src);
	mread(&x->complexTypeEnumHkInt32,4,1,src);
	mread(&x->complexTypeEnumHkUint8,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->complexTypeEnumHkUint16,2,1,src);
	mread(&x->complexTypeEnumHkUint32,4,1,src);
	mread(&x->complexTypeEnumHkInt8InvalidCheck,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->complexTypeEnumHkInt16InvalidCheck,2,1,src);
	mread(&x->complexTypeEnumHkInt32InvalidCheck,4,1,src);
	mread(&x->complexTypeEnumHkUint8InvalidCheck,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->complexTypeEnumHkUint16InvalidCheck,2,1,src);
	mread(&x->complexTypeEnumHkUint32InvalidCheck,4,1,src);
	mread(&x->complexTypeFlagsHkInt8,sizeof(TYPE_FLAGS),1,src);
	mread(&x->complexTypeFlagsHkInt16,sizeof(TYPE_FLAGS),1,src);
	mread(&x->complexTypeFlagsHkInt32,sizeof(TYPE_FLAGS),1,src);
	mread(&x->complexTypeFlagsHkUint8,sizeof(TYPE_FLAGS),1,src);
	mread(&x->complexTypeFlagsHkUint16,sizeof(TYPE_FLAGS),1,src);
	mread(&x->complexTypeFlagsHkUint32,sizeof(TYPE_FLAGS),1,src);
	mread(&x->complexTypeFlagsHkInt8InvalidCheck,sizeof(TYPE_FLAGS),1,src);
	mread(&x->complexTypeFlagsHkInt16InvalidCheck,sizeof(TYPE_FLAGS),1,src);
	mread(&x->complexTypeFlagsHkInt32InvalidCheck,sizeof(TYPE_FLAGS),1,src);
	mread(&x->complexTypeFlagsHkUint8InvalidCheck,sizeof(TYPE_FLAGS),1,src);
	mread(&x->complexTypeFlagsHkUint16InvalidCheck,sizeof(TYPE_FLAGS),1,src);
	mread(&x->complexTypeFlagsHkUint32InvalidCheck,sizeof(TYPE_FLAGS),1,src);
	mread(&x->complexHiddenTypeCopyEnd,1,1,src);
	mseek(src,15,SEEK_CUR);
	mseek(src,256,SEEK_CUR);

	return x;
};
