#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"
enum LightType
{
	POINT_LIGHT = 0,
	DIRECTIONAL_LIGHT = 1,
	SPOT_LIGHT = 2,
};

class hkxLight
{
	public:
	hkReferencedObject base;
	signed char type;
	vec4 position;
	vec4 direction;
	unsigned int color;
	float angle;
	float range;
	float fadeStart;
	float fadeEnd;
	short decayRate;
	float intensity;
	bool shadowCaster;

	static hkxLight* hkxLightRead(MEM* src);
};
