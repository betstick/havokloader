#pragma once
#include "hkaSkeletonMapperDataSimpleMapping.h"

hkaSkeletonMapperDataSimpleMapping* hkaSkeletonMapperDataSimpleMapping::hkaSkeletonMapperDataSimpleMappingRead(MEM* src)
{
	hkaSkeletonMapperDataSimpleMapping* x = new hkaSkeletonMapperDataSimpleMapping;

	mread(&x->boneA,2,1,src);
	mread(&x->boneB,2,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->aFromBTransform,48,1,src);

	return x;
};
