#pragma once
#include "hkaiNavMeshCutterSavedConnectivity.h"

hkaiNavMeshCutterSavedConnectivity* hkaiNavMeshCutterSavedConnectivity::hkaiNavMeshCutterSavedConnectivityRead(MEM* src)
{
	hkaiNavMeshCutterSavedConnectivity* x = new hkaiNavMeshCutterSavedConnectivity;

	mread(&x->storage,sizeof(hkSetUint32),1,src);

	return x;
};
