#pragma once
#include "fsnpCustomMeshParameterPrimitiveData.h"

fsnpCustomMeshParameterPrimitiveData* fsnpCustomMeshParameterPrimitiveData::fsnpCustomMeshParameterPrimitiveDataRead(MEM* src)
{
	fsnpCustomMeshParameterPrimitiveData* x = new fsnpCustomMeshParameterPrimitiveData;

	mread(&x->vertexData,1,1,src);
	mseek(src,15,SEEK_CUR);
	mread(&x->triangleData,1,1,src);
	mseek(src,15,SEEK_CUR);
	mread(&x->primitiveData,1,1,src);
	mseek(src,15,SEEK_CUR);
	mread(&x->materialNameData,4,1,src);
	mseek(src,4,SEEK_CUR);

	return x;
};
