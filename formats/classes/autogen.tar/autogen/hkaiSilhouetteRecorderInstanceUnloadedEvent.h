#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkaiSilhouetteRecorderReplayEvent.h"

class hkaiSilhouetteRecorderInstanceUnloadedEvent
{
	public:
	hkaiSilhouetteRecorderReplayEvent base;
	unsigned int sectionUid;

	static hkaiSilhouetteRecorderInstanceUnloadedEvent* hkaiSilhouetteRecorderInstanceUnloadedEventRead(MEM* src);
};
