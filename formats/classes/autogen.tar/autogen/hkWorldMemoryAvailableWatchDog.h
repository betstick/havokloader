#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkWorldMemoryAvailableWatchDog
{
	public:
	hkReferencedObject base;

	static hkWorldMemoryAvailableWatchDog* hkWorldMemoryAvailableWatchDogRead(MEM* src);
};
