#pragma once
#include "hkaSkeletonPartition.h"

hkaSkeletonPartition* hkaSkeletonPartition::hkaSkeletonPartitionRead(MEM* src)
{
	hkaSkeletonPartition* x = new hkaSkeletonPartition;

	mread(&x->name,8,1,src);
	mread(&x->startBoneIndex,2,1,src);
	mread(&x->numBones,2,1,src);
	mseek(src,4,SEEK_CUR);

	return x;
};
