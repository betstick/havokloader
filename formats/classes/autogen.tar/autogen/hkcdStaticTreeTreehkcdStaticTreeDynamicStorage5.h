#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkcdStaticTreeDynamicStorage5.h"

class hkcdStaticTreeTreehkcdStaticTreeDynamicStorage5
{
	public:
	hkcdStaticTreeDynamicStorage5 base;
	hkAabb domain;

	static hkcdStaticTreeTreehkcdStaticTreeDynamicStorage5* hkcdStaticTreeTreehkcdStaticTreeDynamicStorage5Read(MEM* src);
};
