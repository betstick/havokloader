#pragma once
#include "hkaAnnotationTrackAnnotation.h"

hkaAnnotationTrackAnnotation* hkaAnnotationTrackAnnotation::hkaAnnotationTrackAnnotationRead(MEM* src)
{
	hkaAnnotationTrackAnnotation* x = new hkaAnnotationTrackAnnotation;

	mread(&x->time,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->text,8,1,src);

	return x;
};
