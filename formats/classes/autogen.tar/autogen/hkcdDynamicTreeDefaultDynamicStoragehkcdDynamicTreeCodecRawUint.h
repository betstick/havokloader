#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkcdDynamicTreeDynamicStorage0hkcdDynamicTreeAnisotropicMetrichkcdDynamicTreeCodecRawUint.h"

class hkcdDynamicTreeDefaultDynamicStoragehkcdDynamicTreeCodecRawUint
{
	public:
	hkcdDynamicTreeDynamicStorage0hkcdDynamicTreeAnisotropicMetrichkcdDynamicTreeCodecRawUint base;

	static hkcdDynamicTreeDefaultDynamicStoragehkcdDynamicTreeCodecRawUint* hkcdDynamicTreeDefaultDynamicStoragehkcdDynamicTreeCodecRawUintRead(MEM* src);
};
