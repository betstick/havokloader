#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkpGenericConstraintDataSchemeConstraintInfo
{
	public:
	int maxSizeOfSchema;
	int sizeOfSchemas;
	int numSolverResults;
	int numSolverElemTemps;

	static hkpGenericConstraintDataSchemeConstraintInfo* hkpGenericConstraintDataSchemeConstraintInfoRead(MEM* src);
};
