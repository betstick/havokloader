#pragma once
#include "hkpBreakableMultiMaterial.h"

hkpBreakableMultiMaterial* hkpBreakableMultiMaterial::hkpBreakableMultiMaterialRead(MEM* src)
{
	hkpBreakableMultiMaterial* x = new hkpBreakableMultiMaterial;

	x->base = *hkpBreakableMaterial::hkpBreakableMaterialRead(src);
	mread(&x->subMaterials,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->inverseMapping,8,1,src);
	mseek(src,32,SEEK_CUR);

	return x;
};
