#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkGeometryTriangle
{
	public:
	int a;
	int b;
	int c;
	int material;

	static hkGeometryTriangle* hkGeometryTriangleRead(MEM* src);
};
