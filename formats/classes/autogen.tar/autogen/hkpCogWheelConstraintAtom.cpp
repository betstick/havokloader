#pragma once
#include "hkpCogWheelConstraintAtom.h"

hkpCogWheelConstraintAtom* hkpCogWheelConstraintAtom::hkpCogWheelConstraintAtomRead(MEM* src)
{
	hkpCogWheelConstraintAtom* x = new hkpCogWheelConstraintAtom;

	x->base = *hkpConstraintAtom::hkpConstraintAtomRead(src);
	mread(&x->cogWheelRadiusA,4,1,src);
	mread(&x->cogWheelRadiusB,4,1,src);
	mread(&x->isScrew,1,1,src);
	mread(&x->memOffsetToInitialAngleOffset,1,1,src);
	mread(&x->memOffsetToPrevAngle,1,1,src);
	mread(&x->memOffsetToRevolutionCounter,1,1,src);
	mseek(src,4,SEEK_CUR);

	return x;
};
