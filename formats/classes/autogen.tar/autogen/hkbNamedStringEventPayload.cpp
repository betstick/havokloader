#pragma once
#include "hkbNamedStringEventPayload.h"

hkbNamedStringEventPayload* hkbNamedStringEventPayload::hkbNamedStringEventPayloadRead(MEM* src)
{
	hkbNamedStringEventPayload* x = new hkbNamedStringEventPayload;

	x->base = *hkbNamedEventPayload::hkbNamedEventPayloadRead(src);
	mread(&x->data,8,1,src);
	mseek(src,24,SEEK_CUR);

	return x;
};
