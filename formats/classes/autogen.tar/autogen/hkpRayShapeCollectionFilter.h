#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkpRayShapeCollectionFilter
{
	public:

	static hkpRayShapeCollectionFilter* hkpRayShapeCollectionFilterRead(MEM* src);
};
