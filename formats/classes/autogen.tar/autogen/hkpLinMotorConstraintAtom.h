#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpConstraintAtom.h"

class hkpLinMotorConstraintAtom
{
	public:
	hkpConstraintAtom base;
	bool isEnabled;
	unsigned char motorAxis;
	short initializedOffset;
	short previousTargetPositionOffset;
	float targetPosition;
	unsigned long motor;

	static hkpLinMotorConstraintAtom* hkpLinMotorConstraintAtomRead(MEM* src);
};
