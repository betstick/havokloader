#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkResourceContainer.h"

class hkMemoryResourceContainer
{
	public:
	hkResourceContainer base;
	unsigned long name;
	unsigned long parent;
	unsigned long* resourceHandles;
	unsigned long* children;

	static hkMemoryResourceContainer* hkMemoryResourceContainerRead(MEM* src);
};
