#pragma once
#include "hkbDampingModifier.h"

hkbDampingModifier* hkbDampingModifier::hkbDampingModifierRead(MEM* src)
{
	hkbDampingModifier* x = new hkbDampingModifier;

	x->base = *hkbModifier::hkbModifierRead(src);
	mread(&x->kP,4,1,src);
	mread(&x->kI,4,1,src);
	mread(&x->kD,4,1,src);
	mread(&x->enableScalarDamping,1,1,src);
	mread(&x->enableVectorDamping,1,1,src);
	mseek(src,2,SEEK_CUR);
	mread(&x->rawValue,4,1,src);
	mread(&x->dampedValue,4,1,src);
	mread(&x->rawVector,16,1,src);
	mread(&x->dampedVector,16,1,src);
	mread(&x->vecErrorSum,16,1,src);
	mread(&x->vecPreviousError,16,1,src);
	mread(&x->errorSum,4,1,src);
	mread(&x->previousError,4,1,src);
	mseek(src,8,SEEK_CUR);
	mseek(src,88,SEEK_CUR);

	return x;
};
