#pragma once
#include "hkpSetLocalTranslationsConstraintAtom.h"

hkpSetLocalTranslationsConstraintAtom* hkpSetLocalTranslationsConstraintAtom::hkpSetLocalTranslationsConstraintAtomRead(MEM* src)
{
	hkpSetLocalTranslationsConstraintAtom* x = new hkpSetLocalTranslationsConstraintAtom;

	x->base = *hkpConstraintAtom::hkpConstraintAtomRead(src);
	mread(&x->translationA,16,1,src);
	mread(&x->translationB,16,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
