#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkaiLineOfSightUtilInputBase.h"

class hkaiLineOfSightUtilLineOfSightInput
{
	public:
	hkaiLineOfSightUtilInputBase base;
	vec4 goalPoint;
	unsigned int goalFaceKey;

	static hkaiLineOfSightUtilLineOfSightInput* hkaiLineOfSightUtilLineOfSightInputRead(MEM* src);
};
