#pragma once
#include "hkbStringEventPayload.h"

hkbStringEventPayload* hkbStringEventPayload::hkbStringEventPayloadRead(MEM* src)
{
	hkbStringEventPayload* x = new hkbStringEventPayload;

	x->base = *hkbEventPayload::hkbEventPayloadRead(src);
	mread(&x->data,8,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
