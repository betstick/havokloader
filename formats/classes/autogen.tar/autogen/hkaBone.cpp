#pragma once
#include "hkaBone.h"

hkaBone* hkaBone::hkaBoneRead(MEM* src)
{
	hkaBone* x = new hkaBone;

	mread(&x->name,8,1,src);
	mread(&x->lockTranslation,1,1,src);
	mseek(src,7,SEEK_CUR);

	return x;
};
