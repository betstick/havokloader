#pragma once
#include "hkpLimitedHingeConstraintDataAtoms.h"

hkpLimitedHingeConstraintDataAtoms* hkpLimitedHingeConstraintDataAtoms::hkpLimitedHingeConstraintDataAtomsRead(MEM* src)
{
	hkpLimitedHingeConstraintDataAtoms* x = new hkpLimitedHingeConstraintDataAtoms;

	mread(&x->transforms,sizeof(hkpSetLocalTransformsConstraintAtom),1,src);
	mread(&x->setupStabilization,sizeof(hkpSetupStabilizationAtom),1,src);
	mread(&x->angMotor,sizeof(hkpAngMotorConstraintAtom),1,src);
	mread(&x->angFriction,sizeof(hkpAngFrictionConstraintAtom),1,src);
	mread(&x->angLimit,sizeof(hkpAngLimitConstraintAtom),1,src);
	mread(&x->2dAng,sizeof(hkp2dAngConstraintAtom),1,src);
	mread(&x->ballSocket,sizeof(hkpBallSocketConstraintAtom),1,src);

	return x;
};
