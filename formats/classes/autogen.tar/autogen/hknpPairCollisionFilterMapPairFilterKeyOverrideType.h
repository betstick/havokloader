#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hknpPairCollisionFilterMapPairFilterKeyOverrideType
{
	public:
	unsigned long elem;
	int numElems;
	int hashMod;

	static hknpPairCollisionFilterMapPairFilterKeyOverrideType* hknpPairCollisionFilterMapPairFilterKeyOverrideTypeRead(MEM* src);
};
