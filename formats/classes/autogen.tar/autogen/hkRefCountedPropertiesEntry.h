#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkRefCountedPropertiesEntry
{
	public:
	unsigned long object;
	unsigned short key;
	unsigned short flags;

	static hkRefCountedPropertiesEntry* hkRefCountedPropertiesEntryRead(MEM* src);
};
