#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbGenerator.h"
enum StartStateMode
{
	START_STATE_MODE_DEFAULT = 0,
	START_STATE_MODE_SYNC = 1,
	START_STATE_MODE_RANDOM = 2,
	START_STATE_MODE_CHOOSER = 3,
};
enum StateMachineSelfTransitionMode
{
	SELF_TRANSITION_MODE_NO_TRANSITION = 0,
	SELF_TRANSITION_MODE_TRANSITION_TO_START_STATE = 1,
	SELF_TRANSITION_MODE_FORCE_TRANSITION_TO_START_STATE = 2,
};

class hkbStateMachine
{
	public:
	hkbGenerator base;
	hkbEvent eventToSendWhenStateOrTransitionChanges;
	unsigned long startStateIdSelector;
	int startStateId;
	int returnToPreviousStateEventId;
	int randomTransitionEventId;
	int transitionToNextHigherStateEventId;
	int transitionToNextLowerStateEventId;
	int syncVariableIndex;
	int currentStateId;
	bool wrapAroundStateId;
	signed char maxSimultaneousTransitions;
	signed char startStateMode;
	signed char selfTransitionMode;
	bool isActive;
	unsigned long* states;
	unsigned long wildcardTransitions;
	unsigned long stateIdToIndexMap;
	void* activeTransitions;
	void* transitionFlags;
	void* wildcardTransitionFlags;
	void* delayedTransitions;
	float timeInState;
	float lastLocalTime;
	int previousStateId;
	int nextStartStateIndexOverride;
	bool stateOrTransitionChanged;
	bool echoNextUpdate;
	bool hasEventlessWildcardTransitions;
	unsigned long eventIdToTransitionInfoIndicesMap;

	static hkbStateMachine* hkbStateMachineRead(MEM* src);
};
