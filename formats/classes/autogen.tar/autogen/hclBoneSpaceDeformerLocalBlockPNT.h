#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hclBoneSpaceDeformerLocalBlockPNT
{
	public:
	vec4 localPosition;
	short localNormal;
	short localTangent;

	static hclBoneSpaceDeformerLocalBlockPNT* hclBoneSpaceDeformerLocalBlockPNTRead(MEM* src);
};
