#pragma once
#include "hknpCollisionDispatchType.h"

hknpCollisionDispatchType* hknpCollisionDispatchType::hknpCollisionDispatchTypeRead(MEM* src)
{
	hknpCollisionDispatchType* x = new hknpCollisionDispatchType;

	mseek(src,1,SEEK_CUR);

	return x;
};
