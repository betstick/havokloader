#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"
enum BlendHint
{
	NORMAL = 0,
	ADDITIVE_DEPRECATED = 1,
	ADDITIVE = 2,
};

class hkaAnimationBinding
{
	public:
	hkReferencedObject base;
	unsigned long originalSkeletonName;
	unsigned long animation;
	short* transformTrackToBoneIndices;
	short* floatTrackToFloatSlotIndices;
	short* partitionIndices;
	signed char blendHint;

	static hkaAnimationBinding* hkaAnimationBindingRead(MEM* src);
};
