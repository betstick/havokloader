#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbModifier.h"
enum InitialVelocityCoordinates
{
	INITIAL_VELOCITY_IN_WORLD_COORDINATES = 0,
	INITIAL_VELOCITY_IN_MODEL_COORDINATES = 1,
};
enum MotionMode
{
	MOTION_MODE_FOLLOW_ANIMATION = 0,
	MOTION_MODE_DYNAMIC = 1,
};

class hkbCharacterControllerModifier
{
	public:
	hkbModifier base;
	hkbCharacterControllerModifierControlData controlData;
	vec4 initialVelocity;
	signed char initialVelocityCoordinates;
	signed char motionMode;
	bool forceDownwardMomentum;
	bool applyGravity;
	bool setInitialVelocity;
	bool isTouchingGround;
	vec4 gravity;
	bool isInitialVelocityAdded;

	static hkbCharacterControllerModifier* hkbCharacterControllerModifierRead(MEM* src);
};
