#pragma once
#include "hkcdDynamicTreeCodecRawunsignedint.h"

hkcdDynamicTreeCodecRawunsignedint* hkcdDynamicTreeCodecRawunsignedint::hkcdDynamicTreeCodecRawunsignedintRead(MEM* src)
{
	hkcdDynamicTreeCodecRawunsignedint* x = new hkcdDynamicTreeCodecRawunsignedint;

	mread(&x->aabb,sizeof(hkAabb),1,src);
	mread(&x->parent,4,1,src);
	mread(&x->children,4,1,src);
	mseek(src,8,SEEK_CUR);

	return x;
};
