#pragma once
#include "hkMemoryMeshTexture.h"

hkMemoryMeshTexture* hkMemoryMeshTexture::hkMemoryMeshTextureRead(MEM* src)
{
	hkMemoryMeshTexture* x = new hkMemoryMeshTexture;

	x->base = *hkMeshTexture::hkMeshTextureRead(src);
	mread(&x->filename,8,1,src);
	mread(&x->data,1,1,src);
	mseek(src,15,SEEK_CUR);
	mread(&x->format,1,1,src);
	mread(&x->hasMipMaps,1,1,src);
	mread(&x->filterMode,1,1,src);
	mread(&x->usageHint,1,1,src);
	mread(&x->textureCoordChannel,4,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
