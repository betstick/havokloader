#pragma once
#include "hkaiPhysics2012BodySilhouetteGenerator.h"

hkaiPhysics2012BodySilhouetteGenerator* hkaiPhysics2012BodySilhouetteGenerator::hkaiPhysics2012BodySilhouetteGeneratorRead(MEM* src)
{
	hkaiPhysics2012BodySilhouetteGenerator* x = new hkaiPhysics2012BodySilhouetteGenerator;

	x->base = *hkaiPhysicsBodySilhouetteGeneratorBase::hkaiPhysicsBodySilhouetteGeneratorBaseRead(src);
	mread(&x->rigidBody,8,1,src);
	mread(&x->physicsWorldListener,8,1,src);
	mseek(src,176,SEEK_CUR);

	return x;
};
