#pragma once
#include "hkpConstraintCollisionFilter.h"

hkpConstraintCollisionFilter* hkpConstraintCollisionFilter::hkpConstraintCollisionFilterRead(MEM* src)
{
	hkpConstraintCollisionFilter* x = new hkpConstraintCollisionFilter;

	x->base = *hkpPairCollisionFilter::hkpPairCollisionFilterRead(src);
	mseek(src,104,SEEK_CUR);

	return x;
};
