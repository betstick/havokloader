#pragma once
#include "hkpShapeCollectionFilter.h"

hkpShapeCollectionFilter* hkpShapeCollectionFilter::hkpShapeCollectionFilterRead(MEM* src)
{
	hkpShapeCollectionFilter* x = new hkpShapeCollectionFilter;

	mseek(src,8,SEEK_CUR);

	return x;
};
