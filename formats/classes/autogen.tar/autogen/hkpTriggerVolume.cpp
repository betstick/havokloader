#pragma once
#include "hkpTriggerVolume.h"

hkpTriggerVolume* hkpTriggerVolume::hkpTriggerVolumeRead(MEM* src)
{
	hkpTriggerVolume* x = new hkpTriggerVolume;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->overlappingBodies,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->eventQueue,sizeof(hkpTriggerVolumeEventInfo),1,src);
	mread(&x->triggerBody,8,1,src);
	mread(&x->sequenceNumber,4,1,src);
	mread(&x->isProcessingBodyOverlaps,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->newOverlappingBodies,8,1,src);
	mseek(src,8,SEEK_CUR);
	mseek(src,40,SEEK_CUR);

	return x;
};
