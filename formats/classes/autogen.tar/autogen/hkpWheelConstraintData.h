#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpConstraintData.h"

class hkpWheelConstraintData
{
	public:
	hkpConstraintData base;
	hkpWheelConstraintDataAtoms atoms;
	vec4 initialAxleInB;
	vec4 initialSteeringAxisInB;

	static hkpWheelConstraintData* hkpWheelConstraintDataRead(MEM* src);
};
