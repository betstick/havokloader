#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkaiWorldCharacterStepSerializableContext
{
	public:
	hkReferencedObject base;
	unsigned long world;
	unsigned char callbackType;
	float timestep;
	unsigned long* characters;
	hkaiLocalSteeringInput* localSteeringInputs;
	unsigned long* obstacleGenerators;

	static hkaiWorldCharacterStepSerializableContext* hkaiWorldCharacterStepSerializableContextRead(MEM* src);
};
