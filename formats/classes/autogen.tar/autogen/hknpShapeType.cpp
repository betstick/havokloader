#pragma once
#include "hknpShapeType.h"

hknpShapeType* hknpShapeType::hknpShapeTypeRead(MEM* src)
{
	hknpShapeType* x = new hknpShapeType;

	mseek(src,1,SEEK_CUR);

	return x;
};
