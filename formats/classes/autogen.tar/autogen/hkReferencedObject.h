#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkBaseObject.h"

class hkReferencedObject
{
	public:
	hkBaseObject base;
	unsigned int memSizeAndRefCount;

	static hkReferencedObject* hkReferencedObjectRead(MEM* src);
};
