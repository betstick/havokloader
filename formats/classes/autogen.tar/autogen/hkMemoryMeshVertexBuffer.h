#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkMeshVertexBuffer.h"

class hkMemoryMeshVertexBuffer
{
	public:
	hkMeshVertexBuffer base;
	hkVertexFormat format;
	int elementOffsets;
	unsigned char* memory;
	int vertexStride;
	bool locked;
	int numVertices;
	bool isBigEndian;
	bool isSharable;

	static hkMemoryMeshVertexBuffer* hkMemoryMeshVertexBufferRead(MEM* src);
};
