#pragma once
#include "hkcdStaticPvsBlockHeader.h"

hkcdStaticPvsBlockHeader* hkcdStaticPvsBlockHeader::hkcdStaticPvsBlockHeaderRead(MEM* src)
{
	hkcdStaticPvsBlockHeader* x = new hkcdStaticPvsBlockHeader;

	mread(&x->offset,4,1,src);
	mread(&x->length,4,1,src);

	return x;
};
