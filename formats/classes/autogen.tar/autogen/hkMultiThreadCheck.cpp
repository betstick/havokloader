#pragma once
#include "hkMultiThreadCheck.h"

hkMultiThreadCheck* hkMultiThreadCheck::hkMultiThreadCheckRead(MEM* src)
{
	hkMultiThreadCheck* x = new hkMultiThreadCheck;

	mread(&x->threadId,4,1,src);
	mread(&x->stackTraceId,4,1,src);
	mread(&x->markCount,2,1,src);
	mread(&x->markBitStack,2,1,src);

	return x;
};
