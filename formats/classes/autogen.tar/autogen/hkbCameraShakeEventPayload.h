#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbEventPayload.h"

class hkbCameraShakeEventPayload
{
	public:
	hkbEventPayload base;
	float amplitude;
	float halfLife;

	static hkbCameraShakeEventPayload* hkbCameraShakeEventPayloadRead(MEM* src);
};
