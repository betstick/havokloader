#pragma once
#include "hknpVehicleDefaultBrake.h"

hknpVehicleDefaultBrake* hknpVehicleDefaultBrake::hknpVehicleDefaultBrakeRead(MEM* src)
{
	hknpVehicleDefaultBrake* x = new hknpVehicleDefaultBrake;

	x->base = *hknpVehicleBrake::hknpVehicleBrakeRead(src);
	mread(&x->wheelBrakingProperties,sizeof(hknpVehicleDefaultBrakeWheelBrakingProperties),1,src);
	mread(&x->wheelsMinTimeToBlock,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
