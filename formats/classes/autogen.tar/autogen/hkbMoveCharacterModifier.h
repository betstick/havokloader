#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbModifier.h"

class hkbMoveCharacterModifier
{
	public:
	hkbModifier base;
	vec4 offsetPerSecondMS;
	float timeSinceLastModify;

	static hkbMoveCharacterModifier* hkbMoveCharacterModifierRead(MEM* src);
};
