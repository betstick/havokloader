#pragma once
#include "hkbJigglerModifierInternalState.h"

hkbJigglerModifierInternalState* hkbJigglerModifierInternalState::hkbJigglerModifierInternalStateRead(MEM* src)
{
	hkbJigglerModifierInternalState* x = new hkbJigglerModifierInternalState;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->currentVelocitiesWS,16,1,src);
	mread(&x->currentPositions,16,1,src);
	mread(&x->timeStep,4,1,src);
	mread(&x->initNextModify,1,1,src);
	mseek(src,3,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
