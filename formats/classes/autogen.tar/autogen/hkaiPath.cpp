#pragma once
#include "hkaiPath.h"

hkaiPath* hkaiPath::hkaiPathRead(MEM* src)
{
	hkaiPath* x = new hkaiPath;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->points,sizeof(hkaiPathPathPoint),1,src);
	mread(&x->referenceFrame,1,1,src);
	mseek(src,7,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
