#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hknpVehicleDataWheelComponentParams
{
	public:
	float radius;
	float mass;
	float width;
	float friction;
	float viscosityFriction;
	float maxFriction;
	float slipAngle;
	float forceFeedbackMultiplier;
	float maxContactBodyAcceleration;
	signed char axle;

	static hknpVehicleDataWheelComponentParams* hknpVehicleDataWheelComponentParamsRead(MEM* src);
};
