#pragma once
#include "hkbStateMachineEventPropertyArray.h"

hkbStateMachineEventPropertyArray* hkbStateMachineEventPropertyArray::hkbStateMachineEventPropertyArrayRead(MEM* src)
{
	hkbStateMachineEventPropertyArray* x = new hkbStateMachineEventPropertyArray;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->events,sizeof(hkbEventProperty),1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
