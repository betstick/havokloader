#pragma once
#include "hkbBehaviorGraphInternalStateInfo.h"

hkbBehaviorGraphInternalStateInfo* hkbBehaviorGraphInternalStateInfo::hkbBehaviorGraphInternalStateInfoRead(MEM* src)
{
	hkbBehaviorGraphInternalStateInfo* x = new hkbBehaviorGraphInternalStateInfo;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->characterId,8,1,src);
	mread(&x->internalState,8,1,src);
	mread(&x->auxiliaryNodeInfo,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->activeEventIds,2,1,src);
	mseek(src,14,SEEK_CUR);
	mread(&x->activeVariableIds,2,1,src);
	mseek(src,14,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
