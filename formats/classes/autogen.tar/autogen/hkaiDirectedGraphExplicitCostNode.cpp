#pragma once
#include "hkaiDirectedGraphExplicitCostNode.h"

hkaiDirectedGraphExplicitCostNode* hkaiDirectedGraphExplicitCostNode::hkaiDirectedGraphExplicitCostNodeRead(MEM* src)
{
	hkaiDirectedGraphExplicitCostNode* x = new hkaiDirectedGraphExplicitCostNode;

	mread(&x->startEdgeIndex,4,1,src);
	mread(&x->numEdges,4,1,src);

	return x;
};
