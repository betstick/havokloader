#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkaFootstepAnalysisInfoContainer
{
	public:
	hkReferencedObject base;
	unsigned long* previewInfo;

	static hkaFootstepAnalysisInfoContainer* hkaFootstepAnalysisInfoContainerRead(MEM* src);
};
