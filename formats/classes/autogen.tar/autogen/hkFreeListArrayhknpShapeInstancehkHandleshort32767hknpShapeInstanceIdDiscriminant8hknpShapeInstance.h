#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkFreeListArrayhknpShapeInstancehkHandleshort32767hknpShapeInstanceIdDiscriminant8hknpShapeInstance
{
	public:
	hknpShapeInstance* elements;
	int firstFree;

	static hkFreeListArrayhknpShapeInstancehkHandleshort32767hknpShapeInstanceIdDiscriminant8hknpShapeInstance* hkFreeListArrayhknpShapeInstancehkHandleshort32767hknpShapeInstanceIdDiscriminant8hknpShapeInstanceRead(MEM* src);
};
