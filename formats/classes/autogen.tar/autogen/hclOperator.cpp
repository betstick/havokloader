#pragma once
#include "hclOperator.h"

hclOperator* hclOperator::hclOperatorRead(MEM* src)
{
	hclOperator* x = new hclOperator;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->name,8,1,src);
	mread(&x->type,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
