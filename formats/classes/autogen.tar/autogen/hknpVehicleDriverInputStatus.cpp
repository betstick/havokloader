#pragma once
#include "hknpVehicleDriverInputStatus.h"

hknpVehicleDriverInputStatus* hknpVehicleDriverInputStatus::hknpVehicleDriverInputStatusRead(MEM* src)
{
	hknpVehicleDriverInputStatus* x = new hknpVehicleDriverInputStatus;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mseek(src,16,SEEK_CUR);

	return x;
};
