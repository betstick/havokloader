#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbTransitionEffect.h"

class hkbManualSelectorTransitionEffect
{
	public:
	hkbTransitionEffect base;
	unsigned long* transitionEffects;
	unsigned char selectedIndex;
	unsigned long indexSelector;
	unsigned char currentTransitionEffectIndex;
	unsigned long currentTransitionEffect;
	unsigned long parentStateMachine;
	unsigned long referenceBehavior;

	static hkbManualSelectorTransitionEffect* hkbManualSelectorTransitionEffectRead(MEM* src);
};
