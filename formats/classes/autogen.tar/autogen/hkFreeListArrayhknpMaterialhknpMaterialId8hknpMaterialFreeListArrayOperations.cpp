#pragma once
#include "hkFreeListArrayhknpMaterialhknpMaterialId8hknpMaterialFreeListArrayOperations.h"

hkFreeListArrayhknpMaterialhknpMaterialId8hknpMaterialFreeListArrayOperations* hkFreeListArrayhknpMaterialhknpMaterialId8hknpMaterialFreeListArrayOperations::hkFreeListArrayhknpMaterialhknpMaterialId8hknpMaterialFreeListArrayOperationsRead(MEM* src)
{
	hkFreeListArrayhknpMaterialhknpMaterialId8hknpMaterialFreeListArrayOperations* x = new hkFreeListArrayhknpMaterialhknpMaterialId8hknpMaterialFreeListArrayOperations;

	mread(&x->elements,sizeof(hknpMaterial),1,src);
	mread(&x->firstFree,4,1,src);
	mseek(src,4,SEEK_CUR);

	return x;
};
