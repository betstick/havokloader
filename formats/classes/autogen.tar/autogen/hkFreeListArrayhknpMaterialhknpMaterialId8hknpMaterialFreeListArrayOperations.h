#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkFreeListArrayhknpMaterialhknpMaterialId8hknpMaterialFreeListArrayOperations
{
	public:
	hknpMaterial* elements;
	int firstFree;

	static hkFreeListArrayhknpMaterialhknpMaterialId8hknpMaterialFreeListArrayOperations* hkFreeListArrayhknpMaterialhknpMaterialId8hknpMaterialFreeListArrayOperationsRead(MEM* src);
};
