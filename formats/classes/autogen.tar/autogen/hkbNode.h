#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbBindable.h"
enum GetChildrenFlagBits
{
	FLAG_ACTIVE_ONLY = 1,
	FLAG_GENERATORS_ONLY = 4,
	FLAG_IGNORE_REFERENCED_BEHAVIORS = 8,
};
enum CloneState
{
	CLONE_STATE_DEFAULT = 0,
	CLONE_STATE_TEMPLATE = 1,
	CLONE_STATE_CLONE = 2,
};
enum TemplateOrClone
{
	NODE_IS_TEMPLATE = 0,
	NODE_IS_CLONE = 1,
};

class hkbNode
{
	public:
	hkbBindable base;
	unsigned long userData;
	unsigned long name;
	unsigned short id;
	signed char cloneState;
	unsigned char type;
	unsigned long nodeInfo;

	static hkbNode* hkbNodeRead(MEM* src);
};
