#pragma once
#include "hknpRefMaterial.h"

hknpRefMaterial* hknpRefMaterial::hknpRefMaterialRead(MEM* src)
{
	hknpRefMaterial* x = new hknpRefMaterial;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->material,sizeof(hknpMaterial),1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
