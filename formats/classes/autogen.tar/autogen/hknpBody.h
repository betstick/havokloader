#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
enum Flags
{
	IS_STATIC = 1,
	IS_DYNAMIC = 2,
	IS_KEYFRAMED = 4,
	IS_ACTIVE = 8,
};
enum SpuFlagsEnum
{
	FORCE_NARROW_PHASE_PPU = 1,
};

class hknpBody
{
	public:
	TYPE_TRANSFORM transform;
	int flags;
	unsigned int collisionFilterInfo;
	unsigned long shape;
	hkAabb16 aabb;
	unsigned int id;
	unsigned int nextAttachedBodyId;
	unsigned int motionId;
	unsigned int broadPhaseId;
	unsigned short materialId;
	unsigned char qualityId;
	unsigned char timAngle;
	unsigned short maxTimDistance;
	unsigned short maxContactDistance;
	unsigned int indexIntoActiveListOrDeactivatedIslandId;
	TYPE_HALF radiusOfComCenteredBoundingSphere;
	TYPE_FLAGS spuFlags;
	unsigned char shapeSizeDiv16;
	short motionToBodyRotation;
	unsigned long userData;

	static hknpBody* hknpBodyRead(MEM* src);
};
