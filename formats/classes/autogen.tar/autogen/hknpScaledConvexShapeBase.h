#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hknpDecoratorShape.h"

class hknpScaledConvexShapeBase
{
	public:
	hknpDecoratorShape base;
	vec4 scale;
	vec4 translation;

	static hknpScaledConvexShapeBase* hknpScaledConvexShapeBaseRead(MEM* src);
};
