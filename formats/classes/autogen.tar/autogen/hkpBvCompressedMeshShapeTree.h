#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkcdStaticMeshTreehkcdStaticMeshTreeCommonConfigunsignedintunsignedlonglong1121hkpBvCompressedMeshShapeTreeDataRun.h"

class hkpBvCompressedMeshShapeTree
{
	public:
	hkcdStaticMeshTreehkcdStaticMeshTreeCommonConfigunsignedintunsignedlonglong1121hkpBvCompressedMeshShapeTreeDataRun base;

	static hkpBvCompressedMeshShapeTree* hkpBvCompressedMeshShapeTreeRead(MEM* src);
};
