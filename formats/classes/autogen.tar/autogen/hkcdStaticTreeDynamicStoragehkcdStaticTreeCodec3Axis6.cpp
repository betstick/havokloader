#pragma once
#include "hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis6.h"

hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis6* hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis6::hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis6Read(MEM* src)
{
	hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis6* x = new hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis6;

	mread(&x->nodes,sizeof(hkcdStaticTreeCodec3Axis6),1,src);

	return x;
};
