#pragma once
#include "hclObjectSpaceMeshMeshDeformPNTBOperator.h"

hclObjectSpaceMeshMeshDeformPNTBOperator* hclObjectSpaceMeshMeshDeformPNTBOperator::hclObjectSpaceMeshMeshDeformPNTBOperatorRead(MEM* src)
{
	hclObjectSpaceMeshMeshDeformPNTBOperator* x = new hclObjectSpaceMeshMeshDeformPNTBOperator;

	x->base = *hclObjectSpaceMeshMeshDeformOperator::hclObjectSpaceMeshMeshDeformOperatorRead(src);
	mread(&x->localPNTBs,sizeof(hclObjectSpaceDeformerLocalBlockPNTB),1,src);
	mread(&x->localUnpackedPNTBs,sizeof(hclObjectSpaceDeformerLocalBlockUnpackedPNTB),1,src);
	mseek(src,168,SEEK_CUR);

	return x;
};
