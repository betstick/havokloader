#pragma once
#include "hkaiDirectedGraphInstanceFreeBlockList.h"

hkaiDirectedGraphInstanceFreeBlockList* hkaiDirectedGraphInstanceFreeBlockList::hkaiDirectedGraphInstanceFreeBlockListRead(MEM* src)
{
	hkaiDirectedGraphInstanceFreeBlockList* x = new hkaiDirectedGraphInstanceFreeBlockList;

	mread(&x->blocks,4,1,src);
	mseek(src,12,SEEK_CUR);

	return x;
};
