#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkxEdgeSelectionChannel
{
	public:
	hkReferencedObject base;
	int* selectedEdges;

	static hkxEdgeSelectionChannel* hkxEdgeSelectionChannelRead(MEM* src);
};
