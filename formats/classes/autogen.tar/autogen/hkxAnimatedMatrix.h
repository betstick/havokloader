#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkxAnimatedMatrix
{
	public:
	hkReferencedObject base;
	float* matrices;
	unsigned char hint;

	static hkxAnimatedMatrix* hkxAnimatedMatrixRead(MEM* src);
};
