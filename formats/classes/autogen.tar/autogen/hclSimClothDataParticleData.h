#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hclSimClothDataParticleData
{
	public:
	float mass;
	float invMass;
	float radius;
	float friction;

	static hclSimClothDataParticleData* hclSimClothDataParticleDataRead(MEM* src);
};
