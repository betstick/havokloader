#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkbIntVariableSequencedDataSample
{
	public:
	float time;
	int value;

	static hkbIntVariableSequencedDataSample* hkbIntVariableSequencedDataSampleRead(MEM* src);
};
