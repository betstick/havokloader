#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkbGeneratorSyncInfo
{
	public:
	hkbGeneratorSyncInfoSyncPoint syncPoints;
	float duration;
	float localTime;
	float playbackSpeed;
	signed char numSyncPoints;
	bool isCyclic;
	bool isMirrored;
	bool isAdditive;
	hkbGeneratorSyncInfoActiveInterval activeInterval;

	static hkbGeneratorSyncInfo* hkbGeneratorSyncInfoRead(MEM* src);
};
