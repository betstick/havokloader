#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclOperator.h"

class hclGatherSomeVerticesOperator
{
	public:
	hclOperator base;
	hclGatherSomeVerticesOperatorVertexPair* vertexPairs;
	unsigned int inputBufferIdx;
	unsigned int outputBufferIdx;
	bool gatherNormals;

	static hclGatherSomeVerticesOperator* hclGatherSomeVerticesOperatorRead(MEM* src);
};
