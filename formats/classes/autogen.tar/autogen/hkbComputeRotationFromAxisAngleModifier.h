#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbModifier.h"

class hkbComputeRotationFromAxisAngleModifier
{
	public:
	hkbModifier base;
	TYPE_QUATERNION rotationOut;
	vec4 axis;
	float angleDegrees;

	static hkbComputeRotationFromAxisAngleModifier* hkbComputeRotationFromAxisAngleModifierRead(MEM* src);
};
