#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbGenerator.h"
enum PlaybackMode
{
	MODE_SINGLE_PLAY = 0,
	MODE_LOOPING = 1,
};
enum ClipFlags
{
	FLAG_CONTINUE_MOTION_AT_END = 1,
	FLAG_SYNC_HALF_CYCLE_IN_PING_PONG_MODE = 2,
	FLAG_MIRROR = 4,
	FLAG_FORCE_DENSE_POSE = 8,
	FLAG_DONT_CONVERT_ANNOTATIONS_TO_TRIGGERS = 16,
	FLAG_IGNORE_MOTION = 32,
};
enum AnimeEndEventType
{
	FireNextStateEvent = 0,
	FireStateEndEvent = 1,
	FireIdleEvent = 2,
};

class CustomClipGenerator
{
	public:
	hkbGenerator base;
	float playbackSpeed;
	signed char mode;
	int animId;
	int animeEndEventType;
	hkbEvent endEvent;
	unsigned long animationControl;
	unsigned long binding;
	unsigned long mapperData;
	float cropStartAmountLocalTime;
	float cropEndAmountLocalTime;
	float startTime;
	float enforcedDuration;
	signed char flags;
	qstransform extractedMotion;
	unsigned long animationName;
	float localTime;
	bool atEnd;
	bool ignoreStartTime;

	static CustomClipGenerator* CustomClipGeneratorRead(MEM* src);
};
