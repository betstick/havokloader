#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkLocalFrameGroup
{
	public:
	hkReferencedObject base;
	unsigned long name;

	static hkLocalFrameGroup* hkLocalFrameGroupRead(MEM* src);
};
