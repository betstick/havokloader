#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbBlenderGeneratorInternalState
{
	public:
	hkReferencedObject base;
	hkbBlenderGeneratorChildInternalState* childrenInternalStates;
	short* sortedChildren;
	float endIntervalWeight;
	int numActiveChildren;
	short beginIntervalIndex;
	short endIntervalIndex;
	bool initSync;
	bool doSubtractiveBlend;

	static hkbBlenderGeneratorInternalState* hkbBlenderGeneratorInternalStateRead(MEM* src);
};
