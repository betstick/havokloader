#pragma once
#include "hknpMotionCinfo.h"

hknpMotionCinfo* hknpMotionCinfo::hknpMotionCinfoRead(MEM* src)
{
	hknpMotionCinfo* x = new hknpMotionCinfo;

	mread(&x->motionPropertiesId,2,1,src);
	mread(&x->enableDeactivation,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->inverseMass,4,1,src);
	mread(&x->massFactor,4,1,src);
	mread(&x->maxLinearAccelerationDistancePerStep,4,1,src);
	mread(&x->maxRotationToPreventTunneling,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->inverseInertiaLocal,16,1,src);
	mread(&x->centerOfMassWorld,16,1,src);
	mread(&x->orientation,sizeof(TYPE_QUATERNION),1,src);
	mread(&x->linearVelocity,16,1,src);
	mread(&x->angularVelocity,16,1,src);

	return x;
};
