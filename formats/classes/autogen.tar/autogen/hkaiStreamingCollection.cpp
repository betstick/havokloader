#pragma once
#include "hkaiStreamingCollection.h"

hkaiStreamingCollection* hkaiStreamingCollection::hkaiStreamingCollectionRead(MEM* src)
{
	hkaiStreamingCollection* x = new hkaiStreamingCollection;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->isTemporary,1,1,src);
	mseek(src,7,SEEK_CUR);
	mread(&x->tree,8,1,src);
	mread(&x->instances,sizeof(hkaiStreamingCollectionInstanceInfo),1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
