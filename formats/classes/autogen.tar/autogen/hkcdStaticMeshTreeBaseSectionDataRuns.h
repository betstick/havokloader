#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkcdStaticMeshTreeBaseSectionDataRuns
{
	public:
	unsigned int data;

	static hkcdStaticMeshTreeBaseSectionDataRuns* hkcdStaticMeshTreeBaseSectionDataRunsRead(MEM* src);
};
