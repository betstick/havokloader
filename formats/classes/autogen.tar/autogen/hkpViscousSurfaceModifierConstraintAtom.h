#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpModifierConstraintAtom.h"

class hkpViscousSurfaceModifierConstraintAtom
{
	public:
	hkpModifierConstraintAtom base;

	static hkpViscousSurfaceModifierConstraintAtom* hkpViscousSurfaceModifierConstraintAtomRead(MEM* src);
};
