#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkxTextureFile
{
	public:
	hkReferencedObject base;
	unsigned long filename;
	unsigned long name;
	unsigned long originalFilename;

	static hkxTextureFile* hkxTextureFileRead(MEM* src);
};
