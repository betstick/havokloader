#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpBroadPhaseHandle.h"

class hkpTypedBroadPhaseHandle
{
	public:
	hkpBroadPhaseHandle base;
	signed char type;
	signed char ownerOffset;
	signed char objectQualityType;
	unsigned int collisionFilterInfo;

	static hkpTypedBroadPhaseHandle* hkpTypedBroadPhaseHandleRead(MEM* src);
};
