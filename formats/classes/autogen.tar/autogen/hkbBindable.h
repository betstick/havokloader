#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbBindable
{
	public:
	hkReferencedObject base;
	unsigned long variableBindingSet;
	unsigned long* cachedBindables;
	bool areBindablesCached;
	bool hasEnableChanged;

	static hkbBindable* hkbBindableRead(MEM* src);
};
