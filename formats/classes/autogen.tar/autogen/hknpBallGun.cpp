#pragma once
#include "hknpBallGun.h"

hknpBallGun* hknpBallGun::hknpBallGunRead(MEM* src)
{
	hknpBallGun* x = new hknpBallGun;

	x->base = *hknpFirstPersonGun::hknpFirstPersonGunRead(src);
	mread(&x->bulletRadius,4,1,src);
	mread(&x->bulletVelocity,4,1,src);
	mread(&x->bulletMass,4,1,src);
	mread(&x->damageMultiplier,4,1,src);
	mread(&x->maxBulletsInWorld,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->bulletOffsetFromCenter,16,1,src);
	mread(&x->addedBodyIds,8,1,src);
	mread(&x->materialId,2,1,src);
	mread(&x->motionPropertiesId,2,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->bulletShape,8,1,src);
	mread(&x->raiseContactEvents,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,64,SEEK_CUR);

	return x;
};
