#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpConstraintAtom.h"

class hkpModifierConstraintAtom
{
	public:
	hkpConstraintAtom base;
	unsigned short modifierAtomSize;
	unsigned short childSize;
	unsigned long child;
	unsigned int pad;

	static hkpModifierConstraintAtom* hkpModifierConstraintAtomRead(MEM* src);
};
