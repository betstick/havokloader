#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkxVertexBuffer
{
	public:
	hkReferencedObject base;
	hkxVertexBufferVertexData data;
	hkxVertexDescription desc;

	static hkxVertexBuffer* hkxVertexBufferRead(MEM* src);
};
