#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
enum FadingState
{
	FADING_STATE_NONE = 0,
	FADING_STATE_IN = 1,
	FADING_STATE_OUT = 2,
};

class hkbLayerGeneratorLayerInternalState
{
	public:
	float weight;
	float timeElapsed;
	float onFraction;
	signed char fadingState;
	bool useMotion;
	bool syncNextFrame;
	bool isActive;

	static hkbLayerGeneratorLayerInternalState* hkbLayerGeneratorLayerInternalStateRead(MEM* src);
};
