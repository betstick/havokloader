#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkUuid
{
	public:
	unsigned int data;

	static hkUuid* hkUuidRead(MEM* src);
};
