#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkxVertexSelectionChannel
{
	public:
	hkReferencedObject base;
	int* selectedVertices;

	static hkxVertexSelectionChannel* hkxVertexSelectionChannelRead(MEM* src);
};
