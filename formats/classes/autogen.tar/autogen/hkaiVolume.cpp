#pragma once
#include "hkaiVolume.h"

hkaiVolume* hkaiVolume::hkaiVolumeRead(MEM* src)
{
	hkaiVolume* x = new hkaiVolume;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mseek(src,16,SEEK_CUR);

	return x;
};
