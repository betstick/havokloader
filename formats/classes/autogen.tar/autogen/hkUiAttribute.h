#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
enum HideCriteria
{
	NONE = 0,
	MODELER_IS_MAX = 1,
	MODELER_IS_MAYA = 2,
	UI_SCHEME_IS_DESTRUCTION = 4,
	UI_SCHEME_IS_DESTRUCTION_2012 = 8,
};

class hkUiAttribute
{
	public:
	bool visible;
	bool editable;
	signed char hideCriteria;
	TYPE_CSTRING label;
	TYPE_CSTRING group;
	TYPE_CSTRING hideBaseClassMembers;
	bool endGroup;
	bool endGroup2;
	bool advanced;

	static hkUiAttribute* hkUiAttributeRead(MEM* src);
};
