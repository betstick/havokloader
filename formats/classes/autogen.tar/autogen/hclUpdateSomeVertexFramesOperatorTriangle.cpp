#pragma once
#include "hclUpdateSomeVertexFramesOperatorTriangle.h"

hclUpdateSomeVertexFramesOperatorTriangle* hclUpdateSomeVertexFramesOperatorTriangle::hclUpdateSomeVertexFramesOperatorTriangleRead(MEM* src)
{
	hclUpdateSomeVertexFramesOperatorTriangle* x = new hclUpdateSomeVertexFramesOperatorTriangle;

	mread(&x->indices,2,1,src);
	mseek(src,4,SEEK_CUR);

	return x;
};
