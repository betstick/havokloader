#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkMeshBoneIndexMapping
{
	public:
	short* mapping;

	static hkMeshBoneIndexMapping* hkMeshBoneIndexMappingRead(MEM* src);
};
