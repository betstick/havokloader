#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbAiControlCancelPathCommand
{
	public:
	hkReferencedObject base;
	unsigned long characterId;

	static hkbAiControlCancelPathCommand* hkbAiControlCancelPathCommandRead(MEM* src);
};
