#pragma once
#include "hkFourTransposedPointsf.h"

hkFourTransposedPointsf* hkFourTransposedPointsf::hkFourTransposedPointsfRead(MEM* src)
{
	hkFourTransposedPointsf* x = new hkFourTransposedPointsf;

	mread(&x->vertices,16,1,src);
	mseek(src,32,SEEK_CUR);

	return x;
};
