#pragma once
#include "hkbVariableInfo.h"

hkbVariableInfo* hkbVariableInfo::hkbVariableInfoRead(MEM* src)
{
	hkbVariableInfo* x = new hkbVariableInfo;

	mread(&x->role,sizeof(hkbRoleAttribute),1,src);
	mread(&x->type,1,1,src);
	mseek(src,1,SEEK_CUR);

	return x;
};
