#pragma once
#include "hkxSkinBinding.h"

hkxSkinBinding* hkxSkinBinding::hkxSkinBindingRead(MEM* src)
{
	hkxSkinBinding* x = new hkxSkinBinding;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->mesh,8,1,src);
	mread(&x->nodeNames,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->bindPose,sizeof(TYPE_MATRIX4),1,src);
	mread(&x->initSkinTransform,sizeof(TYPE_MATRIX4),1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
