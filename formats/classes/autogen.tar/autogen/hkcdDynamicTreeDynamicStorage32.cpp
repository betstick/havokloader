#pragma once
#include "hkcdDynamicTreeDynamicStorage32.h"

hkcdDynamicTreeDynamicStorage32* hkcdDynamicTreeDynamicStorage32::hkcdDynamicTreeDynamicStorage32Read(MEM* src)
{
	hkcdDynamicTreeDynamicStorage32* x = new hkcdDynamicTreeDynamicStorage32;

	x->base = *hkcdDynamicTreeDefaultDynamicStoragehkcdDynamicTreeCodecRawUint::hkcdDynamicTreeDefaultDynamicStoragehkcdDynamicTreeCodecRawUintRead(src);
	mseek(src,24,SEEK_CUR);

	return x;
};
