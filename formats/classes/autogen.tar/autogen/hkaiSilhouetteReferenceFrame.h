#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkaiSilhouetteReferenceFrame
{
	public:
	vec4 up;
	vec4 referenceAxis;
	vec4 orthogonalAxis;

	static hkaiSilhouetteReferenceFrame* hkaiSilhouetteReferenceFrameRead(MEM* src);
};
