#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpConstraintData.h"

class hkpWheelFrictionConstraintData
{
	public:
	hkpConstraintData base;
	hkpWheelFrictionConstraintDataAtoms atoms;

	static hkpWheelFrictionConstraintData* hkpWheelFrictionConstraintDataRead(MEM* src);
};
