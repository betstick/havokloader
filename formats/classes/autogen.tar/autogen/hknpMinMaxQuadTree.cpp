#pragma once
#include "hknpMinMaxQuadTree.h"

hknpMinMaxQuadTree* hknpMinMaxQuadTree::hknpMinMaxQuadTreeRead(MEM* src)
{
	hknpMinMaxQuadTree* x = new hknpMinMaxQuadTree;

	mread(&x->coarseTreeData,sizeof(hknpMinMaxQuadTreeMinMaxLevel),1,src);
	mread(&x->offset,16,1,src);
	mread(&x->multiplier,4,1,src);
	mread(&x->invMultiplier,4,1,src);
	mseek(src,8,SEEK_CUR);

	return x;
};
