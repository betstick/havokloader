#pragma once
#include "hkpFixedRigidMotion.h"

hkpFixedRigidMotion* hkpFixedRigidMotion::hkpFixedRigidMotionRead(MEM* src)
{
	hkpFixedRigidMotion* x = new hkpFixedRigidMotion;

	x->base = *hkpKeyframedRigidMotion::hkpKeyframedRigidMotionRead(src);
	mseek(src,320,SEEK_CUR);

	return x;
};
