#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hknpDynamicCompoundShapeData
{
	public:
	hkReferencedObject base;
	hknpDynamicCompoundShapeTree aabbTree;

	static hknpDynamicCompoundShapeData* hknpDynamicCompoundShapeDataRead(MEM* src);
};
