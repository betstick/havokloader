#pragma once
#include "hkaiCharacter.h"

hkaiCharacter* hkaiCharacter::hkaiCharacterRead(MEM* src)
{
	hkaiCharacter* x = new hkaiCharacter;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->userData,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->position,16,1,src);
	mread(&x->forward,16,1,src);
	mread(&x->velocity,16,1,src);
	mread(&x->up,16,1,src);
	mread(&x->currentNavMeshFace,4,1,src);
	mread(&x->radius,4,1,src);
	mread(&x->desiredSpeed,4,1,src);
	mread(&x->adaptiveRanger,sizeof(hkaiAdaptiveRanger),1,src);
	mread(&x->costModifier,8,1,src);
	mread(&x->edgeFilter,8,1,src);
	mread(&x->hitFilter,8,1,src);
	mread(&x->steeringFilter,8,1,src);
	mread(&x->agentFilterInfo,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->avoidanceProperties,8,1,src);
	mread(&x->avoidanceState,4,1,src);
	mread(&x->agentPriority,4,1,src);
	mread(&x->avoidanceType,2,1,src);
	mread(&x->avoidanceEnabledMask,sizeof(TYPE_FLAGS),1,src);
	mread(&x->state,4,1,src);
	mread(&x->behaviorListeners,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->layer,4,1,src);
	mseek(src,12,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
