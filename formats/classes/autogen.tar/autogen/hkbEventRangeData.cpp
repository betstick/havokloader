#pragma once
#include "hkbEventRangeData.h"

hkbEventRangeData* hkbEventRangeData::hkbEventRangeDataRead(MEM* src)
{
	hkbEventRangeData* x = new hkbEventRangeData;

	mread(&x->upperBound,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->event,sizeof(hkbEventProperty),1,src);
	mread(&x->eventMode,1,1,src);
	mseek(src,7,SEEK_CUR);

	return x;
};
