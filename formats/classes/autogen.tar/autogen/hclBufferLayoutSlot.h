#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hclBufferLayoutSlot
{
	public:
	unsigned char flags;
	unsigned char stride;

	static hclBufferLayoutSlot* hclBufferLayoutSlotRead(MEM* src);
};
