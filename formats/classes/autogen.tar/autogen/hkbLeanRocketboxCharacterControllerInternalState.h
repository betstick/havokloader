#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbLeanRocketboxCharacterControllerInternalState
{
	public:
	hkReferencedObject base;
	int currPose;
	int prevPose;
	float characterAngle;
	int plantedFootIdx;
	float timeStep;

	static hkbLeanRocketboxCharacterControllerInternalState* hkbLeanRocketboxCharacterControllerInternalStateRead(MEM* src);
};
