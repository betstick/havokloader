#pragma once
#include "hkxMeshSection.h"

hkxMeshSection* hkxMeshSection::hkxMeshSectionRead(MEM* src)
{
	hkxMeshSection* x = new hkxMeshSection;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->vertexBuffer,8,1,src);
	mread(&x->indexBuffers,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->material,8,1,src);
	mread(&x->userChannels,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->vertexAnimations,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->linearKeyFrameHints,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->boneMatrixMap,sizeof(hkMeshBoneIndexMapping),1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
