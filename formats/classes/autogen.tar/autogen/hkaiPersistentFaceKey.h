#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkaiPersistentFaceKey
{
	public:
	unsigned int key;
	short offset;

	static hkaiPersistentFaceKey* hkaiPersistentFaceKeyRead(MEM* src);
};
