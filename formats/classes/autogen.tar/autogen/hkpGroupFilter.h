#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpCollisionFilter.h"

class hkpGroupFilter
{
	public:
	hkpCollisionFilter base;
	int nextFreeSystemGroup;
	unsigned int collisionLookupTable;
	vec4 pad256;

	static hkpGroupFilter* hkpGroupFilterRead(MEM* src);
};
