#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbBlendingTransitionEffect.h"

class hkbHoldFromBlendingTransitionEffect
{
	public:
	hkbBlendingTransitionEffect base;
	unsigned long heldFromPose;
	int heldFromPoseSize;
	qstransform heldWorldFromModel;
	unsigned long heldFromSkeleton;

	static hkbHoldFromBlendingTransitionEffect* hkbHoldFromBlendingTransitionEffectRead(MEM* src);
};
