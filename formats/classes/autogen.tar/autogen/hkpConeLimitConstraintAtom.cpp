#pragma once
#include "hkpConeLimitConstraintAtom.h"

hkpConeLimitConstraintAtom* hkpConeLimitConstraintAtom::hkpConeLimitConstraintAtomRead(MEM* src)
{
	hkpConeLimitConstraintAtom* x = new hkpConeLimitConstraintAtom;

	x->base = *hkpConstraintAtom::hkpConstraintAtomRead(src);
	mread(&x->isEnabled,1,1,src);
	mread(&x->twistAxisInA,1,1,src);
	mread(&x->refAxisInB,1,1,src);
	mread(&x->angleMeasurementMode,1,1,src);
	mread(&x->memOffsetToAngleOffset,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->minAngle,4,1,src);
	mread(&x->maxAngle,4,1,src);
	mread(&x->angularLimitsTauFactor,4,1,src);
	mread(&x->padding,1,1,src);
	mseek(src,11,SEEK_CUR);
	mseek(src,2,SEEK_CUR);

	return x;
};
