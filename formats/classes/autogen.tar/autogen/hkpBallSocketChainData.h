#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpConstraintChainData.h"

class hkpBallSocketChainData
{
	public:
	hkpConstraintChainData base;
	hkpBridgeAtoms atoms;
	hkpBallSocketChainDataConstraintInfo* infos;
	float tau;
	float damping;
	float cfm;
	float maxErrorDistance;
	bool useStabilizedCode;

	static hkpBallSocketChainData* hkpBallSocketChainDataRead(MEM* src);
};
