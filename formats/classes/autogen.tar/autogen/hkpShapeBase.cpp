#pragma once
#include "hkpShapeBase.h"

hkpShapeBase* hkpShapeBase::hkpShapeBaseRead(MEM* src)
{
	hkpShapeBase* x = new hkpShapeBase;

	x->base = *hkcdShape::hkcdShapeRead(src);
	mseek(src,24,SEEK_CUR);

	return x;
};
