#pragma once
#include "hclObjectSpaceDeformerLocalBlockUnpackedPN.h"

hclObjectSpaceDeformerLocalBlockUnpackedPN* hclObjectSpaceDeformerLocalBlockUnpackedPN::hclObjectSpaceDeformerLocalBlockUnpackedPNRead(MEM* src)
{
	hclObjectSpaceDeformerLocalBlockUnpackedPN* x = new hclObjectSpaceDeformerLocalBlockUnpackedPN;

	mread(&x->localPosition,16,1,src);
	mseek(src,240,SEEK_CUR);
	mread(&x->localNormal,16,1,src);
	mseek(src,240,SEEK_CUR);

	return x;
};
