#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkPackedVector8_3
{
	public:
	signed char values;

	static hkPackedVector8_3* hkPackedVector8_3Read(MEM* src);
};
