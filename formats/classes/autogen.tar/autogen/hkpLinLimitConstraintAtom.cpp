#pragma once
#include "hkpLinLimitConstraintAtom.h"

hkpLinLimitConstraintAtom* hkpLinLimitConstraintAtom::hkpLinLimitConstraintAtomRead(MEM* src)
{
	hkpLinLimitConstraintAtom* x = new hkpLinLimitConstraintAtom;

	x->base = *hkpConstraintAtom::hkpConstraintAtomRead(src);
	mread(&x->axisIndex,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->min,4,1,src);
	mread(&x->max,4,1,src);
	mread(&x->padding,1,1,src);
	mseek(src,3,SEEK_CUR);
	mseek(src,2,SEEK_CUR);

	return x;
};
