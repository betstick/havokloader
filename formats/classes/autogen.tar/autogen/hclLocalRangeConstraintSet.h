#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclConstraintSet.h"
enum ShapeType
{
	SHAPE_SPHERE = 0,
	SHAPE_CYLINDER = 1,
};
enum ForceUpgrade6
{
	HCL_FORCE_UPGRADE6 = 0,
};

class hclLocalRangeConstraintSet
{
	public:
	hclConstraintSet base;
	hclLocalRangeConstraintSetLocalConstraint* localConstraints;
	unsigned int referenceMeshBufferIdx;
	float stiffness;
	unsigned int shapeType;
	bool applyNormalComponent;

	static hclLocalRangeConstraintSet* hclLocalRangeConstraintSetRead(MEM* src);
};
