#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpFirstPersonGun.h"

class hkpProjectileGun
{
	public:
	hkpFirstPersonGun base;
	int maxProjectiles;
	float reloadTime;
	float reload;
	unsigned long* projectiles;
	unsigned long world;
	unsigned long destructionWorld;

	static hkpProjectileGun* hkpProjectileGunRead(MEM* src);
};
