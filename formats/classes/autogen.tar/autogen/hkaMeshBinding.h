#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkaMeshBinding
{
	public:
	hkReferencedObject base;
	unsigned long mesh;
	unsigned long originalSkeletonName;
	unsigned long name;
	unsigned long skeleton;
	hkaMeshBindingMapping* mappings;
	TYPE_TRANSFORM* boneFromSkinMeshTransforms;

	static hkaMeshBinding* hkaMeshBindingRead(MEM* src);
};
