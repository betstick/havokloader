#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkcdStaticMeshTreeBase.h"
enum TriangleMaterial
{
	TM_SET_FROM_TRIANGLE_DATA_TYPE = 0,
	TM_SET_FROM_PRIMITIVE_KEY = 1,
};

class hkcdStaticMeshTreehkcdStaticMeshTreeCommonConfigunsignedintunsignedlonglong1121hknpCompressedMeshShapeTreeDataRun
{
	public:
	hkcdStaticMeshTreeBase base;
	unsigned int* packedVertices;
	unsigned long* sharedVertices;
	hknpCompressedMeshShapeTreeDataRun* primitiveDataRuns;

	static hkcdStaticMeshTreehkcdStaticMeshTreeCommonConfigunsignedintunsignedlonglong1121hknpCompressedMeshShapeTreeDataRun* hkcdStaticMeshTreehkcdStaticMeshTreeCommonConfigunsignedintunsignedlonglong1121hknpCompressedMeshShapeTreeDataRunRead(MEM* src);
};
