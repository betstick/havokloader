#pragma once
#include "hknpVehicleEngine.h"

hknpVehicleEngine* hknpVehicleEngine::hknpVehicleEngineRead(MEM* src)
{
	hknpVehicleEngine* x = new hknpVehicleEngine;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mseek(src,16,SEEK_CUR);

	return x;
};
