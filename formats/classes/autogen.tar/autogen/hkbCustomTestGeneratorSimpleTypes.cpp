#pragma once
#include "hkbCustomTestGeneratorSimpleTypes.h"

hkbCustomTestGeneratorSimpleTypes* hkbCustomTestGeneratorSimpleTypes::hkbCustomTestGeneratorSimpleTypesRead(MEM* src)
{
	hkbCustomTestGeneratorSimpleTypes* x = new hkbCustomTestGeneratorSimpleTypes;

	x->base = *hkbCustomTestGeneratorHiddenTypes::hkbCustomTestGeneratorHiddenTypesRead(src);
	mread(&x->simpleTypeHkInt64,8,1,src);
	mread(&x->simpleTypeHkUint64,8,1,src);
	mread(&x->simpleHiddenTypeCopyStart,1,1,src);
	mread(&x->simpleTypeBool,1,1,src);
	mread(&x->simpleTypeHkBool,1,1,src);
	mseek(src,5,SEEK_CUR);
	mread(&x->simpleTypeCString,sizeof(TYPE_CSTRING),1,src);
	mread(&x->simpleTypeHkStringPtr,8,1,src);
	mread(&x->simpleTypeHkInt8,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->simpleTypeHkInt16,2,1,src);
	mread(&x->simpleTypeHkInt32,4,1,src);
	mread(&x->simpleTypeHkUint8,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->simpleTypeHkUint16,2,1,src);
	mread(&x->simpleTypeHkUint32,4,1,src);
	mread(&x->simpleTypeHkReal,4,1,src);
	mread(&x->simpleTypeHkInt8Default,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->simpleTypeHkInt16Default,2,1,src);
	mread(&x->simpleTypeHkInt32Default,4,1,src);
	mread(&x->simpleTypeHkUint8Default,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->simpleTypeHkUint16Default,2,1,src);
	mread(&x->simpleTypeHkUint32Default,4,1,src);
	mread(&x->simpleTypeHkRealDefault,4,1,src);
	mread(&x->simpleTypeHkInt8Clamp,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->simpleTypeHkInt16Clamp,2,1,src);
	mread(&x->simpleTypeHkInt32Clamp,4,1,src);
	mread(&x->simpleTypeHkUint8Clamp,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->simpleTypeHkUint16Clamp,2,1,src);
	mread(&x->simpleTypeHkUint32Clamp,4,1,src);
	mread(&x->simpleTypeHkRealClamp,4,1,src);
	mread(&x->simpleHiddenTypeCopyEnd,1,1,src);
	mseek(src,3,SEEK_CUR);
	mseek(src,152,SEEK_CUR);

	return x;
};
