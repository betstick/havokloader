#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hknpVehicleVelocityDamper
{
	public:
	hkReferencedObject base;

	static hknpVehicleVelocityDamper* hknpVehicleVelocityDamperRead(MEM* src);
};
