#pragma once
#include "hkMeshShape.h"

hkMeshShape* hkMeshShape::hkMeshShapeRead(MEM* src)
{
	hkMeshShape* x = new hkMeshShape;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mseek(src,16,SEEK_CUR);

	return x;
};
