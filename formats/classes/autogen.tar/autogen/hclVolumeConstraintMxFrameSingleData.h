#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hclVolumeConstraintMxFrameSingleData
{
	public:
	vec4 frameVector;
	unsigned short particleIndex;
	float weight;

	static hclVolumeConstraintMxFrameSingleData* hclVolumeConstraintMxFrameSingleDataRead(MEM* src);
};
