#pragma once
#include "hkpTriangleShape.h"

hkpTriangleShape* hkpTriangleShape::hkpTriangleShapeRead(MEM* src)
{
	hkpTriangleShape* x = new hkpTriangleShape;

	x->base = *hkpConvexShape::hkpConvexShapeRead(src);
	mread(&x->weldingInfo,2,1,src);
	mread(&x->weldingType,1,1,src);
	mread(&x->isExtruded,1,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->vertexA,16,1,src);
	mread(&x->vertexB,16,1,src);
	mread(&x->vertexC,16,1,src);
	mread(&x->extrusion,16,1,src);
	mseek(src,40,SEEK_CUR);

	return x;
};
