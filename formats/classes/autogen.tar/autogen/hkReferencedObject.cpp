#pragma once
#include "hkReferencedObject.h"

hkReferencedObject* hkReferencedObject::hkReferencedObjectRead(MEM* src)
{
	hkReferencedObject* x = new hkReferencedObject;

	x->base = *hkBaseObject::hkBaseObjectRead(src);
	mread(&x->memSizeAndRefCount,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,8,SEEK_CUR);

	return x;
};
