#pragma once
#include "hkpPairCollisionFilterMapPairFilterKeyOverrideType.h"

hkpPairCollisionFilterMapPairFilterKeyOverrideType* hkpPairCollisionFilterMapPairFilterKeyOverrideType::hkpPairCollisionFilterMapPairFilterKeyOverrideTypeRead(MEM* src)
{
	hkpPairCollisionFilterMapPairFilterKeyOverrideType* x = new hkpPairCollisionFilterMapPairFilterKeyOverrideType;

	mread(&x->elem,8,1,src);
	mread(&x->numElems,4,1,src);
	mread(&x->hashMod,4,1,src);

	return x;
};
