#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbCustomIdSelector
{
	public:
	hkReferencedObject base;

	static hkbCustomIdSelector* hkbCustomIdSelectorRead(MEM* src);
};
