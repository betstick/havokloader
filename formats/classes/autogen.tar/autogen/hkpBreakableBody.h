#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkpBreakableBody
{
	public:
	hkReferencedObject base;
	unsigned long controller;
	unsigned long breakableShape;
	unsigned char bodyTypeAndFlags;
	TYPE_HALF constraintStrength;

	static hkpBreakableBody* hkpBreakableBodyRead(MEM* src);
};
