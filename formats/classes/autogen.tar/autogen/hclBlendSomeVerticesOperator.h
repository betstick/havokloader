#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclOperator.h"
enum VectorContext
{
	VEC_POSITION = 0,
	VEC_DIRECTION = 1,
};

class hclBlendSomeVerticesOperator
{
	public:
	hclOperator base;
	hclBlendSomeVerticesOperatorBlendEntry* blendEntries;
	unsigned int bufferIdx_A;
	unsigned int bufferIdx_B;
	unsigned int bufferIdx_C;
	bool blendNormals;
	bool blendTangents;
	bool blendBitangents;

	static hclBlendSomeVerticesOperator* hclBlendSomeVerticesOperatorRead(MEM* src);
};
