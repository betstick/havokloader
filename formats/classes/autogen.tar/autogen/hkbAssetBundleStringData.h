#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkbAssetBundleStringData
{
	public:
	unsigned long bundleName;
	unsigned long* assetNames;

	static hkbAssetBundleStringData* hkbAssetBundleStringDataRead(MEM* src);
};
