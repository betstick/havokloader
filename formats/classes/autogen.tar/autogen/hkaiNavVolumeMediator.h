#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkaiNavVolumeMediator
{
	public:
	hkReferencedObject base;

	static hkaiNavVolumeMediator* hkaiNavVolumeMediatorRead(MEM* src);
};
