#pragma once
#include "hclStretchLinkConstraintSetMxBatch.h"

hclStretchLinkConstraintSetMxBatch* hclStretchLinkConstraintSetMxBatch::hclStretchLinkConstraintSetMxBatchRead(MEM* src)
{
	hclStretchLinkConstraintSetMxBatch* x = new hclStretchLinkConstraintSetMxBatch;

	mread(&x->restLengths,4,1,src);
	mseek(src,60,SEEK_CUR);
	mread(&x->stiffnesses,4,1,src);
	mseek(src,60,SEEK_CUR);
	mread(&x->particlesA,2,1,src);
	mseek(src,30,SEEK_CUR);
	mread(&x->particlesB,2,1,src);
	mseek(src,30,SEEK_CUR);

	return x;
};
