#pragma once
#include "hkaiOverlappingTrianglesSettings.h"

hkaiOverlappingTrianglesSettings* hkaiOverlappingTrianglesSettings::hkaiOverlappingTrianglesSettingsRead(MEM* src)
{
	hkaiOverlappingTrianglesSettings* x = new hkaiOverlappingTrianglesSettings;

	mread(&x->coplanarityTolerance,4,1,src);
	mread(&x->raycastLengthMultiplier,4,1,src);
	mread(&x->walkableTriangleSettings,1,1,src);
	mseek(src,3,SEEK_CUR);

	return x;
};
