#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkpSerializedDisplayRbTransforms
{
	public:
	hkReferencedObject base;
	hkpSerializedDisplayRbTransformsDisplayTransformPair* transforms;

	static hkpSerializedDisplayRbTransforms* hkpSerializedDisplayRbTransformsRead(MEM* src);
};
