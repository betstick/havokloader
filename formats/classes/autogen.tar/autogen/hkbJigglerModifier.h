#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbModifier.h"
enum JiggleCoordinates
{
	JIGGLE_IN_WORLD_COORDINATES = 0,
	JIGGLE_IN_MODEL_COORDINATES = 1,
};

class hkbJigglerModifier
{
	public:
	hkbModifier base;
	unsigned long* jigglerGroups;
	signed char jiggleCoordinates;
	void* currentVelocitiesWS;
	void* currentPositions;
	float timeStep;
	bool initNextModify;

	static hkbJigglerModifier* hkbJigglerModifierRead(MEM* src);
};
