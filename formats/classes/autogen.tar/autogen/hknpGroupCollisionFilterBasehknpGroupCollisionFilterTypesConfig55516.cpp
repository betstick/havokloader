#pragma once
#include "hknpGroupCollisionFilterBasehknpGroupCollisionFilterTypesConfig55516.h"

hknpGroupCollisionFilterBasehknpGroupCollisionFilterTypesConfig55516* hknpGroupCollisionFilterBasehknpGroupCollisionFilterTypesConfig55516::hknpGroupCollisionFilterBasehknpGroupCollisionFilterTypesConfig55516Read(MEM* src)
{
	hknpGroupCollisionFilterBasehknpGroupCollisionFilterTypesConfig55516* x = new hknpGroupCollisionFilterBasehknpGroupCollisionFilterTypesConfig55516;

	x->base = *hknpCollisionFilter::hknpCollisionFilterRead(src);
	mread(&x->nextFreeSystemGroup,4,1,src);
	mread(&x->collisionLookupTable,4,1,src);
	mseek(src,136,SEEK_CUR);
	mseek(src,32,SEEK_CUR);

	return x;
};
