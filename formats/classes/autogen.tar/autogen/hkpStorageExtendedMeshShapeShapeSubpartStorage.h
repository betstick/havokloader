#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkpStorageExtendedMeshShapeShapeSubpartStorage
{
	public:
	hkReferencedObject base;
	unsigned char* materialIndices;
	hkpStorageExtendedMeshShapeMaterial* materials;
	unsigned short* materialIndices16;

	static hkpStorageExtendedMeshShapeShapeSubpartStorage* hkpStorageExtendedMeshShapeShapeSubpartStorageRead(MEM* src);
};
