#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hclClothStateSetupObject
{
	public:
	hkReferencedObject base;
	unsigned long name;
	unsigned long* operatorSetupObjects;

	static hclClothStateSetupObject* hclClothStateSetupObjectRead(MEM* src);
};
