#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkaAnnotationTrack
{
	public:
	unsigned long trackName;
	hkaAnnotationTrackAnnotation* annotations;

	static hkaAnnotationTrack* hkaAnnotationTrackRead(MEM* src);
};
