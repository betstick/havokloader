#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkSkinnedMeshShapeBoneSection
{
	public:
	unsigned long meshBuffer;
	unsigned short startBoneSetId;
	short numBoneSets;

	static hkSkinnedMeshShapeBoneSection* hkSkinnedMeshShapeBoneSectionRead(MEM* src);
};
