#pragma once
#include "hkAabb16.h"

hkAabb16* hkAabb16::hkAabb16Read(MEM* src)
{
	hkAabb16* x = new hkAabb16;

	mread(&x->min,2,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->key,2,1,src);
	mread(&x->max,2,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->key1,2,1,src);

	return x;
};
