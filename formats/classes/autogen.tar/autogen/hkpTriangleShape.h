#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpConvexShape.h"

class hkpTriangleShape
{
	public:
	hkpConvexShape base;
	unsigned short weldingInfo;
	unsigned char weldingType;
	unsigned char isExtruded;
	vec4 vertexA;
	vec4 vertexB;
	vec4 vertexC;
	vec4 extrusion;

	static hkpTriangleShape* hkpTriangleShapeRead(MEM* src);
};
