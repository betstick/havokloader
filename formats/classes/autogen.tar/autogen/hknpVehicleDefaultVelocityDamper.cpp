#pragma once
#include "hknpVehicleDefaultVelocityDamper.h"

hknpVehicleDefaultVelocityDamper* hknpVehicleDefaultVelocityDamper::hknpVehicleDefaultVelocityDamperRead(MEM* src)
{
	hknpVehicleDefaultVelocityDamper* x = new hknpVehicleDefaultVelocityDamper;

	x->base = *hknpVehicleVelocityDamper::hknpVehicleVelocityDamperRead(src);
	mread(&x->normalSpinDamping,4,1,src);
	mread(&x->collisionSpinDamping,4,1,src);
	mread(&x->collisionThreshold,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
