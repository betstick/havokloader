#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkaiNavMeshGenerationSettingsOverrideSettings
{
	public:
	unsigned long volume;
	int material;
	unsigned char characterWidthUsage;
	float maxWalkableSlope;
	hkaiNavMeshEdgeMatchingParameters edgeMatchingParams;
	hkaiNavMeshSimplificationUtilsSettings simplificationSettings;

	static hkaiNavMeshGenerationSettingsOverrideSettings* hkaiNavMeshGenerationSettingsOverrideSettingsRead(MEM* src);
};
