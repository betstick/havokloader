#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
enum BlendCurve
{
	BLEND_CURVE_SMOOTH = 0,
	BLEND_CURVE_LINEAR = 1,
	BLEND_CURVE_LINEAR_TO_SMOOTH = 2,
	BLEND_CURVE_SMOOTH_TO_LINEAR = 3,
};

class hkbBlendCurveUtils
{
	public:

	static hkbBlendCurveUtils* hkbBlendCurveUtilsRead(MEM* src);
};
