#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkcdStaticMeshTreeBaseSectionSharedVertices
{
	public:
	unsigned int data;

	static hkcdStaticMeshTreeBaseSectionSharedVertices* hkcdStaticMeshTreeBaseSectionSharedVerticesRead(MEM* src);
};
