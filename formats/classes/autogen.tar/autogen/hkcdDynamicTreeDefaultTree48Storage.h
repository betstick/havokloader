#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkcdDynamicTreeTreehkcdDynamicTreeDynamicStorage32.h"

class hkcdDynamicTreeDefaultTree48Storage
{
	public:
	hkcdDynamicTreeTreehkcdDynamicTreeDynamicStorage32 base;

	static hkcdDynamicTreeDefaultTree48Storage* hkcdDynamicTreeDefaultTree48StorageRead(MEM* src);
};
