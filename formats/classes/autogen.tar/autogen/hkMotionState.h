#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkMotionState
{
	public:
	TYPE_TRANSFORM transform;
	vec4 sweptTransform;
	vec4 deltaAngle;
	float objectRadius;
	TYPE_HALF linearDamping;
	TYPE_HALF angularDamping;
	TYPE_HALF timeFactor;
	hkUFloat8 maxLinearVelocity;
	hkUFloat8 maxAngularVelocity;
	unsigned char deactivationClass;

	static hkMotionState* hkMotionStateRead(MEM* src);
};
