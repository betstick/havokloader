#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkbEventSequencedDataSequencedEvent
{
	public:
	hkbEvent event;
	float time;

	static hkbEventSequencedDataSequencedEvent* hkbEventSequencedDataSequencedEventRead(MEM* src);
};
