#pragma once
#include "hkpPrismaticConstraintData.h"

hkpPrismaticConstraintData* hkpPrismaticConstraintData::hkpPrismaticConstraintDataRead(MEM* src)
{
	hkpPrismaticConstraintData* x = new hkpPrismaticConstraintData;

	x->base = *hkpConstraintData::hkpConstraintDataRead(src);
	mread(&x->atoms,sizeof(hkpPrismaticConstraintDataAtoms),1,src);
	mseek(src,32,SEEK_CUR);

	return x;
};
