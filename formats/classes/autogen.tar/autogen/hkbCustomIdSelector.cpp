#pragma once
#include "hkbCustomIdSelector.h"

hkbCustomIdSelector* hkbCustomIdSelector::hkbCustomIdSelectorRead(MEM* src)
{
	hkbCustomIdSelector* x = new hkbCustomIdSelector;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mseek(src,16,SEEK_CUR);

	return x;
};
