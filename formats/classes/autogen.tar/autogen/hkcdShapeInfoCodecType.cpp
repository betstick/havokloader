#pragma once
#include "hkcdShapeInfoCodecType.h"

hkcdShapeInfoCodecType* hkcdShapeInfoCodecType::hkcdShapeInfoCodecTypeRead(MEM* src)
{
	hkcdShapeInfoCodecType* x = new hkcdShapeInfoCodecType;

	mseek(src,1,SEEK_CUR);

	return x;
};
