#pragma once
#include "hkpFixedConstraintData.h"

hkpFixedConstraintData* hkpFixedConstraintData::hkpFixedConstraintDataRead(MEM* src)
{
	hkpFixedConstraintData* x = new hkpFixedConstraintData;

	x->base = *hkpConstraintData::hkpConstraintDataRead(src);
	mread(&x->atoms,sizeof(hkpFixedConstraintDataAtoms),1,src);
	mseek(src,32,SEEK_CUR);

	return x;
};
