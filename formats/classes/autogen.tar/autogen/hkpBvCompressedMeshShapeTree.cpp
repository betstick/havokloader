#pragma once
#include "hkpBvCompressedMeshShapeTree.h"

hkpBvCompressedMeshShapeTree* hkpBvCompressedMeshShapeTree::hkpBvCompressedMeshShapeTreeRead(MEM* src)
{
	hkpBvCompressedMeshShapeTree* x = new hkpBvCompressedMeshShapeTree;

	x->base = *hkcdStaticMeshTreehkcdStaticMeshTreeCommonConfigunsignedintunsignedlonglong1121hkpBvCompressedMeshShapeTreeDataRun::hkcdStaticMeshTreehkcdStaticMeshTreeCommonConfigunsignedintunsignedlonglong1121hkpBvCompressedMeshShapeTreeDataRunRead(src);
	mseek(src,160,SEEK_CUR);

	return x;
};
