#pragma once
#include "hkcdStaticTreeDefaultTreeStorage4.h"

hkcdStaticTreeDefaultTreeStorage4* hkcdStaticTreeDefaultTreeStorage4::hkcdStaticTreeDefaultTreeStorage4Read(MEM* src)
{
	hkcdStaticTreeDefaultTreeStorage4* x = new hkcdStaticTreeDefaultTreeStorage4;

	x->base = *hkcdStaticTreeTreehkcdStaticTreeDynamicStorage4::hkcdStaticTreeTreehkcdStaticTreeDynamicStorage4Read(src);
	mseek(src,48,SEEK_CUR);

	return x;
};
