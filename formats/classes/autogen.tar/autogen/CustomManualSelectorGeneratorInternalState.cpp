#pragma once
#include "CustomManualSelectorGeneratorInternalState.h"

CustomManualSelectorGeneratorInternalState* CustomManualSelectorGeneratorInternalState::CustomManualSelectorGeneratorInternalStateRead(MEM* src)
{
	CustomManualSelectorGeneratorInternalState* x = new CustomManualSelectorGeneratorInternalState;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->currentGeneratorIndex,1,1,src);
	mread(&x->generatorIndexAtActivate,1,1,src);
	mseek(src,6,SEEK_CUR);
	mread(&x->activeTransitions,sizeof(hkbStateMachineActiveTransitionInfo),1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
