#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkbHandIkControlsModifierHand
{
	public:
	hkbHandIkControlData controlData;
	int handIndex;
	bool enable;

	static hkbHandIkControlsModifierHand* hkbHandIkControlsModifierHandRead(MEM* src);
};
