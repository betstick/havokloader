#pragma once
#include "hkbRocketboxCharacterController.h"

hkbRocketboxCharacterController* hkbRocketboxCharacterController::hkbRocketboxCharacterControllerRead(MEM* src)
{
	hkbRocketboxCharacterController* x = new hkbRocketboxCharacterController;

	x->base = *hkbModifier::hkbModifierRead(src);
	mread(&x->child,8,1,src);
	mread(&x->autoTurnsAllowed,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->desiredAIMovementMode,4,1,src);
	mread(&x->effectiveLinearSpeed,4,1,src);
	mread(&x->effectiveAngularSpeed,4,1,src);
	mread(&x->effectiveHorizontalAim,4,1,src);
	mread(&x->effectiveVerticalAim,4,1,src);
	mread(&x->torsoTiltAngle,4,1,src);
	mread(&x->desiredAIMovementSpeed,4,1,src);
	mread(&x->currentMaximumSpeed,4,1,src);
	mread(&x->stopRequest,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->idleToMoveAnimIdx,4,1,src);
	mread(&x->linearSpeed,4,1,src);
	mread(&x->angularSpeed,4,1,src);
	mread(&x->horizontalAim,4,1,src);
	mread(&x->verticalAim,4,1,src);
	mread(&x->rotationAllowed,1,1,src);
	mread(&x->poseChangeAllowed,1,1,src);
	mread(&x->modifyLinearSpeed,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->poseIdx,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->leftFootDownEvent,sizeof(hkbEventProperty),1,src);
	mread(&x->rightFootDownEvent,sizeof(hkbEventProperty),1,src);
	mread(&x->immediateStopEvent,sizeof(hkbEventProperty),1,src);
	mread(&x->rapidTurnEvent,sizeof(hkbEventProperty),1,src);
	mread(&x->changeMovementDirectionEvent,sizeof(hkbEventProperty),1,src);
	mread(&x->changePoseEvent,sizeof(hkbEventProperty),1,src);
	mread(&x->moveEvent,sizeof(hkbEventProperty),1,src);
	mread(&x->stopEvent,sizeof(hkbEventProperty),1,src);
	mread(&x->characterHasHalted,sizeof(hkbEventProperty),1,src);
	mread(&x->moveVelocities,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->rapidTurnRequest,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->currPose,4,1,src);
	mread(&x->prevPose,4,1,src);
	mread(&x->noVelocityTimer,4,1,src);
	mread(&x->linearSpeedModifier,4,1,src);
	mread(&x->characterAngle,4,1,src);
	mread(&x->plantedFootIdx,4,1,src);
	mread(&x->timeStep,4,1,src);
	mseek(src,88,SEEK_CUR);

	return x;
};
