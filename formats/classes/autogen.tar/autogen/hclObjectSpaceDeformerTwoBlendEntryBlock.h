#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hclObjectSpaceDeformerTwoBlendEntryBlock
{
	public:
	unsigned short vertexIndices;
	unsigned short boneIndices;
	unsigned char boneWeights;

	static hclObjectSpaceDeformerTwoBlendEntryBlock* hclObjectSpaceDeformerTwoBlendEntryBlockRead(MEM* src);
};
