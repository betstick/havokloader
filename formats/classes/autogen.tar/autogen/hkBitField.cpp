#pragma once
#include "hkBitField.h"

hkBitField* hkBitField::hkBitFieldRead(MEM* src)
{
	hkBitField* x = new hkBitField;

	x->base = *hkBitFieldBasehkBitFieldStoragehkArrayunsignedinthkContainerHeapAllocator::hkBitFieldBasehkBitFieldStoragehkArrayunsignedinthkContainerHeapAllocatorRead(src);
	mseek(src,24,SEEK_CUR);

	return x;
};
