#pragma once
#include "hkbDelayedModifier.h"

hkbDelayedModifier* hkbDelayedModifier::hkbDelayedModifierRead(MEM* src)
{
	hkbDelayedModifier* x = new hkbDelayedModifier;

	x->base = *hkbModifierWrapper::hkbModifierWrapperRead(src);
	mread(&x->delaySeconds,4,1,src);
	mread(&x->durationSeconds,4,1,src);
	mread(&x->secondsElapsed,4,1,src);
	mread(&x->isActive,1,1,src);
	mseek(src,3,SEEK_CUR);
	mseek(src,96,SEEK_CUR);

	return x;
};
