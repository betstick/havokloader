#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "CustomMeshParameter.h"

class CustomMeshTriangleParameter
{
	public:
	CustomMeshParameter base;
	TYPE_SIMPLEARRAY triangleDataBuffer;
	int triangleDataStride;

	static CustomMeshTriangleParameter* CustomMeshTriangleParameterRead(MEM* src);
};
