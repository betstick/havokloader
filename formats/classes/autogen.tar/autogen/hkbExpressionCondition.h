#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbCondition.h"

class hkbExpressionCondition
{
	public:
	hkbCondition base;
	unsigned long expression;
	unsigned long compiledExpressionSet;

	static hkbExpressionCondition* hkbExpressionConditionRead(MEM* src);
};
