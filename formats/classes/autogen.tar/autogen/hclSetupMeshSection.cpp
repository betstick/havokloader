#pragma once
#include "hclSetupMeshSection.h"

hclSetupMeshSection* hclSetupMeshSection::hclSetupMeshSectionRead(MEM* src)
{
	hclSetupMeshSection* x = new hclSetupMeshSection;

	mseek(src,8,SEEK_CUR);

	return x;
};
