#pragma once
#include "hkpSerializedDisplayRbTransformsDisplayTransformPair.h"

hkpSerializedDisplayRbTransformsDisplayTransformPair* hkpSerializedDisplayRbTransformsDisplayTransformPair::hkpSerializedDisplayRbTransformsDisplayTransformPairRead(MEM* src)
{
	hkpSerializedDisplayRbTransformsDisplayTransformPair* x = new hkpSerializedDisplayRbTransformsDisplayTransformPair;

	mread(&x->rb,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->localToDisplay,sizeof(TYPE_TRANSFORM),1,src);

	return x;
};
