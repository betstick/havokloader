#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpConvexShape.h"
enum RayHitType
{
	HIT_CAP0 = 0,
	HIT_CAP1 = 1,
	HIT_BODY = 2,
};

class hkpCapsuleShape
{
	public:
	hkpConvexShape base;
	vec4 vertexA;
	vec4 vertexB;

	static hkpCapsuleShape* hkpCapsuleShapeRead(MEM* src);
};
