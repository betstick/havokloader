#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpAction.h"

class hkpConstraintChainInstanceAction
{
	public:
	hkpAction base;
	unsigned long constraintInstance;

	static hkpConstraintChainInstanceAction* hkpConstraintChainInstanceActionRead(MEM* src);
};
