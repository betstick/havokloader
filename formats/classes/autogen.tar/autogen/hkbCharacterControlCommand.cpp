#pragma once
#include "hkbCharacterControlCommand.h"

hkbCharacterControlCommand* hkbCharacterControlCommand::hkbCharacterControlCommandRead(MEM* src)
{
	hkbCharacterControlCommand* x = new hkbCharacterControlCommand;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->characterId,8,1,src);
	mread(&x->command,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->padding,4,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
