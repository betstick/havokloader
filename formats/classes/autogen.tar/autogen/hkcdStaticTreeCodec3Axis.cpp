#pragma once
#include "hkcdStaticTreeCodec3Axis.h"

hkcdStaticTreeCodec3Axis* hkcdStaticTreeCodec3Axis::hkcdStaticTreeCodec3AxisRead(MEM* src)
{
	hkcdStaticTreeCodec3Axis* x = new hkcdStaticTreeCodec3Axis;

	mread(&x->xyz,1,1,src);
	mseek(src,2,SEEK_CUR);

	return x;
};
