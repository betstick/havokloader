#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkaiEdgeGeometryFace
{
	public:
	unsigned int data;
	unsigned int faceIndex;
	TYPE_FLAGS flags;

	static hkaiEdgeGeometryFace* hkaiEdgeGeometryFaceRead(MEM* src);
};
