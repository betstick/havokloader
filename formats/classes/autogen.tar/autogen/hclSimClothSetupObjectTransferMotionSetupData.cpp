#pragma once
#include "hclSimClothSetupObjectTransferMotionSetupData.h"

hclSimClothSetupObjectTransferMotionSetupData* hclSimClothSetupObjectTransferMotionSetupData::hclSimClothSetupObjectTransferMotionSetupDataRead(MEM* src)
{
	hclSimClothSetupObjectTransferMotionSetupData* x = new hclSimClothSetupObjectTransferMotionSetupData;

	mread(&x->transferMotionTransformSetSetup,8,1,src);
	mread(&x->transferMotionTransformName,8,1,src);
	mread(&x->transferTranslationMotion,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->minTranslationSpeed,4,1,src);
	mread(&x->maxTranslationSpeed,4,1,src);
	mread(&x->minTranslationBlend,4,1,src);
	mread(&x->maxTranslationBlend,4,1,src);
	mread(&x->transferRotationMotion,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->minRotationSpeed,4,1,src);
	mread(&x->maxRotationSpeed,4,1,src);
	mread(&x->minRotationBlend,4,1,src);
	mread(&x->maxRotationBlend,4,1,src);

	return x;
};
