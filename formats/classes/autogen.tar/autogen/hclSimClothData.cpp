#pragma once
#include "hclSimClothData.h"

hclSimClothData* hclSimClothData::hclSimClothDataRead(MEM* src)
{
	hclSimClothData* x = new hclSimClothData;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->simulationInfo,sizeof(hclSimClothDataOverridableSimulationInfo),1,src);
	mread(&x->name,8,1,src);
	mread(&x->particleDatas,sizeof(hclSimClothDataParticleData),1,src);
	mread(&x->fixedParticles,2,1,src);
	mseek(src,14,SEEK_CUR);
	mread(&x->triangleIndices,2,1,src);
	mseek(src,14,SEEK_CUR);
	mread(&x->triangleFlips,1,1,src);
	mseek(src,15,SEEK_CUR);
	mread(&x->totalMass,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->collidableTransformMap,sizeof(hclSimClothDataCollidableTransformMap),1,src);
	mread(&x->perInstanceCollidables,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->staticConstraintSets,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->antiPinchConstraintSets,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->simClothPoses,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->actions,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->staticCollisionMasks,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->perParticlePinchDetectionEnabledFlags,1,1,src);
	mseek(src,15,SEEK_CUR);
	mread(&x->collidablePinchingDatas,sizeof(hclSimClothDataCollidablePinchingData),1,src);
	mread(&x->minPinchedParticleIndex,2,1,src);
	mread(&x->maxPinchedParticleIndex,2,1,src);
	mread(&x->maxCollisionPairs,4,1,src);
	mread(&x->maxParticleRadius,4,1,src);
	mread(&x->landscapeCollisionData,sizeof(hclSimClothDataLandscapeCollisionData),1,src);
	mread(&x->numLandscapeCollidableParticles,4,1,src);
	mread(&x->doNormals,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->transferMotionData,sizeof(hclSimClothDataTransferMotionData),1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
