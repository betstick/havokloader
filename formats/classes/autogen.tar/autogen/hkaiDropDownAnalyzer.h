#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkaiTraversalAnalyzer.h"

class hkaiDropDownAnalyzer
{
	public:
	hkaiTraversalAnalyzer base;
	float minDropDistance;
	float maxDropDistance;
	float maxUnderhang;
	float verticalLipHeight;

	static hkaiDropDownAnalyzer* hkaiDropDownAnalyzerRead(MEM* src);
};
