#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkpSerializedDisplayMarker
{
	public:
	hkReferencedObject base;
	TYPE_TRANSFORM transform;

	static hkpSerializedDisplayMarker* hkpSerializedDisplayMarkerRead(MEM* src);
};
