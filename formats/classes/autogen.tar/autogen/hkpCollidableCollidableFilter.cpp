#pragma once
#include "hkpCollidableCollidableFilter.h"

hkpCollidableCollidableFilter* hkpCollidableCollidableFilter::hkpCollidableCollidableFilterRead(MEM* src)
{
	hkpCollidableCollidableFilter* x = new hkpCollidableCollidableFilter;

	mseek(src,8,SEEK_CUR);

	return x;
};
