#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbCustomTestGeneratorBoneTypes.h"

class hkbCustomTestGeneratorAnnotatedTypes
{
	public:
	hkbCustomTestGeneratorBoneTypes base;
	TYPE_CSTRING annotatedTypeCStringFilename;
	unsigned long annotatedTypeHkStringPtrFilename;
	TYPE_CSTRING annotatedTypeCStringScript;
	unsigned long annotatedTypeHkStringPtrScript;
	TYPE_CSTRING annotatedTypeCStringBoneAttachment;
	unsigned long annotatedTypeHkStringPtrBoneAttachment;
	TYPE_CSTRING annotatedTypeCStringLocalFrame;
	unsigned long annotatedTypeHkStringPtrLocalFrame;
	bool annotatedHiddenTypeCopyStart;
	int annotatedTypeHkInt32EventID;
	int annotatedTypeHkInt32VariableIndex;
	int annotatedTypeHkInt32AttributeIndex;
	float annotatedTypeHkRealTime;
	bool annotatedTypeBoolNoVar;
	bool annotatedTypeHkBoolNoVar;
	signed char annotatedTypeHkInt8NoVar;
	short annotatedTypeHkInt16NoVar;
	int annotatedTypeHkInt32NoVar;
	unsigned char annotatedTypeHkUint8NoVar;
	unsigned short annotatedTypeHkUint16NoVar;
	unsigned int annotatedTypeHkUint32NoVar;
	float annotatedTypeHkRealNoVar;
	bool annotatedTypeBoolOutput;
	bool annotatedTypeHkBoolOutput;
	signed char annotatedTypeHkInt8Output;
	short annotatedTypeHkInt16Output;
	int annotatedTypeHkInt32Output;
	unsigned char annotatedTypeHkUint8Output;
	unsigned short annotatedTypeHkUint16Output;
	unsigned int annotatedTypeHkUint32Output;
	float annotatedTypeHkRealOutput;
	bool annotatedHiddenTypeBool;
	bool annotatedHiddenTypeHkBool;
	TYPE_CSTRING annotatedHiddenTypeCString1;
	unsigned long annotatedHiddenTypeHkStringPtr1;
	TYPE_CSTRING annotatedHiddenTypeCString2;
	unsigned long annotatedHiddenTypeHkStringPtr2;
	signed char annotatedHiddenTypeHkInt8;
	short annotatedHiddenTypeHkInt16;
	int annotatedHiddenTypeHkInt32;
	unsigned char annotatedHiddenTypeHkUint8;
	unsigned short annotatedHiddenTypeHkUint16;
	unsigned int annotatedHiddenTypeHkUint32;
	bool annotatedHiddenTypeCopyEnd;

	static hkbCustomTestGeneratorAnnotatedTypes* hkbCustomTestGeneratorAnnotatedTypesRead(MEM* src);
};
