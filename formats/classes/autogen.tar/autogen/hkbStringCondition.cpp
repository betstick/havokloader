#pragma once
#include "hkbStringCondition.h"

hkbStringCondition* hkbStringCondition::hkbStringConditionRead(MEM* src)
{
	hkbStringCondition* x = new hkbStringCondition;

	x->base = *hkbCondition::hkbConditionRead(src);
	mread(&x->conditionString,8,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
