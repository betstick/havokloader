#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbGenerator.h"

class hkbPinBonesGenerator
{
	public:
	hkbGenerator base;
	unsigned long referenceFrameGenerator;
	unsigned long pinnedGenerator;
	unsigned long boneIndices;
	float fraction;

	static hkbPinBonesGenerator* hkbPinBonesGeneratorRead(MEM* src);
};
