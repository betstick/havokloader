#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbCustomTestGeneratorComplexTypes.h"

class hkbCustomTestGeneratorNestedTypesBase
{
	public:
	hkbCustomTestGeneratorComplexTypes base;
	unsigned long nestedTypeHkbGeneratorPtr;
	unsigned long nestedTypeHkbGeneratorRefPtr;
	unsigned long nestedTypeHkbModifierPtr;
	unsigned long nestedTypeHkbModifierRefPtr;
	unsigned long nestedTypeHkbCustomIdSelectorPtr;
	unsigned long nestedTypeHkbCustomIdSelectorRefPtr;
	bool* nestedTypeArrayBool;
	bool* nestedTypeArrayHkBool;
	TYPE_CSTRING* nestedTypeArrayCString;
	unsigned long* nestedTypeArrayHkStringPtr;
	signed char* nestedTypeArrayHkInt8;
	short* nestedTypeArrayHkInt16;
	int* nestedTypeArrayHkInt32;
	unsigned char* nestedTypeArrayHkUint8;
	unsigned short* nestedTypeArrayHkUint16;
	unsigned int* nestedTypeArrayHkUint32;
	float* nestedTypeArrayHkReal;
	unsigned long* nestedTypeArrayHkbGeneratorPtr;
	unsigned long* nestedTypeArrayHkbGeneratorRefPtr;
	unsigned long* nestedTypeArrayHkbModifierPtr;
	unsigned long* nestedTypeArrayHkbModifierRefPtr;
	unsigned long* nestedTypeArrayHkbCustomIdSelectorPtr;
	unsigned long* nestedTypeArrayHkbCustomIdSelectorRefPtr;

	static hkbCustomTestGeneratorNestedTypesBase* hkbCustomTestGeneratorNestedTypesBaseRead(MEM* src);
};
