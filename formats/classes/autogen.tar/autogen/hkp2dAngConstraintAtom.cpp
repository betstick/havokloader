#pragma once
#include "hkp2dAngConstraintAtom.h"

hkp2dAngConstraintAtom* hkp2dAngConstraintAtom::hkp2dAngConstraintAtomRead(MEM* src)
{
	hkp2dAngConstraintAtom* x = new hkp2dAngConstraintAtom;

	x->base = *hkpConstraintAtom::hkpConstraintAtomRead(src);
	mread(&x->freeRotationAxis,1,1,src);
	mread(&x->padding,1,1,src);
	mseek(src,12,SEEK_CUR);
	mseek(src,2,SEEK_CUR);

	return x;
};
