#pragma once
#include "hclObjectSpaceMeshMeshDeformPNTOperator.h"

hclObjectSpaceMeshMeshDeformPNTOperator* hclObjectSpaceMeshMeshDeformPNTOperator::hclObjectSpaceMeshMeshDeformPNTOperatorRead(MEM* src)
{
	hclObjectSpaceMeshMeshDeformPNTOperator* x = new hclObjectSpaceMeshMeshDeformPNTOperator;

	x->base = *hclObjectSpaceMeshMeshDeformOperator::hclObjectSpaceMeshMeshDeformOperatorRead(src);
	mread(&x->localPNTs,sizeof(hclObjectSpaceDeformerLocalBlockPNT),1,src);
	mread(&x->localUnpackedPNTs,sizeof(hclObjectSpaceDeformerLocalBlockUnpackedPNT),1,src);
	mseek(src,168,SEEK_CUR);

	return x;
};
