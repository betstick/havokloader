#pragma once
#include "hkAabb.h"

hkAabb* hkAabb::hkAabbRead(MEM* src)
{
	hkAabb* x = new hkAabb;

	mread(&x->min,16,1,src);
	mread(&x->max,16,1,src);

	return x;
};
