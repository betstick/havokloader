#pragma once
#include "hclStorageSetupMeshSectionSectionVertexFloatChannel.h"

hclStorageSetupMeshSectionSectionVertexFloatChannel* hclStorageSetupMeshSectionSectionVertexFloatChannel::hclStorageSetupMeshSectionSectionVertexFloatChannelRead(MEM* src)
{
	hclStorageSetupMeshSectionSectionVertexFloatChannel* x = new hclStorageSetupMeshSectionSectionVertexFloatChannel;

	x->base = *hclStorageSetupMeshSectionSectionVertexChannel::hclStorageSetupMeshSectionSectionVertexChannelRead(src);
	mread(&x->vertexFloats,4,1,src);
	mseek(src,12,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
