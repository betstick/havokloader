#pragma once
#include "hknpWorldCinfo.h"

hknpWorldCinfo* hknpWorldCinfo::hknpWorldCinfoRead(MEM* src)
{
	hknpWorldCinfo* x = new hknpWorldCinfo;

	mread(&x->bodyBufferCapacity,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->userBodyBuffer,8,1,src);
	mread(&x->motionBufferCapacity,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->userMotionBuffer,8,1,src);
	mread(&x->constraintBufferCapacity,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->userConstraintBuffer,8,1,src);
	mread(&x->persistentStreamAllocator,8,1,src);
	mread(&x->materialLibrary,8,1,src);
	mread(&x->motionPropertiesLibrary,8,1,src);
	mread(&x->qualityLibrary,8,1,src);
	mread(&x->simulationType,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->numSplitterCells,4,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->gravity,16,1,src);
	mread(&x->enableContactCaching,1,1,src);
	mread(&x->mergeEventsBeforeDispatch,1,1,src);
	mread(&x->leavingBroadPhaseBehavior,1,1,src);
	mseek(src,13,SEEK_CUR);
	mread(&x->broadPhaseAabb,sizeof(hkAabb),1,src);
	mread(&x->broadPhaseConfig,8,1,src);
	mread(&x->collisionFilter,8,1,src);
	mread(&x->shapeTagCodec,8,1,src);
	mread(&x->collisionTolerance,4,1,src);
	mread(&x->relativeCollisionAccuracy,4,1,src);
	mread(&x->enableWeldingForDefaultObjects,1,1,src);
	mread(&x->enableWeldingForCriticalObjects,1,1,src);
	mseek(src,2,SEEK_CUR);
	mread(&x->solverTau,4,1,src);
	mread(&x->solverDamp,4,1,src);
	mread(&x->solverIterations,4,1,src);
	mread(&x->solverMicrosteps,4,1,src);
	mread(&x->defaultSolverTimestep,4,1,src);
	mread(&x->maxApproachSpeedForHighQualitySolver,4,1,src);
	mread(&x->enableDeactivation,1,1,src);
	mread(&x->deleteCachesOnDeactivation,1,1,src);
	mseek(src,2,SEEK_CUR);
	mread(&x->largeIslandSize,4,1,src);
	mread(&x->enableSolverDynamicScheduling,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->contactSolverType,4,1,src);
	mread(&x->unitScale,4,1,src);
	mread(&x->applyUnitScaleToStaticConstants,1,1,src);
	mseek(src,15,SEEK_CUR);

	return x;
};
