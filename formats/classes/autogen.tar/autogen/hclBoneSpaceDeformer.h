#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
enum ControlByte
{
	FOUR_BLEND = 0,
	THREE_BLEND = 1,
	TWO_BLEND = 2,
	ONE_BLEND = 3,
	NEXT_SPU_BATCH = 4,
};

class hclBoneSpaceDeformer
{
	public:
	hclBoneSpaceDeformerFourBlendEntryBlock* fourBlendEntries;
	hclBoneSpaceDeformerThreeBlendEntryBlock* threeBlendEntries;
	hclBoneSpaceDeformerTwoBlendEntryBlock* twoBlendEntries;
	hclBoneSpaceDeformerOneBlendEntryBlock* oneBlendEntries;
	unsigned char* controlBytes;
	unsigned short startVertexIndex;
	unsigned short endVertexIndex;
	unsigned short batchSizeSpu;
	bool partialWrite;

	static hclBoneSpaceDeformer* hclBoneSpaceDeformerRead(MEM* src);
};
