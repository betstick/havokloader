#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkbAiControlControlDataBlendable
{
	public:
	float desiredSpeed;
	float maximumSpeed;

	static hkbAiControlControlDataBlendable* hkbAiControlControlDataBlendableRead(MEM* src);
};
