#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hknpVehicleBrake
{
	public:
	hkReferencedObject base;

	static hknpVehicleBrake* hknpVehicleBrakeRead(MEM* src);
};
