#pragma once
#include "hkaiUserEdgeUtils.h"

hkaiUserEdgeUtils* hkaiUserEdgeUtils::hkaiUserEdgeUtilsRead(MEM* src)
{
	hkaiUserEdgeUtils* x = new hkaiUserEdgeUtils;

	mseek(src,1,SEEK_CUR);

	return x;
};
