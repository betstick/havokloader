#pragma once
#include "hknpVehicleDefaultSuspensionWheelSpringSuspensionParameters.h"

hknpVehicleDefaultSuspensionWheelSpringSuspensionParameters* hknpVehicleDefaultSuspensionWheelSpringSuspensionParameters::hknpVehicleDefaultSuspensionWheelSpringSuspensionParametersRead(MEM* src)
{
	hknpVehicleDefaultSuspensionWheelSpringSuspensionParameters* x = new hknpVehicleDefaultSuspensionWheelSpringSuspensionParameters;

	mread(&x->strength,4,1,src);
	mread(&x->dampingCompression,4,1,src);
	mread(&x->dampingRelaxation,4,1,src);

	return x;
};
