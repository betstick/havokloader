#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"
enum VertexChannelType
{
	HCL_VERTEX_CHANNEL_INVALID = 0,
	HCL_VERTEX_CHANNEL_FLOAT = 1,
	HCL_VERTEX_CHANNEL_DISTANCE = 2,
	HCL_VERTEX_CHANNEL_ANGLE = 3,
	HCL_VERTEX_CHANNEL_SELECTION = 4,
};
enum TriangleChannelType
{
	HCL_TRIANGLE_CHANNEL_INVALID = 0,
	HCL_TRIANGLE_CHANNEL_SELECTION = 1,
};
enum EdgeChannelType
{
	HCL_EDGE_CHANNEL_INVALID = 0,
	HCL_EDGE_CHANNEL_SELECTION = 1,
};

class hclSetupMesh
{
	public:
	hkReferencedObject base;

	static hclSetupMesh* hclSetupMeshRead(MEM* src);
};
