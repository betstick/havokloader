#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkcdStaticTreeDefaultTreeStorage6.h"

class hknpStaticCompoundShapeTree
{
	public:
	hkcdStaticTreeDefaultTreeStorage6 base;

	static hknpStaticCompoundShapeTree* hknpStaticCompoundShapeTreeRead(MEM* src);
};
