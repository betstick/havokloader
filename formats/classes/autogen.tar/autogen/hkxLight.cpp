#pragma once
#include "hkxLight.h"

hkxLight* hkxLight::hkxLightRead(MEM* src)
{
	hkxLight* x = new hkxLight;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->type,1,1,src);
	mseek(src,15,SEEK_CUR);
	mread(&x->position,16,1,src);
	mread(&x->direction,16,1,src);
	mread(&x->color,4,1,src);
	mread(&x->angle,4,1,src);
	mread(&x->range,4,1,src);
	mread(&x->fadeStart,4,1,src);
	mread(&x->fadeEnd,4,1,src);
	mread(&x->decayRate,2,1,src);
	mseek(src,2,SEEK_CUR);
	mread(&x->intensity,4,1,src);
	mread(&x->shadowCaster,1,1,src);
	mseek(src,3,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
