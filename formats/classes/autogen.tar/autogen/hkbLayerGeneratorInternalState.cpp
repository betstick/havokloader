#pragma once
#include "hkbLayerGeneratorInternalState.h"

hkbLayerGeneratorInternalState* hkbLayerGeneratorInternalState::hkbLayerGeneratorInternalStateRead(MEM* src)
{
	hkbLayerGeneratorInternalState* x = new hkbLayerGeneratorInternalState;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->numActiveLayers,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->layerInternalStates,sizeof(hkbLayerGeneratorLayerInternalState),1,src);
	mread(&x->initSync,1,1,src);
	mseek(src,7,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
