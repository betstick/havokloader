#pragma once
#include "hknpConstraintCollisionFilter.h"

hknpConstraintCollisionFilter* hknpConstraintCollisionFilter::hknpConstraintCollisionFilterRead(MEM* src)
{
	hknpConstraintCollisionFilter* x = new hknpConstraintCollisionFilter;

	x->base = *hknpPairCollisionFilter::hknpPairCollisionFilterRead(src);
	mread(&x->subscribedWorld,8,1,src);
	mseek(src,48,SEEK_CUR);

	return x;
};
