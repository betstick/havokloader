#pragma once
#include "hclClothData.h"

hclClothData* hclClothData::hclClothDataRead(MEM* src)
{
	hclClothData* x = new hclClothData;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->name,8,1,src);
	mread(&x->simClothDatas,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->bufferDefinitions,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->transformSetDefinitions,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->operators,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->clothStateDatas,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->actions,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->targetPlatform,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
