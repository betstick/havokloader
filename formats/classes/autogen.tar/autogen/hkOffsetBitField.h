#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkBitFieldBasehkOffsetBitFieldStoragehkArrayunsignedinthkContainerHeapAllocator.h"

class hkOffsetBitField
{
	public:
	hkBitFieldBasehkOffsetBitFieldStoragehkArrayunsignedinthkContainerHeapAllocator base;

	static hkOffsetBitField* hkOffsetBitFieldRead(MEM* src);
};
