#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkaiAgentTraversalInfo
{
	public:
	float diameter;
	unsigned int filterInfo;

	static hkaiAgentTraversalInfo* hkaiAgentTraversalInfoRead(MEM* src);
};
