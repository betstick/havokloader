#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkcdStaticTreeTreehkcdStaticTreeDynamicStorage4.h"

class hkcdStaticTreeDefaultTreeStorage4
{
	public:
	hkcdStaticTreeTreehkcdStaticTreeDynamicStorage4 base;

	static hkcdStaticTreeDefaultTreeStorage4* hkcdStaticTreeDefaultTreeStorage4Read(MEM* src);
};
