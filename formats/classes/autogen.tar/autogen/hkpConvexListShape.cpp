#pragma once
#include "hkpConvexListShape.h"

hkpConvexListShape* hkpConvexListShape::hkpConvexListShapeRead(MEM* src)
{
	hkpConvexListShape* x = new hkpConvexListShape;

	x->base = *hkpConvexShape::hkpConvexShapeRead(src);
	mread(&x->minDistanceToUseConvexHullForGetClosestPoints,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->aabbHalfExtents,16,1,src);
	mread(&x->aabbCenter,16,1,src);
	mread(&x->useCachedAabb,1,1,src);
	mseek(src,7,SEEK_CUR);
	mread(&x->childShapes,8,1,src);
	mseek(src,16,SEEK_CUR);
	mseek(src,48,SEEK_CUR);

	return x;
};
