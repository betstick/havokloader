#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkbCharacterControllerModifierControlData
{
	public:
	float verticalGain;
	float horizontalCatchUpGain;
	float maxVerticalSeparation;
	float maxHorizontalSeparation;

	static hkbCharacterControllerModifierControlData* hkbCharacterControllerModifierControlDataRead(MEM* src);
};
