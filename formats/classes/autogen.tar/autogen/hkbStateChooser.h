#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbStateChooser
{
	public:
	hkReferencedObject base;

	static hkbStateChooser* hkbStateChooserRead(MEM* src);
};
