#pragma once
#include "hkaiEdgePathFollowingCornerInfo.h"

hkaiEdgePathFollowingCornerInfo* hkaiEdgePathFollowingCornerInfo::hkaiEdgePathFollowingCornerInfoRead(MEM* src)
{
	hkaiEdgePathFollowingCornerInfo* x = new hkaiEdgePathFollowingCornerInfo;

	mread(&x->data,2,1,src);

	return x;
};
