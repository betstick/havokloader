#pragma once
#include "hkbBlendingTransitionEffect.h"

hkbBlendingTransitionEffect* hkbBlendingTransitionEffect::hkbBlendingTransitionEffectRead(MEM* src)
{
	hkbBlendingTransitionEffect* x = new hkbBlendingTransitionEffect;

	x->base = *hkbTransitionEffect::hkbTransitionEffectRead(src);
	mread(&x->duration,4,1,src);
	mread(&x->toGeneratorStartTimeFraction,4,1,src);
	mread(&x->flags,sizeof(TYPE_FLAGS),1,src);
	mread(&x->endMode,1,1,src);
	mread(&x->blendCurve,1,1,src);
	mread(&x->alignmentBone,2,1,src);
	mseek(src,10,SEEK_CUR);
	mread(&x->fromPos,16,1,src);
	mread(&x->fromRot,sizeof(TYPE_QUATERNION),1,src);
	mread(&x->toPos,16,1,src);
	mread(&x->toRot,sizeof(TYPE_QUATERNION),1,src);
	mread(&x->lastPos,16,1,src);
	mread(&x->lastRot,sizeof(TYPE_QUATERNION),1,src);
	mread(&x->characterPoseAtBeginningOfTransition,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->timeRemaining,4,1,src);
	mread(&x->timeInTransition,4,1,src);
	mread(&x->toGeneratorSelfTranstitionMode,1,1,src);
	mread(&x->initializeCharacterPose,1,1,src);
	mread(&x->alignThisFrame,1,1,src);
	mread(&x->alignmentFinished,1,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,168,SEEK_CUR);

	return x;
};
