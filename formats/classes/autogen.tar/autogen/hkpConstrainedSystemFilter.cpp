#pragma once
#include "hkpConstrainedSystemFilter.h"

hkpConstrainedSystemFilter* hkpConstrainedSystemFilter::hkpConstrainedSystemFilterRead(MEM* src)
{
	hkpConstrainedSystemFilter* x = new hkpConstrainedSystemFilter;

	x->base = *hkpCollisionFilter::hkpCollisionFilterRead(src);
	mread(&x->otherFilter,8,1,src);
	mseek(src,80,SEEK_CUR);

	return x;
};
