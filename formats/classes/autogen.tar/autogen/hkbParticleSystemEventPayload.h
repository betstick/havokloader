#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbEventPayload.h"
enum SystemType
{
	DEBRIS = 0,
	DUST = 1,
	EXPLOSION = 2,
	SMOKE = 3,
	SPARKS = 4,
};

class hkbParticleSystemEventPayload
{
	public:
	hkbEventPayload base;
	unsigned char type;
	short emitBoneIndex;
	vec4 offset;
	vec4 direction;
	int numParticles;
	float speed;

	static hkbParticleSystemEventPayload* hkbParticleSystemEventPayloadRead(MEM* src);
};
