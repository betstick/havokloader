#pragma once
#include "hkaiSilhouetteReferenceFrame.h"

hkaiSilhouetteReferenceFrame* hkaiSilhouetteReferenceFrame::hkaiSilhouetteReferenceFrameRead(MEM* src)
{
	hkaiSilhouetteReferenceFrame* x = new hkaiSilhouetteReferenceFrame;

	mread(&x->up,16,1,src);
	mread(&x->referenceAxis,16,1,src);
	mread(&x->orthogonalAxis,16,1,src);

	return x;
};
