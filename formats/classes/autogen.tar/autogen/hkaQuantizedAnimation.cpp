#pragma once
#include "hkaQuantizedAnimation.h"

hkaQuantizedAnimation* hkaQuantizedAnimation::hkaQuantizedAnimationRead(MEM* src)
{
	hkaQuantizedAnimation* x = new hkaQuantizedAnimation;

	x->base = *hkaAnimation::hkaAnimationRead(src);
	mread(&x->data,1,1,src);
	mseek(src,15,SEEK_CUR);
	mread(&x->endian,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->skeleton,8,1,src);
	mseek(src,56,SEEK_CUR);

	return x;
};
