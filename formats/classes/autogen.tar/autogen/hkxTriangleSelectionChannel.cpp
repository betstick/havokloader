#pragma once
#include "hkxTriangleSelectionChannel.h"

hkxTriangleSelectionChannel* hkxTriangleSelectionChannel::hkxTriangleSelectionChannelRead(MEM* src)
{
	hkxTriangleSelectionChannel* x = new hkxTriangleSelectionChannel;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->selectedTriangles,4,1,src);
	mseek(src,12,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
