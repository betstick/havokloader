#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbRagdollInterface.h"

class hkbnpRagdollInterface
{
	public:
	hkbRagdollInterface base;
	unsigned long physicsInterface;
	unsigned long ragdoll;
	unsigned long* scaledObjects;
	unsigned long* rigidBodyHandles;
	bool addedToWorld;

	static hkbnpRagdollInterface* hkbnpRagdollInterfaceRead(MEM* src);
};
