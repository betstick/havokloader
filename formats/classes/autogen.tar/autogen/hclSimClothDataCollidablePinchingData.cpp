#pragma once
#include "hclSimClothDataCollidablePinchingData.h"

hclSimClothDataCollidablePinchingData* hclSimClothDataCollidablePinchingData::hclSimClothDataCollidablePinchingDataRead(MEM* src)
{
	hclSimClothDataCollidablePinchingData* x = new hclSimClothDataCollidablePinchingData;

	mread(&x->pinchDetectionEnabled,1,1,src);
	mread(&x->pinchDetectionPriority,1,1,src);
	mseek(src,2,SEEK_CUR);
	mread(&x->pinchDetectionRadius,4,1,src);

	return x;
};
