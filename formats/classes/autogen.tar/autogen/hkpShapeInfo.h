#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkpShapeInfo
{
	public:
	hkReferencedObject base;
	unsigned long shape;
	bool isHierarchicalCompound;
	bool hkdShapesCollected;
	unsigned long* childShapeNames;
	TYPE_TRANSFORM* childTransforms;
	TYPE_TRANSFORM transform;

	static hkpShapeInfo* hkpShapeInfoRead(MEM* src);
};
