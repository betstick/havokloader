#pragma once
#include "hkxVertexFloatDataChannel.h"

hkxVertexFloatDataChannel* hkxVertexFloatDataChannel::hkxVertexFloatDataChannelRead(MEM* src)
{
	hkxVertexFloatDataChannel* x = new hkxVertexFloatDataChannel;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->perVertexFloats,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->dimensions,1,1,src);
	mseek(src,7,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
