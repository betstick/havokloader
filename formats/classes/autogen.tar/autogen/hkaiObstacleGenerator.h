#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkaiObstacleGenerator
{
	public:
	hkReferencedObject base;
	bool useSpheres;
	bool useBoundaries;
	bool clipBoundaries;
	TYPE_TRANSFORM transform;
	hkaiAvoidanceSolverSphereObstacle* spheres;
	hkaiAvoidanceSolverBoundaryObstacle* boundaries;
	unsigned long userData;

	static hkaiObstacleGenerator* hkaiObstacleGeneratorRead(MEM* src);
};
