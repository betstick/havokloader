#pragma once
#include "hkpConvexTranslateShape.h"

hkpConvexTranslateShape* hkpConvexTranslateShape::hkpConvexTranslateShapeRead(MEM* src)
{
	hkpConvexTranslateShape* x = new hkpConvexTranslateShape;

	x->base = *hkpConvexTransformShapeBase::hkpConvexTransformShapeBaseRead(src);
	mread(&x->translation,16,1,src);
	mseek(src,64,SEEK_CUR);

	return x;
};
