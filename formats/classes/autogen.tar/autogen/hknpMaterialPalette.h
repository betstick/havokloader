#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hknpMaterialPalette
{
	public:
	hkReferencedObject base;
	hknpMaterialDescriptor* entries;

	static hknpMaterialPalette* hknpMaterialPaletteRead(MEM* src);
};
