#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkaiNavVolumeInstance
{
	public:
	hkReferencedObject base;
	TYPE_SIMPLEARRAY originalCells;
	TYPE_SIMPLEARRAY originalEdges;
	unsigned long originalVolume;
	int* cellMap;
	hkaiNavVolumeInstanceCellInstance* instancedCells;
	hkaiNavVolumeEdge* ownedEdges;
	unsigned int sectionUid;
	int runtimeId;
	unsigned int layer;
	vec4 translation;

	static hkaiNavVolumeInstance* hkaiNavVolumeInstanceRead(MEM* src);
};
