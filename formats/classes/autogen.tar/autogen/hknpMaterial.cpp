#pragma once
#include "hknpMaterial.h"

hknpMaterial* hknpMaterial::hknpMaterialRead(MEM* src)
{
	hknpMaterial* x = new hknpMaterial;

	mread(&x->name,8,1,src);
	mread(&x->isExclusive,4,1,src);
	mread(&x->flags,4,1,src);
	mread(&x->triggerType,1,1,src);
	mread(&x->triggerManifoldTolerance,sizeof(hkUFloat8),1,src);
	mread(&x->dynamicFriction,sizeof(TYPE_HALF),1,src);
	mread(&x->staticFriction,sizeof(TYPE_HALF),1,src);
	mread(&x->restitution,sizeof(TYPE_HALF),1,src);
	mread(&x->frictionCombinePolicy,1,1,src);
	mread(&x->restitutionCombinePolicy,1,1,src);
	mread(&x->weldingTolerance,sizeof(TYPE_HALF),1,src);
	mread(&x->maxContactImpulse,4,1,src);
	mread(&x->fractionOfClippedImpulseToApply,4,1,src);
	mread(&x->massChangerCategory,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->massChangerHeavyObjectFactor,sizeof(TYPE_HALF),1,src);
	mread(&x->softContactForceFactor,sizeof(TYPE_HALF),1,src);
	mread(&x->softContactDampFactor,sizeof(TYPE_HALF),1,src);
	mread(&x->softContactSeperationVelocity,sizeof(hkUFloat8),1,src);
	mread(&x->surfaceVelocity,8,1,src);
	mread(&x->disablingCollisionsBetweenCvxCvxDynamicObjectsDistance,sizeof(TYPE_HALF),1,src);
	mread(&x->userData,8,1,src);
	mread(&x->isShared,1,1,src);
	mseek(src,7,SEEK_CUR);

	return x;
};
