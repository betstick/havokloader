#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkxMaterialProperty
{
	public:
	unsigned int key;
	unsigned int value;

	static hkxMaterialProperty* hkxMaterialPropertyRead(MEM* src);
};
