#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclConstraintSet.h"

class hclTransitionConstraintSet
{
	public:
	hclConstraintSet base;
	hclTransitionConstraintSetPerParticle* perParticleData;
	float toAnimPeriod;
	float toAnimPlusDelayPeriod;
	float toSimPeriod;
	float toSimPlusDelayPeriod;
	unsigned int referenceMeshBufferIdx;

	static hclTransitionConstraintSet* hclTransitionConstraintSetRead(MEM* src);
};
