#pragma once
#include "hclBendLinkConstraintSetMxBatch.h"

hclBendLinkConstraintSetMxBatch* hclBendLinkConstraintSetMxBatch::hclBendLinkConstraintSetMxBatchRead(MEM* src)
{
	hclBendLinkConstraintSetMxBatch* x = new hclBendLinkConstraintSetMxBatch;

	mread(&x->bendMinLengths,4,1,src);
	mseek(src,60,SEEK_CUR);
	mread(&x->stretchMaxLengths,4,1,src);
	mseek(src,60,SEEK_CUR);
	mread(&x->stretchStiffnesses,4,1,src);
	mseek(src,60,SEEK_CUR);
	mread(&x->bendStiffnesses,4,1,src);
	mseek(src,60,SEEK_CUR);
	mread(&x->invMassesA,4,1,src);
	mseek(src,60,SEEK_CUR);
	mread(&x->invMassesB,4,1,src);
	mseek(src,60,SEEK_CUR);
	mread(&x->particlesA,2,1,src);
	mseek(src,30,SEEK_CUR);
	mread(&x->particlesB,2,1,src);
	mseek(src,30,SEEK_CUR);

	return x;
};
