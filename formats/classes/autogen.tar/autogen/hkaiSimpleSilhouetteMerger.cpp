#pragma once
#include "hkaiSimpleSilhouetteMerger.h"

hkaiSimpleSilhouetteMerger* hkaiSimpleSilhouetteMerger::hkaiSimpleSilhouetteMergerRead(MEM* src)
{
	hkaiSimpleSilhouetteMerger* x = new hkaiSimpleSilhouetteMerger;

	x->base = *hkaiSilhouetteMerger::hkaiSilhouetteMergerRead(src);
	mseek(src,96,SEEK_CUR);

	return x;
};
