#pragma once
#include "hclObjectSpaceSkinPNTOperator.h"

hclObjectSpaceSkinPNTOperator* hclObjectSpaceSkinPNTOperator::hclObjectSpaceSkinPNTOperatorRead(MEM* src)
{
	hclObjectSpaceSkinPNTOperator* x = new hclObjectSpaceSkinPNTOperator;

	x->base = *hclObjectSpaceSkinOperator::hclObjectSpaceSkinOperatorRead(src);
	mread(&x->localPNTs,sizeof(hclObjectSpaceDeformerLocalBlockPNT),1,src);
	mread(&x->localUnpackedPNTs,sizeof(hclObjectSpaceDeformerLocalBlockUnpackedPNT),1,src);
	mseek(src,160,SEEK_CUR);

	return x;
};
