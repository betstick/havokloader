#pragma once
#include "hkpAabbPhantom.h"

hkpAabbPhantom* hkpAabbPhantom::hkpAabbPhantomRead(MEM* src)
{
	hkpAabbPhantom* x = new hkpAabbPhantom;

	x->base = *hkpPhantom::hkpPhantomRead(src);
	mread(&x->aabb,sizeof(hkAabb),1,src);
	mread(&x->overlappingCollidables,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->orderDirty,1,1,src);
	mseek(src,15,SEEK_CUR);
	mseek(src,240,SEEK_CUR);

	return x;
};
