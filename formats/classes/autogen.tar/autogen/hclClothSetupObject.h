#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hclClothSetupObject
{
	public:
	hkReferencedObject base;
	unsigned long name;
	unsigned long* bufferSetupObjects;
	unsigned long* transformSetSetupObjects;
	unsigned long* simClothSetupObjects;
	unsigned long* operatorSetupObjects;
	unsigned long* clothStateSetupObjects;

	static hclClothSetupObject* hclClothSetupObjectRead(MEM* src);
};
