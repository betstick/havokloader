#pragma once
#include "hclStretchLinkConstraintSetMxSingle.h"

hclStretchLinkConstraintSetMxSingle* hclStretchLinkConstraintSetMxSingle::hclStretchLinkConstraintSetMxSingleRead(MEM* src)
{
	hclStretchLinkConstraintSetMxSingle* x = new hclStretchLinkConstraintSetMxSingle;

	mread(&x->restLength,4,1,src);
	mread(&x->stiffness,4,1,src);
	mread(&x->particleA,4,1,src);
	mread(&x->particleB,4,1,src);

	return x;
};
