#pragma once
#include "fsnpCustomMeshParameter.h"

fsnpCustomMeshParameter* fsnpCustomMeshParameter::fsnpCustomMeshParameterRead(MEM* src)
{
	fsnpCustomMeshParameter* x = new fsnpCustomMeshParameter;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->triangleDataArray,sizeof(fsnpCustomMeshParameterTriangleData),1,src);
	mread(&x->primitiveDataArray,sizeof(fsnpCustomMeshParameterPrimitiveData),1,src);
	mread(&x->vertexDataStride,4,1,src);
	mread(&x->triangleDataStride,4,1,src);
	mread(&x->version,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
