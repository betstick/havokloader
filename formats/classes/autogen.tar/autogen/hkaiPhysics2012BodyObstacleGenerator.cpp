#pragma once
#include "hkaiPhysics2012BodyObstacleGenerator.h"

hkaiPhysics2012BodyObstacleGenerator* hkaiPhysics2012BodyObstacleGenerator::hkaiPhysics2012BodyObstacleGeneratorRead(MEM* src)
{
	hkaiPhysics2012BodyObstacleGenerator* x = new hkaiPhysics2012BodyObstacleGenerator;

	x->base = *hkaiObstacleGenerator::hkaiObstacleGeneratorRead(src);
	mread(&x->velocityThreshold,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->rigidBody,8,1,src);
	mread(&x->physicsWorldListener,8,1,src);
	mseek(src,8,SEEK_CUR);
	mseek(src,144,SEEK_CUR);

	return x;
};
