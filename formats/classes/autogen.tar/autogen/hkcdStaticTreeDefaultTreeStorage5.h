#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkcdStaticTreeTreehkcdStaticTreeDynamicStorage5.h"

class hkcdStaticTreeDefaultTreeStorage5
{
	public:
	hkcdStaticTreeTreehkcdStaticTreeDynamicStorage5 base;

	static hkcdStaticTreeDefaultTreeStorage5* hkcdStaticTreeDefaultTreeStorage5Read(MEM* src);
};
