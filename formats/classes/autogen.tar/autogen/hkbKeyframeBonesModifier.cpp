#pragma once
#include "hkbKeyframeBonesModifier.h"

hkbKeyframeBonesModifier* hkbKeyframeBonesModifier::hkbKeyframeBonesModifierRead(MEM* src)
{
	hkbKeyframeBonesModifier* x = new hkbKeyframeBonesModifier;

	x->base = *hkbModifier::hkbModifierRead(src);
	mread(&x->keyframeInfo,sizeof(hkbKeyframeBonesModifierKeyframeInfo),1,src);
	mread(&x->keyframedBonesList,8,1,src);
	mseek(src,88,SEEK_CUR);

	return x;
};
