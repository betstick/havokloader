#pragma once
#include "hclStandardLinkConstraintSetLink.h"

hclStandardLinkConstraintSetLink* hclStandardLinkConstraintSetLink::hclStandardLinkConstraintSetLinkRead(MEM* src)
{
	hclStandardLinkConstraintSetLink* x = new hclStandardLinkConstraintSetLink;

	mread(&x->particleA,2,1,src);
	mread(&x->particleB,2,1,src);
	mread(&x->restLength,4,1,src);
	mread(&x->stiffness,4,1,src);

	return x;
};
