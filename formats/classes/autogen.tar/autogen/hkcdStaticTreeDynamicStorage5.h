#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis5.h"

class hkcdStaticTreeDynamicStorage5
{
	public:
	hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis5 base;

	static hkcdStaticTreeDynamicStorage5* hkcdStaticTreeDynamicStorage5Read(MEM* src);
};
