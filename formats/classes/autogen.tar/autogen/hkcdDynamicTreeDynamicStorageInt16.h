#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkcdDynamicTreeDefaultDynamicStoragehkcdDynamicTreeCodecInt16.h"

class hkcdDynamicTreeDynamicStorageInt16
{
	public:
	hkcdDynamicTreeDefaultDynamicStoragehkcdDynamicTreeCodecInt16 base;

	static hkcdDynamicTreeDynamicStorageInt16* hkcdDynamicTreeDynamicStorageInt16Read(MEM* src);
};
