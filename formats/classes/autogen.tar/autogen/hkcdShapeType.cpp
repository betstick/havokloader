#pragma once
#include "hkcdShapeType.h"

hkcdShapeType* hkcdShapeType::hkcdShapeTypeRead(MEM* src)
{
	hkcdShapeType* x = new hkcdShapeType;

	mseek(src,1,SEEK_CUR);

	return x;
};
