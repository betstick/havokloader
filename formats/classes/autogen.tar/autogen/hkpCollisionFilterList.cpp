#pragma once
#include "hkpCollisionFilterList.h"

hkpCollisionFilterList* hkpCollisionFilterList::hkpCollisionFilterListRead(MEM* src)
{
	hkpCollisionFilterList* x = new hkpCollisionFilterList;

	x->base = *hkpCollisionFilter::hkpCollisionFilterRead(src);
	mread(&x->collisionFilters,8,1,src);
	mseek(src,8,SEEK_CUR);
	mseek(src,72,SEEK_CUR);

	return x;
};
