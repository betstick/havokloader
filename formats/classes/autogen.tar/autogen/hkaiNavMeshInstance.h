#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"
enum DebugValues
{
	DEAD_FACE = -559023410,
	DEAD_EDGE = -559026834,
};
enum CutInfoValues
{
	NOT_CUT_EDGE = 65535,
};

class hkaiNavMeshInstance
{
	public:
	hkReferencedObject base;
	TYPE_SIMPLEARRAY originalFaces;
	TYPE_SIMPLEARRAY originalEdges;
	TYPE_SIMPLEARRAY originalVertices;
	unsigned long originalFaceData;
	int faceDataStriding;
	unsigned long originalEdgeData;
	int edgeDataStriding;
	unsigned long originalMesh;
	hkaiReferenceFrame referenceFrame;
	int* edgeMap;
	int* faceMap;
	hkaiNavMeshFace* instancedFaces;
	hkaiNavMeshEdge* instancedEdges;
	hkaiNavMeshFace* ownedFaces;
	hkaiNavMeshEdge* ownedEdges;
	vec4* ownedVertices;
	unsigned char* faceFlags;
	unsigned short* cuttingInfo;
	int* instancedFaceData;
	int* instancedEdgeData;
	int* ownedFaceData;
	int* ownedEdgeData;
	TYPE_HALF* clearanceCache;
	TYPE_HALF* globalClearanceCache;
	int* faceClearanceIndices;
	float maxGlobalClearance;
	unsigned int sectionUid;
	int runtimeId;
	unsigned int layer;

	static hkaiNavMeshInstance* hkaiNavMeshInstanceRead(MEM* src);
};
