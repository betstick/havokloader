#pragma once
#include "hknpVehicleDefaultTransmission.h"

hknpVehicleDefaultTransmission* hknpVehicleDefaultTransmission::hknpVehicleDefaultTransmissionRead(MEM* src)
{
	hknpVehicleDefaultTransmission* x = new hknpVehicleDefaultTransmission;

	x->base = *hknpVehicleTransmission::hknpVehicleTransmissionRead(src);
	mread(&x->downshiftRPM,4,1,src);
	mread(&x->upshiftRPM,4,1,src);
	mread(&x->primaryTransmissionRatio,4,1,src);
	mread(&x->clutchDelayTime,4,1,src);
	mread(&x->reverseGearRatio,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->gearsRatio,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->wheelsTorqueRatio,4,1,src);
	mseek(src,12,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
