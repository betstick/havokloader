#pragma once
#include "hclSkeletonTransformSetSetupObject.h"

hclSkeletonTransformSetSetupObject* hclSkeletonTransformSetSetupObject::hclSkeletonTransformSetSetupObjectRead(MEM* src)
{
	hclSkeletonTransformSetSetupObject* x = new hclSkeletonTransformSetSetupObject;

	x->base = *hclTransformSetSetupObject::hclTransformSetSetupObjectRead(src);
	mread(&x->name,8,1,src);
	mread(&x->skeleton,8,1,src);
	mread(&x->worldFromModel,sizeof(TYPE_MATRIX4),1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
