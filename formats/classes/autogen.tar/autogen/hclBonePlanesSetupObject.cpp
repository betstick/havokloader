#pragma once
#include "hclBonePlanesSetupObject.h"

hclBonePlanesSetupObject* hclBonePlanesSetupObject::hclBonePlanesSetupObjectRead(MEM* src)
{
	hclBonePlanesSetupObject* x = new hclBonePlanesSetupObject;

	x->base = *hclConstraintSetSetupObject::hclConstraintSetSetupObjectRead(src);
	mread(&x->name,8,1,src);
	mread(&x->simulationMesh,8,1,src);
	mread(&x->transformSetSetup,8,1,src);
	mread(&x->perParticlePlanes,sizeof(hclBonePlanesSetupObjectPerParticlePlane),1,src);
	mread(&x->globalPlanes,sizeof(hclBonePlanesSetupObjectGlobalPlane),1,src);
	mread(&x->perParticleAngle,sizeof(hclBonePlanesSetupObjectPerParticleAngle),1,src);
	mread(&x->angleSpecifiedInDegrees,1,1,src);
	mseek(src,7,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
