#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class CustomManualSelectorGeneratorInternalState
{
	public:
	hkReferencedObject base;
	signed char currentGeneratorIndex;
	signed char generatorIndexAtActivate;
	hkbStateMachineActiveTransitionInfo* activeTransitions;

	static CustomManualSelectorGeneratorInternalState* CustomManualSelectorGeneratorInternalStateRead(MEM* src);
};
