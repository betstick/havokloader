#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkcdStaticTreeTreehkcdStaticTreeDynamicStorage4.h"
enum Flags
{
	SF_REQUIRE_TREE = 1,
};

class hkcdStaticMeshTreeBaseSection
{
	public:
	hkcdStaticTreeTreehkcdStaticTreeDynamicStorage4 base;
	float codecParms;
	unsigned int firstPackedVertex;
	hkcdStaticMeshTreeBaseSectionSharedVertices sharedVertices;
	hkcdStaticMeshTreeBaseSectionPrimitives primitives;
	hkcdStaticMeshTreeBaseSectionDataRuns dataRuns;
	unsigned char numPackedVertices;
	unsigned char numSharedIndices;
	unsigned short leafIndex;
	unsigned char page;
	unsigned char flags;
	unsigned char layerData;
	unsigned char unusedData;

	static hkcdStaticMeshTreeBaseSection* hkcdStaticMeshTreeBaseSectionRead(MEM* src);
};
