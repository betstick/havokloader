#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbBehaviorEventsInfo
{
	public:
	hkReferencedObject base;
	unsigned long characterId;
	short* externalEventIds;
	int padding;

	static hkbBehaviorEventsInfo* hkbBehaviorEventsInfoRead(MEM* src);
};
