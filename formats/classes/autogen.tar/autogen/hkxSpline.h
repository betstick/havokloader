#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"
enum ControlType
{
	BEZIER_SMOOTH = 0,
	BEZIER_CORNER = 1,
	LINEAR = 2,
	CUSTOM = 3,
};

class hkxSpline
{
	public:
	hkReferencedObject base;
	hkxSplineControlPoint* controlPoints;
	bool isClosed;

	static hkxSpline* hkxSplineRead(MEM* src);
};
