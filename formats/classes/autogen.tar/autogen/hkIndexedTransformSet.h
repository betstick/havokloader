#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkIndexedTransformSet
{
	public:
	hkReferencedObject base;
	TYPE_MATRIX4* matrices;
	TYPE_MATRIX4* inverseMatrices;
	short* matricesOrder;
	unsigned long* matricesNames;
	hkMeshBoneIndexMapping* indexMappings;
	bool allMatricesAreAffine;

	static hkIndexedTransformSet* hkIndexedTransformSetRead(MEM* src);
};
