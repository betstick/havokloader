#pragma once
#include "hkbToolNodeType.h"

hkbToolNodeType* hkbToolNodeType::hkbToolNodeTypeRead(MEM* src)
{
	hkbToolNodeType* x = new hkbToolNodeType;

	mseek(src,1,SEEK_CUR);

	return x;
};
