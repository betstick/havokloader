#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbModifier.h"

class hkbFootIkControlsModifier
{
	public:
	hkbModifier base;
	hkbFootIkControlData controlData;
	hkbFootIkControlsModifierLeg* legs;

	static hkbFootIkControlsModifier* hkbFootIkControlsModifierRead(MEM* src);
};
