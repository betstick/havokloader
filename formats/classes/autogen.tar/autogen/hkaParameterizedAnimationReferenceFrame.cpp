#pragma once
#include "hkaParameterizedAnimationReferenceFrame.h"

hkaParameterizedAnimationReferenceFrame* hkaParameterizedAnimationReferenceFrame::hkaParameterizedAnimationReferenceFrameRead(MEM* src)
{
	hkaParameterizedAnimationReferenceFrame* x = new hkaParameterizedAnimationReferenceFrame;

	x->base = *hkaDefaultAnimatedReferenceFrame::hkaDefaultAnimatedReferenceFrameRead(src);
	mread(&x->parameterValues,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->parameterTypes,4,1,src);
	mseek(src,12,SEEK_CUR);
	mseek(src,96,SEEK_CUR);

	return x;
};
