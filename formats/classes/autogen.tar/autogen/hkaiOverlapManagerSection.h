#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkaiOverlapManagerSection
{
	public:
	unsigned long generatorDataMap;
	int numOriginalFaces;
	unsigned long* generatorData;
	unsigned long* faceToGeneratorsMap;
	hkSetIntFloatPair facePriorities;

	static hkaiOverlapManagerSection* hkaiOverlapManagerSectionRead(MEM* src);
};
