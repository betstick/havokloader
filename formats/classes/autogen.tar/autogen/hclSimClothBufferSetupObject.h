#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclBufferSetupObject.h"
enum Type
{
	SIM_CLOTH_MESH_CURRENT_POSITIONS = 0,
	SIM_CLOTH_MESH_PREVIOUS_POSITIONS = 1,
	SIM_CLOTH_MESH_ORIGINAL_POSE = 2,
};

class hclSimClothBufferSetupObject
{
	public:
	hclBufferSetupObject base;
	unsigned int type;
	unsigned long name;
	unsigned long simClothSetupObject;

	static hclSimClothBufferSetupObject* hclSimClothBufferSetupObjectRead(MEM* src);
};
