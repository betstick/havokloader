#pragma once
#include "hknpConstraintCinfo.h"

hknpConstraintCinfo* hknpConstraintCinfo::hknpConstraintCinfoRead(MEM* src)
{
	hknpConstraintCinfo* x = new hknpConstraintCinfo;

	mread(&x->constraintData,8,1,src);
	mread(&x->bodyA,4,1,src);
	mread(&x->bodyB,4,1,src);
	mread(&x->flags,sizeof(TYPE_FLAGS),1,src);

	return x;
};
