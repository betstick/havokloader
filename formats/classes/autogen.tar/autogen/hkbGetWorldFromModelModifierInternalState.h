#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbGetWorldFromModelModifierInternalState
{
	public:
	hkReferencedObject base;
	vec4 translationOut;
	TYPE_QUATERNION rotationOut;

	static hkbGetWorldFromModelModifierInternalState* hkbGetWorldFromModelModifierInternalStateRead(MEM* src);
};
