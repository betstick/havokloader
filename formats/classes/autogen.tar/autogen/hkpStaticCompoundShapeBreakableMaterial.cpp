#pragma once
#include "hkpStaticCompoundShapeBreakableMaterial.h"

hkpStaticCompoundShapeBreakableMaterial* hkpStaticCompoundShapeBreakableMaterial::hkpStaticCompoundShapeBreakableMaterialRead(MEM* src)
{
	hkpStaticCompoundShapeBreakableMaterial* x = new hkpStaticCompoundShapeBreakableMaterial;

	x->base = *hkpBreakableMultiMaterial::hkpBreakableMultiMaterialRead(src);
	mseek(src,56,SEEK_CUR);

	return x;
};
