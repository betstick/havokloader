#pragma once
#include "hclClothContainer.h"

hclClothContainer* hclClothContainer::hclClothContainerRead(MEM* src)
{
	hclClothContainer* x = new hclClothContainer;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->collidables,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->clothDatas,8,1,src);
	mseek(src,8,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
