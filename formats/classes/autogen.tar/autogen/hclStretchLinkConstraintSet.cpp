#pragma once
#include "hclStretchLinkConstraintSet.h"

hclStretchLinkConstraintSet* hclStretchLinkConstraintSet::hclStretchLinkConstraintSetRead(MEM* src)
{
	hclStretchLinkConstraintSet* x = new hclStretchLinkConstraintSet;

	x->base = *hclConstraintSet::hclConstraintSetRead(src);
	mread(&x->links,sizeof(hclStretchLinkConstraintSetLink),1,src);
	mseek(src,32,SEEK_CUR);

	return x;
};
