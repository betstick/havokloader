#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
enum Type
{
	POWERED = 1,
	RIGID_BODY = 2,
};

class hkbRagdollControllerSetup
{
	public:
	signed char type;

	static hkbRagdollControllerSetup* hkbRagdollControllerSetupRead(MEM* src);
};
