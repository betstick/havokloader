#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkaiSilhouetteRecorderReplayEvent.h"

class hkaiSilhouetteRecorderGraphLoadedEvent
{
	public:
	hkaiSilhouetteRecorderReplayEvent base;
	unsigned long graph;

	static hkaiSilhouetteRecorderGraphLoadedEvent* hkaiSilhouetteRecorderGraphLoadedEventRead(MEM* src);
};
