#pragma once
#include "hkaiDuckUnderAnalyzer.h"

hkaiDuckUnderAnalyzer* hkaiDuckUnderAnalyzer::hkaiDuckUnderAnalyzerRead(MEM* src)
{
	hkaiDuckUnderAnalyzer* x = new hkaiDuckUnderAnalyzer;

	x->base = *hkaiTraversalAnalyzer::hkaiTraversalAnalyzerRead(src);
	mread(&x->maxHorizontalDistance,4,1,src);
	mread(&x->minClearance,4,1,src);
	mread(&x->maxClearance,4,1,src);
	mread(&x->maxHeightDifference,4,1,src);
	mseek(src,32,SEEK_CUR);

	return x;
};
