#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkaiVolume.h"

class hkaiInvertedAabbVolume
{
	public:
	hkaiVolume base;
	hkAabb aabb;
	hkGeometry geometry;

	static hkaiInvertedAabbVolume* hkaiInvertedAabbVolumeRead(MEM* src);
};
