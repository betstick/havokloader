#pragma once
#include "hkbExpressionData.h"

hkbExpressionData* hkbExpressionData::hkbExpressionDataRead(MEM* src)
{
	hkbExpressionData* x = new hkbExpressionData;

	mread(&x->expression,8,1,src);
	mread(&x->assignmentVariableIndex,4,1,src);
	mread(&x->assignmentEventIndex,4,1,src);
	mread(&x->eventMode,1,1,src);
	mread(&x->raisedEvent,1,1,src);
	mread(&x->wasTrueInPreviousFrame,1,1,src);
	mseek(src,5,SEEK_CUR);

	return x;
};
