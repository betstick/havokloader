#pragma once
#include "hkbPoweredRagdollControlData.h"

hkbPoweredRagdollControlData* hkbPoweredRagdollControlData::hkbPoweredRagdollControlDataRead(MEM* src)
{
	hkbPoweredRagdollControlData* x = new hkbPoweredRagdollControlData;

	mread(&x->maxForce,4,1,src);
	mread(&x->tau,4,1,src);
	mread(&x->damping,4,1,src);
	mread(&x->proportionalRecoveryVelocity,4,1,src);
	mread(&x->constantRecoveryVelocity,4,1,src);
	mseek(src,12,SEEK_CUR);

	return x;
};
