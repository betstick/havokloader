#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkCustomAttributesAttribute
{
	public:
	TYPE_CSTRING name;
	TYPE_VARIANT value;

	static hkCustomAttributesAttribute* hkCustomAttributesAttributeRead(MEM* src);
};
