#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpBreakableMaterial.h"

class hkpSimpleBreakableMaterial
{
	public:
	hkpBreakableMaterial base;

	static hkpSimpleBreakableMaterial* hkpSimpleBreakableMaterialRead(MEM* src);
};
