#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"
enum PathPointBits
{
	EDGE_TYPE_USER_START = 1,
	EDGE_TYPE_USER_END = 2,
	EDGE_TYPE_SEGMENT_START = 4,
	EDGE_TYPE_SEGMENT_END = 8,
};
enum ReferenceFrame
{
	REFERENCE_FRAME_WORLD = 0,
	REFERENCE_FRAME_SECTION_LOCAL = 1,
	REFERENCE_FRAME_SECTION_FIXED = 2,
};

class hkaiPath
{
	public:
	hkReferencedObject base;
	hkaiPathPathPoint* points;
	unsigned char referenceFrame;

	static hkaiPath* hkaiPathRead(MEM* src);
};
