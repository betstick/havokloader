#pragma once
#include "hkaiStreamingSetGraphConnection.h"

hkaiStreamingSetGraphConnection* hkaiStreamingSetGraphConnection::hkaiStreamingSetGraphConnectionRead(MEM* src)
{
	hkaiStreamingSetGraphConnection* x = new hkaiStreamingSetGraphConnection;

	mread(&x->nodeIndex,4,1,src);
	mread(&x->oppositeNodeIndex,4,1,src);
	mread(&x->edgeData,4,1,src);
	mread(&x->edgeCost,sizeof(TYPE_HALF),1,src);

	return x;
};
