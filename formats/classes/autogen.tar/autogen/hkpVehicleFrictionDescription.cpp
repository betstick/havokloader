#pragma once
#include "hkpVehicleFrictionDescription.h"

hkpVehicleFrictionDescription* hkpVehicleFrictionDescription::hkpVehicleFrictionDescriptionRead(MEM* src)
{
	hkpVehicleFrictionDescription* x = new hkpVehicleFrictionDescription;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->wheelDistance,4,1,src);
	mread(&x->chassisMassInv,4,1,src);
	mread(&x->axleDescr,sizeof(hkpVehicleFrictionDescriptionAxisDescription),1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
