#pragma once
#include "hkbStateMachineTransitionInfoReference.h"

hkbStateMachineTransitionInfoReference* hkbStateMachineTransitionInfoReference::hkbStateMachineTransitionInfoReferenceRead(MEM* src)
{
	hkbStateMachineTransitionInfoReference* x = new hkbStateMachineTransitionInfoReference;

	mread(&x->fromStateIndex,2,1,src);
	mread(&x->transitionIndex,2,1,src);
	mread(&x->stateMachineId,2,1,src);

	return x;
};
