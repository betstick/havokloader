#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hclObjectSpaceDeformerOneBlendEntryBlock
{
	public:
	unsigned short vertexIndices;
	unsigned short boneIndices;

	static hclObjectSpaceDeformerOneBlendEntryBlock* hclObjectSpaceDeformerOneBlendEntryBlockRead(MEM* src);
};
