#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbModifier.h"
enum SensingMode
{
	SENSE_IN_NEARBY_RIGID_BODIES = 0,
	SENSE_IN_RIGID_BODIES_OUTSIDE_THIS_CHARACTER = 1,
	SENSE_IN_OTHER_CHARACTER_RIGID_BODIES = 2,
	SENSE_IN_THIS_CHARACTER_RIGID_BODIES = 3,
	SENSE_IN_GIVEN_CHARACTER_RIGID_BODIES = 4,
	SENSE_IN_GIVEN_RIGID_BODY = 5,
	SENSE_IN_OTHER_CHARACTER_SKELETON = 6,
	SENSE_IN_THIS_CHARACTER_SKELETON = 7,
	SENSE_IN_GIVEN_CHARACTER_SKELETON = 8,
	SENSE_IN_GIVEN_LOCAL_FRAME_GROUP = 9,
};

class hkbSenseHandleModifier
{
	public:
	hkbModifier base;
	hkbHandle handle;
	vec4 sensorLocalOffset;
	hkbSenseHandleModifierRange* ranges;
	unsigned long handleOut;
	unsigned long handleIn;
	unsigned long localFrameName;
	unsigned long sensorLocalFrameName;
	float minDistance;
	float maxDistance;
	float distanceOut;
	unsigned int collisionFilterInfo;
	short sensorRagdollBoneIndex;
	short sensorAnimationBoneIndex;
	signed char sensingMode;
	bool extrapolateSensorPosition;
	bool keepFirstSensedHandle;
	bool foundHandleOut;
	float timeSinceLastModify;
	int rangeIndexForEventToSendNextUpdate;

	static hkbSenseHandleModifier* hkbSenseHandleModifierRead(MEM* src);
};
