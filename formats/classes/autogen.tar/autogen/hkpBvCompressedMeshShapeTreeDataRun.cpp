#pragma once
#include "hkpBvCompressedMeshShapeTreeDataRun.h"

hkpBvCompressedMeshShapeTreeDataRun* hkpBvCompressedMeshShapeTreeDataRun::hkpBvCompressedMeshShapeTreeDataRunRead(MEM* src)
{
	hkpBvCompressedMeshShapeTreeDataRun* x = new hkpBvCompressedMeshShapeTreeDataRun;

	x->base = *hkcdStaticMeshTreeBasePrimitiveDataRunBaseunsignedint::hkcdStaticMeshTreeBasePrimitiveDataRunBaseunsignedintRead(src);
	mseek(src,8,SEEK_CUR);

	return x;
};
