#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbComputeRotationFromAxisAngleModifierInternalState
{
	public:
	hkReferencedObject base;
	TYPE_QUATERNION rotationOut;

	static hkbComputeRotationFromAxisAngleModifierInternalState* hkbComputeRotationFromAxisAngleModifierInternalStateRead(MEM* src);
};
