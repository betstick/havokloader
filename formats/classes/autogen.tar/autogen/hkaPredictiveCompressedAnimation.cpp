#pragma once
#include "hkaPredictiveCompressedAnimation.h"

hkaPredictiveCompressedAnimation* hkaPredictiveCompressedAnimation::hkaPredictiveCompressedAnimationRead(MEM* src)
{
	hkaPredictiveCompressedAnimation* x = new hkaPredictiveCompressedAnimation;

	x->base = *hkaAnimation::hkaAnimationRead(src);
	mread(&x->compressedData,1,1,src);
	mseek(src,15,SEEK_CUR);
	mread(&x->intData,2,1,src);
	mseek(src,14,SEEK_CUR);
	mread(&x->intArrayOffsets,4,1,src);
	mseek(src,36,SEEK_CUR);
	mread(&x->floatData,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->floatArrayOffsets,4,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->numBones,4,1,src);
	mread(&x->numFloatSlots,4,1,src);
	mread(&x->numFrames,4,1,src);
	mread(&x->firstFloatBlockScaleAndOffsetIndex,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->skeleton,8,1,src);
	mread(&x->maxCompressedBytesPerFrame,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,56,SEEK_CUR);

	return x;
};
