#pragma once
#include "hknpCompressedHeightFieldShape.h"

hknpCompressedHeightFieldShape* hknpCompressedHeightFieldShape::hknpCompressedHeightFieldShapeRead(MEM* src)
{
	hknpCompressedHeightFieldShape* x = new hknpCompressedHeightFieldShape;

	x->base = *hknpHeightFieldShape::hknpHeightFieldShapeRead(src);
	mread(&x->storage,2,1,src);
	mseek(src,14,SEEK_CUR);
	mread(&x->shapeTags,2,1,src);
	mseek(src,14,SEEK_CUR);
	mread(&x->triangleFlip,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->offset,4,1,src);
	mread(&x->scale,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,240,SEEK_CUR);

	return x;
};
