#pragma once
#include "hkaiNavVolumeGenerationSnapshot.h"

hkaiNavVolumeGenerationSnapshot* hkaiNavVolumeGenerationSnapshot::hkaiNavVolumeGenerationSnapshotRead(MEM* src)
{
	hkaiNavVolumeGenerationSnapshot* x = new hkaiNavVolumeGenerationSnapshot;

	mread(&x->geometry,sizeof(hkGeometry),1,src);
	mread(&x->settings,sizeof(hkaiNavVolumeGenerationSettings),1,src);

	return x;
};
