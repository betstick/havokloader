#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hknpVehicleDefaultSuspensionWheelSpringSuspensionParameters
{
	public:
	float strength;
	float dampingCompression;
	float dampingRelaxation;

	static hknpVehicleDefaultSuspensionWheelSpringSuspensionParameters* hknpVehicleDefaultSuspensionWheelSpringSuspensionParametersRead(MEM* src);
};
