#pragma once
#include "hkcdDynamicTreeAnisotropicMetric.h"

hkcdDynamicTreeAnisotropicMetric* hkcdDynamicTreeAnisotropicMetric::hkcdDynamicTreeAnisotropicMetricRead(MEM* src)
{
	hkcdDynamicTreeAnisotropicMetric* x = new hkcdDynamicTreeAnisotropicMetric;

	mseek(src,1,SEEK_CUR);

	return x;
};
