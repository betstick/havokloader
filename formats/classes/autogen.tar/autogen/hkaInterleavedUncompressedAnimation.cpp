#pragma once
#include "hkaInterleavedUncompressedAnimation.h"

hkaInterleavedUncompressedAnimation* hkaInterleavedUncompressedAnimation::hkaInterleavedUncompressedAnimationRead(MEM* src)
{
	hkaInterleavedUncompressedAnimation* x = new hkaInterleavedUncompressedAnimation;

	x->base = *hkaAnimation::hkaAnimationRead(src);
	mread(&x->transforms,48,1,src);
	mread(&x->floats,4,1,src);
	mseek(src,12,SEEK_CUR);
	mseek(src,56,SEEK_CUR);

	return x;
};
