#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpConstraintAtom.h"

class hkp2dAngConstraintAtom
{
	public:
	hkpConstraintAtom base;
	unsigned char freeRotationAxis;
	unsigned char padding;

	static hkp2dAngConstraintAtom* hkp2dAngConstraintAtomRead(MEM* src);
};
