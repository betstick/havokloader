#pragma once
#include "hkbEvaluateExpressionModifierInternalExpressionData.h"

hkbEvaluateExpressionModifierInternalExpressionData* hkbEvaluateExpressionModifierInternalExpressionData::hkbEvaluateExpressionModifierInternalExpressionDataRead(MEM* src)
{
	hkbEvaluateExpressionModifierInternalExpressionData* x = new hkbEvaluateExpressionModifierInternalExpressionData;

	mread(&x->raisedEvent,1,1,src);
	mread(&x->wasTrueInPreviousFrame,1,1,src);

	return x;
};
