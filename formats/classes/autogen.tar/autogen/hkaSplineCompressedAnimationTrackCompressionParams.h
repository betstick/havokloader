#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
enum RotationQuantization
{
	POLAR32 = 0,
	THREECOMP40 = 1,
	THREECOMP48 = 2,
	THREECOMP24 = 3,
	STRAIGHT16 = 4,
	UNCOMPRESSED = 5,
};
enum ScalarQuantization
{
	BITS8 = 0,
	BITS16 = 1,
};

class hkaSplineCompressedAnimationTrackCompressionParams
{
	public:
	float rotationTolerance;
	float translationTolerance;
	float scaleTolerance;
	float floatingTolerance;
	unsigned short rotationDegree;
	unsigned short translationDegree;
	unsigned short scaleDegree;
	unsigned short floatingDegree;
	unsigned char rotationQuantizationType;
	unsigned char translationQuantizationType;
	unsigned char scaleQuantizationType;
	unsigned char floatQuantizationType;

	static hkaSplineCompressedAnimationTrackCompressionParams* hkaSplineCompressedAnimationTrackCompressionParamsRead(MEM* src);
};
