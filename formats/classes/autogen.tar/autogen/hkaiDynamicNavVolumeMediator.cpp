#pragma once
#include "hkaiDynamicNavVolumeMediator.h"

hkaiDynamicNavVolumeMediator* hkaiDynamicNavVolumeMediator::hkaiDynamicNavVolumeMediatorRead(MEM* src)
{
	hkaiDynamicNavVolumeMediator* x = new hkaiDynamicNavVolumeMediator;

	x->base = *hkaiNavVolumeMediator::hkaiNavVolumeMediatorRead(src);
	mread(&x->collection,8,1,src);
	mread(&x->aabbTree,8,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
