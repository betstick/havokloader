#pragma once
#include "hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis4.h"

hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis4* hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis4::hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis4Read(MEM* src)
{
	hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis4* x = new hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis4;

	mread(&x->nodes,sizeof(hkcdStaticTreeCodec3Axis4),1,src);

	return x;
};
