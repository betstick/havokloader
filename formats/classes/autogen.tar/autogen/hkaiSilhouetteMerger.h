#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"
enum MergeType
{
	UNUSED_MERGING_SIMPLE = 0,
	UNUSED_MERGING_CONVEX_HULL = 1,
};

class hkaiSilhouetteMerger
{
	public:
	hkReferencedObject base;
	unsigned char mergeType;
	hkaiSilhouetteGenerationParameters mergeParams;

	static hkaiSilhouetteMerger* hkaiSilhouetteMergerRead(MEM* src);
};
