#pragma once
#include "hclVolumeConstraintSetupObject.h"

hclVolumeConstraintSetupObject* hclVolumeConstraintSetupObject::hclVolumeConstraintSetupObjectRead(MEM* src)
{
	hclVolumeConstraintSetupObject* x = new hclVolumeConstraintSetupObject;

	x->base = *hclConstraintSetSetupObject::hclConstraintSetSetupObjectRead(src);
	mread(&x->name,8,1,src);
	mread(&x->simulationMesh,8,1,src);
	mread(&x->applyToParticles,sizeof(hclVertexSelectionInput),1,src);
	mread(&x->stiffness,sizeof(hclVertexFloatInput),1,src);
	mread(&x->influenceParticles,sizeof(hclVertexSelectionInput),1,src);
	mread(&x->particleWeights,sizeof(hclVertexFloatInput),1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
