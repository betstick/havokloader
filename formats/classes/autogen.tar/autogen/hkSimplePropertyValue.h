#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkSimplePropertyValue
{
	public:
	unsigned long data;

	static hkSimplePropertyValue* hkSimplePropertyValueRead(MEM* src);
};
