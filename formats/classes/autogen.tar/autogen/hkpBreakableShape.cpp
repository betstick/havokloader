#pragma once
#include "hkpBreakableShape.h"

hkpBreakableShape* hkpBreakableShape::hkpBreakableShapeRead(MEM* src)
{
	hkpBreakableShape* x = new hkpBreakableShape;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->physicsShape,8,1,src);
	mread(&x->material,8,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
