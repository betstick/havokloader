#pragma once
#include "hkpDashpotAction.h"

hkpDashpotAction* hkpDashpotAction::hkpDashpotActionRead(MEM* src)
{
	hkpDashpotAction* x = new hkpDashpotAction;

	x->base = *hkpBinaryAction::hkpBinaryActionRead(src);
	mread(&x->point,16,1,src);
	mseek(src,16,SEEK_CUR);
	mread(&x->strength,4,1,src);
	mread(&x->damping,4,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->impulse,16,1,src);
	mseek(src,64,SEEK_CUR);

	return x;
};
