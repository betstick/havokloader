#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkaiAdaptiveRanger
{
	public:
	float curRange;

	static hkaiAdaptiveRanger* hkaiAdaptiveRangerRead(MEM* src);
};
