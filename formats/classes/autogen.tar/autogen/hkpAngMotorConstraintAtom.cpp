#pragma once
#include "hkpAngMotorConstraintAtom.h"

hkpAngMotorConstraintAtom* hkpAngMotorConstraintAtom::hkpAngMotorConstraintAtomRead(MEM* src)
{
	hkpAngMotorConstraintAtom* x = new hkpAngMotorConstraintAtom;

	x->base = *hkpConstraintAtom::hkpConstraintAtomRead(src);
	mread(&x->isEnabled,1,1,src);
	mread(&x->motorAxis,1,1,src);
	mread(&x->initializedOffset,2,1,src);
	mread(&x->previousTargetAngleOffset,2,1,src);
	mread(&x->correspondingAngLimitSolverResultOffset,2,1,src);
	mseek(src,2,SEEK_CUR);
	mread(&x->targetAngle,4,1,src);
	mread(&x->motor,8,1,src);
	mread(&x->padding,1,1,src);
	mseek(src,15,SEEK_CUR);
	mseek(src,2,SEEK_CUR);

	return x;
};
