#pragma once
#include "hkpUnaryAction.h"

hkpUnaryAction* hkpUnaryAction::hkpUnaryActionRead(MEM* src)
{
	hkpUnaryAction* x = new hkpUnaryAction;

	x->base = *hkpAction::hkpActionRead(src);
	mread(&x->entity,8,1,src);
	mseek(src,48,SEEK_CUR);

	return x;
};
