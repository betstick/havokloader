#pragma once
#include "hkaiUserEdgePairArray.h"

hkaiUserEdgePairArray* hkaiUserEdgePairArray::hkaiUserEdgePairArrayRead(MEM* src)
{
	hkaiUserEdgePairArray* x = new hkaiUserEdgePairArray;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->edgePairs,sizeof(hkaiUserEdgeUtilsUserEdgePair),1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
