#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbEventPayload.h"

class hkbEventPayloadList
{
	public:
	hkbEventPayload base;
	unsigned long* payloads;

	static hkbEventPayloadList* hkbEventPayloadListRead(MEM* src);
};
