#pragma once
#include "hkaiNavMeshPathRequestInfo.h"

hkaiNavMeshPathRequestInfo* hkaiNavMeshPathRequestInfo::hkaiNavMeshPathRequestInfoRead(MEM* src)
{
	hkaiNavMeshPathRequestInfo* x = new hkaiNavMeshPathRequestInfo;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->input,8,1,src);
	mread(&x->output,8,1,src);
	mread(&x->priority,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->owner,8,1,src);
	mread(&x->markedForDeletion,1,1,src);
	mseek(src,7,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
