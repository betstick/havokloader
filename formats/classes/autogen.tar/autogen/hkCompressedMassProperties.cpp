#pragma once
#include "hkCompressedMassProperties.h"

hkCompressedMassProperties* hkCompressedMassProperties::hkCompressedMassPropertiesRead(MEM* src)
{
	hkCompressedMassProperties* x = new hkCompressedMassProperties;

	mread(&x->centerOfMass,2,1,src);
	mseek(src,6,SEEK_CUR);
	mread(&x->inertia,2,1,src);
	mseek(src,6,SEEK_CUR);
	mread(&x->majorAxisSpace,2,1,src);
	mseek(src,6,SEEK_CUR);
	mread(&x->mass,4,1,src);
	mread(&x->volume,4,1,src);

	return x;
};
