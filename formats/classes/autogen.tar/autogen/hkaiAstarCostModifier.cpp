#pragma once
#include "hkaiAstarCostModifier.h"

hkaiAstarCostModifier* hkaiAstarCostModifier::hkaiAstarCostModifierRead(MEM* src)
{
	hkaiAstarCostModifier* x = new hkaiAstarCostModifier;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->type,1,1,src);
	mseek(src,7,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
