#pragma once
#include "hkbNamedRealEventPayload.h"

hkbNamedRealEventPayload* hkbNamedRealEventPayload::hkbNamedRealEventPayloadRead(MEM* src)
{
	hkbNamedRealEventPayload* x = new hkbNamedRealEventPayload;

	x->base = *hkbNamedEventPayload::hkbNamedEventPayloadRead(src);
	mread(&x->data,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,24,SEEK_CUR);

	return x;
};
