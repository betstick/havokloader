#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbModifier.h"
enum ReachMode
{
	REACH_MODE_TERRAIN = 0,
	REACH_MODE_WORLD_POSITION = 1,
	REACH_MODE_MODEL_POSITION = 2,
	REACH_MODE_BONE_POSITION = 3,
};

class hkbpReachModifier
{
	public:
	hkbModifier base;
	hkbpReachModifierHand* hands;
	float newTargetGain;
	float noTargetGain;
	float targetGain;
	float fadeOutDuration;
	int raycastLayer;
	unsigned int sensingPropertyKey;
	signed char reachMode;
	bool ignoreMySystemGroup;
	float extrapolate;
	void* internalHandData;
	float timeLapse;

	static hkbpReachModifier* hkbpReachModifierRead(MEM* src);
};
