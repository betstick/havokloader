#pragma once
#include "hknpDynamicCompoundShape.h"

hknpDynamicCompoundShape* hknpDynamicCompoundShape::hknpDynamicCompoundShapeRead(MEM* src)
{
	hknpDynamicCompoundShape* x = new hknpDynamicCompoundShape;

	x->base = *hknpCompoundShape::hknpCompoundShapeRead(src);
	mread(&x->boundingVolumeData,8,1,src);
	mseek(src,8,SEEK_CUR);
	mseek(src,192,SEEK_CUR);

	return x;
};
