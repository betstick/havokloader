#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbCharacterSetup
{
	public:
	hkReferencedObject base;
	unsigned long* retargetingSkeletonMappers;
	unsigned long animationSkeleton;
	unsigned long ragdollToAnimationSkeletonMapper;
	unsigned long animationToRagdollSkeletonMapper;
	unsigned long animationBindingSet;
	unsigned long data;
	unsigned long unscaledAnimationSkeleton;
	unsigned long mirroredSkeleton;
	unsigned long characterPropertyIdMap;
	unsigned long criticalSection;

	static hkbCharacterSetup* hkbCharacterSetupRead(MEM* src);
};
