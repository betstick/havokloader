#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkxEnum
{
	public:
	hkReferencedObject base;
	hkxEnumItem* items;

	static hkxEnum* hkxEnumRead(MEM* src);
};
