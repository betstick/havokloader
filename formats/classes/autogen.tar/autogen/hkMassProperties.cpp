#pragma once
#include "hkMassProperties.h"

hkMassProperties* hkMassProperties::hkMassPropertiesRead(MEM* src)
{
	hkMassProperties* x = new hkMassProperties;

	mread(&x->volume,4,1,src);
	mread(&x->mass,4,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->centerOfMass,16,1,src);
	mread(&x->inertiaTensor,sizeof(TYPE_MATRIX3),1,src);

	return x;
};
