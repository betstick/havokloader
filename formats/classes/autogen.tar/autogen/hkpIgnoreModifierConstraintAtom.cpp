#pragma once
#include "hkpIgnoreModifierConstraintAtom.h"

hkpIgnoreModifierConstraintAtom* hkpIgnoreModifierConstraintAtom::hkpIgnoreModifierConstraintAtomRead(MEM* src)
{
	hkpIgnoreModifierConstraintAtom* x = new hkpIgnoreModifierConstraintAtom;

	x->base = *hkpModifierConstraintAtom::hkpModifierConstraintAtomRead(src);
	mseek(src,48,SEEK_CUR);

	return x;
};
