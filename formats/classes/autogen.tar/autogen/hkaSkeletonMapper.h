#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"
enum ConstraintSource
{
	NO_CONSTRAINTS = 0,
	REFERENCE_POSE = 1,
	CURRENT_POSE = 2,
};

class hkaSkeletonMapper
{
	public:
	hkReferencedObject base;
	hkaSkeletonMapperData mapping;

	static hkaSkeletonMapper* hkaSkeletonMapperRead(MEM* src);
};
