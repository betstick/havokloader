#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkBaseObject.h"

class hknpShapeKeyMask
{
	public:
	hkBaseObject base;

	static hknpShapeKeyMask* hknpShapeKeyMaskRead(MEM* src);
};
