#pragma once
#include "hclVolumeConstraintMxFrameBatchData.h"

hclVolumeConstraintMxFrameBatchData* hclVolumeConstraintMxFrameBatchData::hclVolumeConstraintMxFrameBatchDataRead(MEM* src)
{
	hclVolumeConstraintMxFrameBatchData* x = new hclVolumeConstraintMxFrameBatchData;

	mread(&x->frameVector,16,1,src);
	mseek(src,240,SEEK_CUR);
	mread(&x->particleIndex,2,1,src);
	mseek(src,30,SEEK_CUR);
	mread(&x->weight,4,1,src);
	mseek(src,60,SEEK_CUR);

	return x;
};
