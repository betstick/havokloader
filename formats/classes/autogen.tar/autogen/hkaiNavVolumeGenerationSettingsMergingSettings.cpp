#pragma once
#include "hkaiNavVolumeGenerationSettingsMergingSettings.h"

hkaiNavVolumeGenerationSettingsMergingSettings* hkaiNavVolumeGenerationSettingsMergingSettings::hkaiNavVolumeGenerationSettingsMergingSettingsRead(MEM* src)
{
	hkaiNavVolumeGenerationSettingsMergingSettings* x = new hkaiNavVolumeGenerationSettingsMergingSettings;

	mread(&x->nodeWeight,4,1,src);
	mread(&x->edgeWeight,4,1,src);
	mread(&x->estimateNewEdges,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->iterationsStabilizationThreshold,4,1,src);
	mread(&x->slopeThreshold,4,1,src);
	mread(&x->maxMergingIterations,4,1,src);
	mread(&x->randomSeed,4,1,src);
	mread(&x->multiplier,4,1,src);
	mread(&x->useSimpleFirstMergePass,1,1,src);
	mseek(src,3,SEEK_CUR);

	return x;
};
