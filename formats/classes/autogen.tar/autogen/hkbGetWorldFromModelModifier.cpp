#pragma once
#include "hkbGetWorldFromModelModifier.h"

hkbGetWorldFromModelModifier* hkbGetWorldFromModelModifier::hkbGetWorldFromModelModifierRead(MEM* src)
{
	hkbGetWorldFromModelModifier* x = new hkbGetWorldFromModelModifier;

	x->base = *hkbModifier::hkbModifierRead(src);
	mread(&x->translationOut,16,1,src);
	mread(&x->rotationOut,sizeof(TYPE_QUATERNION),1,src);
	mseek(src,96,SEEK_CUR);

	return x;
};
