#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hknpVehicleSteering
{
	public:
	hkReferencedObject base;

	static hknpVehicleSteering* hknpVehicleSteeringRead(MEM* src);
};
