#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkcdDynamicTreeCodec32
{
	public:
	hkAabb aabb;

	static hkcdDynamicTreeCodec32* hkcdDynamicTreeCodec32Read(MEM* src);
};
