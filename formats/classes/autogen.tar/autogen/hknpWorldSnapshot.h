#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hknpWorldSnapshot
{
	public:
	hkReferencedObject base;
	hknpWorldCinfo worldCinfo;
	hknpBody* bodies;
	unsigned long* bodyNames;
	hknpMotion* motions;
	hknpConstraintCinfo* constraints;

	static hknpWorldSnapshot* hknpWorldSnapshotRead(MEM* src);
};
