#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbModifier.h"

class hkbMoveBoneAttachmentModifier
{
	public:
	hkbModifier base;
	int activateEventId;
	unsigned long attachment;
	unsigned long localFrame;

	static hkbMoveBoneAttachmentModifier* hkbMoveBoneAttachmentModifierRead(MEM* src);
};
