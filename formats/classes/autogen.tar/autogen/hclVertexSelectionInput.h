#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
enum VertexSelectionType
{
	VERTEX_SELECTION_ALL = 0,
	VERTEX_SELECTION_NONE = 1,
	VERTEX_SELECTION_CHANNEL = 2,
	VERTEX_SELECTION_INVERSE_CHANNEL = 3,
};

class hclVertexSelectionInput
{
	public:
	unsigned int type;
	unsigned long channelName;

	static hclVertexSelectionInput* hclVertexSelectionInputRead(MEM* src);
};
