#pragma once
#include "hkbBoneWeightArray.h"

hkbBoneWeightArray* hkbBoneWeightArray::hkbBoneWeightArrayRead(MEM* src)
{
	hkbBoneWeightArray* x = new hkbBoneWeightArray;

	x->base = *hkbBindable::hkbBindableRead(src);
	mread(&x->boneWeights,4,1,src);
	mseek(src,12,SEEK_CUR);
	mseek(src,48,SEEK_CUR);

	return x;
};
