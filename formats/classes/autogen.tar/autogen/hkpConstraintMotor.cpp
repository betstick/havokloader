#pragma once
#include "hkpConstraintMotor.h"

hkpConstraintMotor* hkpConstraintMotor::hkpConstraintMotorRead(MEM* src)
{
	hkpConstraintMotor* x = new hkpConstraintMotor;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->type,1,1,src);
	mseek(src,7,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
