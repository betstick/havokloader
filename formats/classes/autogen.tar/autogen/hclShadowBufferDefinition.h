#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclBufferDefinition.h"

class hclShadowBufferDefinition
{
	public:
	hclBufferDefinition base;
	unsigned short* triangleIndices;
	bool shadowPositions;
	bool shadowNormals;
	bool shadowTangents;
	bool shadowBiTangents;

	static hclShadowBufferDefinition* hclShadowBufferDefinitionRead(MEM* src);
};
