#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
enum Link
{
	NONE = 0,
	DIRECT_LINK = 1,
	CHILD = 2,
	MESH = 3,
	PARENT_NAME = 4,
	IMGSELECT = 5,
};

class hkLinkAttribute
{
	public:
	signed char type;

	static hkLinkAttribute* hkLinkAttributeRead(MEM* src);
};
