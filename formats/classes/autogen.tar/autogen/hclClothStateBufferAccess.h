#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hclClothStateBufferAccess
{
	public:
	unsigned int bufferIndex;
	hclBufferUsage bufferUsage;
	unsigned int shadowBufferIndex;

	static hclClothStateBufferAccess* hclClothStateBufferAccessRead(MEM* src);
};
