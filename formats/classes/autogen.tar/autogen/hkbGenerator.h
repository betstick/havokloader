#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbNode.h"

class hkbGenerator
{
	public:
	hkbNode base;
	hkbGeneratorPartitionInfo partitionInfo;
	unsigned long syncInfo;
	signed char pad;

	static hkbGenerator* hkbGeneratorRead(MEM* src);
};
