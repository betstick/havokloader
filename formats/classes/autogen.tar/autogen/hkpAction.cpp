#pragma once
#include "hkpAction.h"

hkpAction* hkpAction::hkpActionRead(MEM* src)
{
	hkpAction* x = new hkpAction;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->world,8,1,src);
	mread(&x->island,8,1,src);
	mread(&x->userData,8,1,src);
	mread(&x->name,8,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
