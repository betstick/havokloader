#pragma once
#include "hkaDirectionalReferenceFrame.h"

hkaDirectionalReferenceFrame* hkaDirectionalReferenceFrame::hkaDirectionalReferenceFrameRead(MEM* src)
{
	hkaDirectionalReferenceFrame* x = new hkaDirectionalReferenceFrame;

	x->base = *hkaParameterizedReferenceFrame::hkaParameterizedReferenceFrameRead(src);
	mread(&x->movementDir,16,1,src);
	mseek(src,96,SEEK_CUR);

	return x;
};
