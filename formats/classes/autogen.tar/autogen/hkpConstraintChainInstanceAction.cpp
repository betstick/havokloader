#pragma once
#include "hkpConstraintChainInstanceAction.h"

hkpConstraintChainInstanceAction* hkpConstraintChainInstanceAction::hkpConstraintChainInstanceActionRead(MEM* src)
{
	hkpConstraintChainInstanceAction* x = new hkpConstraintChainInstanceAction;

	x->base = *hkpAction::hkpActionRead(src);
	mread(&x->constraintInstance,8,1,src);
	mseek(src,48,SEEK_CUR);

	return x;
};
