#pragma once
#include "hkMemoryMeshMaterial.h"

hkMemoryMeshMaterial* hkMemoryMeshMaterial::hkMemoryMeshMaterialRead(MEM* src)
{
	hkMemoryMeshMaterial* x = new hkMemoryMeshMaterial;

	x->base = *hkMeshMaterial::hkMeshMaterialRead(src);
	mread(&x->materialName,8,1,src);
	mread(&x->textures,8,1,src);
	mseek(src,16,SEEK_CUR);
	mread(&x->diffuseColor,16,1,src);
	mread(&x->ambientColor,16,1,src);
	mread(&x->specularColor,16,1,src);
	mread(&x->emissiveColor,16,1,src);
	mread(&x->userData,8,1,src);
	mread(&x->tesselationFactor,4,1,src);
	mread(&x->displacementAmount,4,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
