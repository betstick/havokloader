#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"
enum EdgeFilterType
{
	EDGE_FILTER_DEFAULT = 0,
	EDGE_FILTER_USER = 1,
};

class hkaiAstarEdgeFilter
{
	public:
	hkReferencedObject base;
	unsigned char type;

	static hkaiAstarEdgeFilter* hkaiAstarEdgeFilterRead(MEM* src);
};
