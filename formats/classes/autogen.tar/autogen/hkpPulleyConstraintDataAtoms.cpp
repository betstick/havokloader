#pragma once
#include "hkpPulleyConstraintDataAtoms.h"

hkpPulleyConstraintDataAtoms* hkpPulleyConstraintDataAtoms::hkpPulleyConstraintDataAtomsRead(MEM* src)
{
	hkpPulleyConstraintDataAtoms* x = new hkpPulleyConstraintDataAtoms;

	mread(&x->translations,sizeof(hkpSetLocalTranslationsConstraintAtom),1,src);
	mread(&x->pulley,sizeof(hkpPulleyConstraintAtom),1,src);

	return x;
};
