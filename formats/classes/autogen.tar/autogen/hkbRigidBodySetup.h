#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
enum Type
{
	INVALID = -1,
	KEYFRAMED = 0,
	DYNAMIC = 1,
	FIXED = 2,
};

class hkbRigidBodySetup
{
	public:
	unsigned int collisionFilterInfo;
	signed char type;
	hkbShapeSetup shapeSetup;

	static hkbRigidBodySetup* hkbRigidBodySetupRead(MEM* src);
};
