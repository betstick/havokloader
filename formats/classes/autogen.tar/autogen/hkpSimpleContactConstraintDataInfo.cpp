#pragma once
#include "hkpSimpleContactConstraintDataInfo.h"

hkpSimpleContactConstraintDataInfo* hkpSimpleContactConstraintDataInfo::hkpSimpleContactConstraintDataInfoRead(MEM* src)
{
	hkpSimpleContactConstraintDataInfo* x = new hkpSimpleContactConstraintDataInfo;

	mread(&x->flags,2,1,src);
	mread(&x->biNormalAxis,2,1,src);
	mread(&x->rollingFrictionMultiplier,sizeof(TYPE_HALF),1,src);
	mread(&x->internalData1,sizeof(TYPE_HALF),1,src);
	mread(&x->rhsRolling,sizeof(TYPE_HALF),1,src);
	mread(&x->contactRadius,4,1,src);
	mread(&x->data,4,1,src);
	mseek(src,12,SEEK_CUR);

	return x;
};
