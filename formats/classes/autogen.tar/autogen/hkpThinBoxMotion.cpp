#pragma once
#include "hkpThinBoxMotion.h"

hkpThinBoxMotion* hkpThinBoxMotion::hkpThinBoxMotionRead(MEM* src)
{
	hkpThinBoxMotion* x = new hkpThinBoxMotion;

	x->base = *hkpBoxMotion::hkpBoxMotionRead(src);
	mseek(src,320,SEEK_CUR);

	return x;
};
