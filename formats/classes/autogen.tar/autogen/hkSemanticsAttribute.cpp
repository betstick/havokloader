#pragma once
#include "hkSemanticsAttribute.h"

hkSemanticsAttribute* hkSemanticsAttribute::hkSemanticsAttributeRead(MEM* src)
{
	hkSemanticsAttribute* x = new hkSemanticsAttribute;

	mread(&x->type,1,1,src);

	return x;
};
