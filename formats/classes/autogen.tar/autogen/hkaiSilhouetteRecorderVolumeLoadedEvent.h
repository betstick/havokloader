#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkaiSilhouetteRecorderReplayEvent.h"

class hkaiSilhouetteRecorderVolumeLoadedEvent
{
	public:
	hkaiSilhouetteRecorderReplayEvent base;
	unsigned long volume;
	unsigned long mediator;

	static hkaiSilhouetteRecorderVolumeLoadedEvent* hkaiSilhouetteRecorderVolumeLoadedEventRead(MEM* src);
};
