#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hclVolumeConstraintMxApplyBatchData
{
	public:
	vec4 frameVector;
	unsigned short particleIndex;
	float stiffness;

	static hclVolumeConstraintMxApplyBatchData* hclVolumeConstraintMxApplyBatchDataRead(MEM* src);
};
