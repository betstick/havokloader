#pragma once
#include "hknpVehicleDefaultEngine.h"

hknpVehicleDefaultEngine* hknpVehicleDefaultEngine::hknpVehicleDefaultEngineRead(MEM* src)
{
	hknpVehicleDefaultEngine* x = new hknpVehicleDefaultEngine;

	x->base = *hknpVehicleEngine::hknpVehicleEngineRead(src);
	mread(&x->minRPM,4,1,src);
	mread(&x->optRPM,4,1,src);
	mread(&x->maxRPM,4,1,src);
	mread(&x->maxTorque,4,1,src);
	mread(&x->torqueFactorAtMinRPM,4,1,src);
	mread(&x->torqueFactorAtMaxRPM,4,1,src);
	mread(&x->resistanceFactorAtMinRPM,4,1,src);
	mread(&x->resistanceFactorAtOptRPM,4,1,src);
	mread(&x->resistanceFactorAtMaxRPM,4,1,src);
	mread(&x->clutchSlipRPM,4,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
