#pragma once
#include "hkpBinaryAction.h"

hkpBinaryAction* hkpBinaryAction::hkpBinaryActionRead(MEM* src)
{
	hkpBinaryAction* x = new hkpBinaryAction;

	x->base = *hkpAction::hkpActionRead(src);
	mread(&x->entityA,8,1,src);
	mread(&x->entityB,8,1,src);
	mseek(src,48,SEEK_CUR);

	return x;
};
