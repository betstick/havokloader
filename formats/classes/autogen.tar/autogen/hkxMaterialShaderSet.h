#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkxMaterialShaderSet
{
	public:
	hkReferencedObject base;
	unsigned long* shaders;

	static hkxMaterialShaderSet* hkxMaterialShaderSetRead(MEM* src);
};
