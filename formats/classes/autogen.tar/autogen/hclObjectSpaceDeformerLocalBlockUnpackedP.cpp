#pragma once
#include "hclObjectSpaceDeformerLocalBlockUnpackedP.h"

hclObjectSpaceDeformerLocalBlockUnpackedP* hclObjectSpaceDeformerLocalBlockUnpackedP::hclObjectSpaceDeformerLocalBlockUnpackedPRead(MEM* src)
{
	hclObjectSpaceDeformerLocalBlockUnpackedP* x = new hclObjectSpaceDeformerLocalBlockUnpackedP;

	mread(&x->localPosition,16,1,src);
	mseek(src,240,SEEK_CUR);

	return x;
};
