#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hknpDestructionShapeProperties
{
	public:
	hkReferencedObject base;
	TYPE_TRANSFORM worldFromShape;
	bool isHierarchicalCompound;
	bool hasDestructionShapes;

	static hknpDestructionShapeProperties* hknpDestructionShapePropertiesRead(MEM* src);
};
