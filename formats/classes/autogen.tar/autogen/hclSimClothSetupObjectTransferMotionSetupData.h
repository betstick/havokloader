#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hclSimClothSetupObjectTransferMotionSetupData
{
	public:
	unsigned long transferMotionTransformSetSetup;
	unsigned long transferMotionTransformName;
	bool transferTranslationMotion;
	float minTranslationSpeed;
	float maxTranslationSpeed;
	float minTranslationBlend;
	float maxTranslationBlend;
	bool transferRotationMotion;
	float minRotationSpeed;
	float maxRotationSpeed;
	float minRotationBlend;
	float maxRotationBlend;

	static hclSimClothSetupObjectTransferMotionSetupData* hclSimClothSetupObjectTransferMotionSetupDataRead(MEM* src);
};
