#pragma once
#include "hkbExtractRagdollPoseModifier.h"

hkbExtractRagdollPoseModifier* hkbExtractRagdollPoseModifier::hkbExtractRagdollPoseModifierRead(MEM* src)
{
	hkbExtractRagdollPoseModifier* x = new hkbExtractRagdollPoseModifier;

	x->base = *hkbModifier::hkbModifierRead(src);
	mread(&x->poseMatchingBone0,2,1,src);
	mread(&x->poseMatchingBone1,2,1,src);
	mread(&x->poseMatchingBone2,2,1,src);
	mread(&x->enableComputeWorldFromModel,1,1,src);
	mseek(src,1,SEEK_CUR);
	mseek(src,88,SEEK_CUR);

	return x;
};
