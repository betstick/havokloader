#pragma once
#include "hkbBehaviorGraphData.h"

hkbBehaviorGraphData* hkbBehaviorGraphData::hkbBehaviorGraphDataRead(MEM* src)
{
	hkbBehaviorGraphData* x = new hkbBehaviorGraphData;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->attributeDefaults,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->variableInfos,sizeof(hkbVariableInfo),1,src);
	mread(&x->characterPropertyInfos,sizeof(hkbVariableInfo),1,src);
	mread(&x->eventInfos,sizeof(hkbEventInfo),1,src);
	mread(&x->variableBounds,sizeof(hkbVariableBounds),1,src);
	mread(&x->variableInitialValues,8,1,src);
	mread(&x->stringData,8,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
