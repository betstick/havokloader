#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkFreeListArrayhknpMotionPropertieshknpMotionPropertiesId8hknpMotionPropertiesFreeListArrayOperations
{
	public:
	hknpMotionProperties* elements;
	int firstFree;

	static hkFreeListArrayhknpMotionPropertieshknpMotionPropertiesId8hknpMotionPropertiesFreeListArrayOperations* hkFreeListArrayhknpMotionPropertieshknpMotionPropertiesId8hknpMotionPropertiesFreeListArrayOperationsRead(MEM* src);
};
