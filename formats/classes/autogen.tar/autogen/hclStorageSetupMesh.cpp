#pragma once
#include "hclStorageSetupMesh.h"

hclStorageSetupMesh* hclStorageSetupMesh::hclStorageSetupMeshRead(MEM* src)
{
	hclStorageSetupMesh* x = new hclStorageSetupMesh;

	x->base = *hclSetupMesh::hclSetupMeshRead(src);
	mread(&x->name,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->worldFromMesh,sizeof(TYPE_MATRIX4),1,src);
	mread(&x->sections,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->vertexChannels,sizeof(hclStorageSetupMeshVertexChannel),1,src);
	mread(&x->edgeChannels,sizeof(hclStorageSetupMeshEdgeChannel),1,src);
	mread(&x->triangleChannels,sizeof(hclStorageSetupMeshTriangleChannel),1,src);
	mread(&x->bones,sizeof(hclStorageSetupMeshBone),1,src);
	mread(&x->isSkinned,1,1,src);
	mseek(src,7,SEEK_CUR);
	mread(&x->stringPool,8,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
