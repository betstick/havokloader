#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkpConstraintInstanceSmallArraySerializeOverrideType
{
	public:
	unsigned long data;
	unsigned short size;
	unsigned short capacityAndFlags;

	static hkpConstraintInstanceSmallArraySerializeOverrideType* hkpConstraintInstanceSmallArraySerializeOverrideTypeRead(MEM* src);
};
