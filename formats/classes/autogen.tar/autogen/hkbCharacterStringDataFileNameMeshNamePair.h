#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkbCharacterStringDataFileNameMeshNamePair
{
	public:
	unsigned long fileName;
	unsigned long meshName;

	static hkbCharacterStringDataFileNameMeshNamePair* hkbCharacterStringDataFileNameMeshNamePairRead(MEM* src);
};
