#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclSetupMesh.h"

class hclNamedSetupMesh
{
	public:
	hclSetupMesh base;
	unsigned long name;
	unsigned long meshName;
	unsigned long setupMesh;

	static hclNamedSetupMesh* hclNamedSetupMeshRead(MEM* src);
};
