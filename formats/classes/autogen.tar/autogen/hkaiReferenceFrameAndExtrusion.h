#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
enum UpVectorTransformMethod
{
	USE_GLOBAL_UP = 0,
	USE_INSTANCE_TRANSFORM = 1,
	USE_FACE_NORMAL = 2,
};

class hkaiReferenceFrameAndExtrusion
{
	public:
	vec4 up;
	float cellExtrusion;
	float silhouetteRadiusExpasion;
	unsigned char upTransformMethod;

	static hkaiReferenceFrameAndExtrusion* hkaiReferenceFrameAndExtrusionRead(MEM* src);
};
