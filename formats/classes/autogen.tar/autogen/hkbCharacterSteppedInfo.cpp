#pragma once
#include "hkbCharacterSteppedInfo.h"

hkbCharacterSteppedInfo* hkbCharacterSteppedInfo::hkbCharacterSteppedInfoRead(MEM* src)
{
	hkbCharacterSteppedInfo* x = new hkbCharacterSteppedInfo;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->characterId,8,1,src);
	mread(&x->deltaTime,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->worldFromModel,48,1,src);
	mread(&x->poseModelSpace,48,1,src);
	mread(&x->rigidAttachmentTransforms,48,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
