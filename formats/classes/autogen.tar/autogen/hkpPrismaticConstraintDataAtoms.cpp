#pragma once
#include "hkpPrismaticConstraintDataAtoms.h"

hkpPrismaticConstraintDataAtoms* hkpPrismaticConstraintDataAtoms::hkpPrismaticConstraintDataAtomsRead(MEM* src)
{
	hkpPrismaticConstraintDataAtoms* x = new hkpPrismaticConstraintDataAtoms;

	mread(&x->transforms,sizeof(hkpSetLocalTransformsConstraintAtom),1,src);
	mread(&x->motor,sizeof(hkpLinMotorConstraintAtom),1,src);
	mread(&x->friction,sizeof(hkpLinFrictionConstraintAtom),1,src);
	mread(&x->ang,sizeof(hkpAngConstraintAtom),1,src);
	mread(&x->lin0,sizeof(hkpLinConstraintAtom),1,src);
	mread(&x->lin1,sizeof(hkpLinConstraintAtom),1,src);
	mread(&x->linLimit,sizeof(hkpLinLimitConstraintAtom),1,src);

	return x;
};
