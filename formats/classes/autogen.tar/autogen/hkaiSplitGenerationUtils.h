#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
enum SplitAndGenerateOptions
{
	SIMPLIFY_INDIVIDUALLY = 0,
	SIMPLIFY_INDIVIDUALLY_BORDER_PRESERVE = 1,
	SIMPLIFY_ALL_AT_ONCE = 2,
	SIMPLIFY_TWO_PASS = 3,
};
enum SplitMethod
{
	SPLIT_UNIFORM = 0,
	SPLIT_ADAPTIVE = 1,
};

class hkaiSplitGenerationUtils
{
	public:

	static hkaiSplitGenerationUtils* hkaiSplitGenerationUtilsRead(MEM* src);
};
