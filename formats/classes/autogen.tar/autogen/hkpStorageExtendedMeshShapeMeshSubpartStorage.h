#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkpStorageExtendedMeshShapeMeshSubpartStorage
{
	public:
	hkReferencedObject base;
	vec4* vertices;
	unsigned char* indices8;
	unsigned short* indices16;
	unsigned int* indices32;
	unsigned char* materialIndices;
	hkpStorageExtendedMeshShapeMaterial* materials;
	hkpNamedMeshMaterial* namedMaterials;
	unsigned short* materialIndices16;

	static hkpStorageExtendedMeshShapeMeshSubpartStorage* hkpStorageExtendedMeshShapeMeshSubpartStorageRead(MEM* src);
};
