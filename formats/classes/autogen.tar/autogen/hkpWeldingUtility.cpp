#pragma once
#include "hkpWeldingUtility.h"

hkpWeldingUtility* hkpWeldingUtility::hkpWeldingUtilityRead(MEM* src)
{
	hkpWeldingUtility* x = new hkpWeldingUtility;

	mseek(src,1,SEEK_CUR);

	return x;
};
