#pragma once
#include "hkcdStaticMeshTreehkcdStaticMeshTreeCommonConfigunsignedintunsignedlonglong1121hkpBvCompressedMeshShapeTreeDataRun.h"

hkcdStaticMeshTreehkcdStaticMeshTreeCommonConfigunsignedintunsignedlonglong1121hkpBvCompressedMeshShapeTreeDataRun* hkcdStaticMeshTreehkcdStaticMeshTreeCommonConfigunsignedintunsignedlonglong1121hkpBvCompressedMeshShapeTreeDataRun::hkcdStaticMeshTreehkcdStaticMeshTreeCommonConfigunsignedintunsignedlonglong1121hkpBvCompressedMeshShapeTreeDataRunRead(MEM* src)
{
	hkcdStaticMeshTreehkcdStaticMeshTreeCommonConfigunsignedintunsignedlonglong1121hkpBvCompressedMeshShapeTreeDataRun* x = new hkcdStaticMeshTreehkcdStaticMeshTreeCommonConfigunsignedintunsignedlonglong1121hkpBvCompressedMeshShapeTreeDataRun;

	x->base = *hkcdStaticMeshTreeBase::hkcdStaticMeshTreeBaseRead(src);
	mread(&x->packedVertices,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->sharedVertices,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->primitiveDataRuns,sizeof(hkpBvCompressedMeshShapeTreeDataRun),1,src);
	mseek(src,112,SEEK_CUR);

	return x;
};
