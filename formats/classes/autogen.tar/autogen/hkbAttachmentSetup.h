#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"
enum AttachmentType
{
	ATTACHMENT_TYPE_KEYFRAME_RIGID_BODY = 0,
	ATTACHMENT_TYPE_BALL_SOCKET_CONSTRAINT = 1,
	ATTACHMENT_TYPE_RAGDOLL_CONSTRAINT = 2,
	ATTACHMENT_TYPE_SET_WORLD_FROM_MODEL = 3,
	ATTACHMENT_TYPE_NONE = 4,
};

class hkbAttachmentSetup
{
	public:
	hkReferencedObject base;
	float blendInTime;
	float moveAttacherFraction;
	float gain;
	float extrapolationTimeStep;
	float fixUpGain;
	float maxLinearDistance;
	float maxAngularDistance;
	signed char attachmentType;

	static hkbAttachmentSetup* hkbAttachmentSetupRead(MEM* src);
};
