#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbRagdollInterface
{
	public:
	hkReferencedObject base;

	static hkbRagdollInterface* hkbRagdollInterfaceRead(MEM* src);
};
