#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpWrappedConstraintData.h"

class hkpMalleableConstraintData
{
	public:
	hkpWrappedConstraintData base;
	hkpBridgeAtoms atoms;
	float strength;

	static hkpMalleableConstraintData* hkpMalleableConstraintDataRead(MEM* src);
};
