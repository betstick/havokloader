#pragma once
#include "hkbGeneratorPartitionInfo.h"

hkbGeneratorPartitionInfo* hkbGeneratorPartitionInfo::hkbGeneratorPartitionInfoRead(MEM* src)
{
	hkbGeneratorPartitionInfo* x = new hkbGeneratorPartitionInfo;

	mread(&x->boneMask,4,1,src);
	mseek(src,28,SEEK_CUR);
	mread(&x->partitionMask,4,1,src);
	mread(&x->numBones,2,1,src);
	mread(&x->numMaxPartitions,2,1,src);

	return x;
};
