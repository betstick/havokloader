#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkaiNavMeshGenerationSettingsWallClimbingSettings
{
	public:
	bool enableWallClimbing;
	bool excludeWalkableFaces;

	static hkaiNavMeshGenerationSettingsWallClimbingSettings* hkaiNavMeshGenerationSettingsWallClimbingSettingsRead(MEM* src);
};
