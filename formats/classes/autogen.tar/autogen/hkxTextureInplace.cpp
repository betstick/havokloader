#pragma once
#include "hkxTextureInplace.h"

hkxTextureInplace* hkxTextureInplace::hkxTextureInplaceRead(MEM* src)
{
	hkxTextureInplace* x = new hkxTextureInplace;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->fileType,sizeof(TYPE_CHAR),1,src);
	mread(&x->data,1,1,src);
	mseek(src,15,SEEK_CUR);
	mread(&x->name,8,1,src);
	mread(&x->originalFilename,8,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
