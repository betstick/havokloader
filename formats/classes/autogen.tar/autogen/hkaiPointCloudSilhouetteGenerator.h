#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkaiSilhouetteGenerator.h"
enum DetailLevel
{
	DETAIL_INVALID = 0,
	DETAIL_FULL = 1,
	DETAIL_OBB = 2,
	DETAIL_CONVEX_HULL = 3,
};
enum PointCloudFlagBits
{
	LOCAL_POINTS_CHANGED = 1,
};

class hkaiPointCloudSilhouetteGenerator
{
	public:
	hkaiSilhouetteGenerator base;
	hkAabb localAabb;
	vec4* localPoints;
	int* silhouetteSizes;
	float weldTolerance;
	unsigned char silhouetteDetailLevel;
	TYPE_FLAGS flags;
	bool localPointsChanged;
	bool isEnabled;

	static hkaiPointCloudSilhouetteGenerator* hkaiPointCloudSilhouetteGeneratorRead(MEM* src);
};
