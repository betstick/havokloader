#pragma once
#include "hclClothState.h"

hclClothState* hclClothState::hclClothStateRead(MEM* src)
{
	hclClothState* x = new hclClothState;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->name,8,1,src);
	mread(&x->operators,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->usedBuffers,sizeof(hclClothStateBufferAccess),1,src);
	mread(&x->usedTransformSets,sizeof(hclClothStateTransformSetAccess),1,src);
	mread(&x->usedSimCloths,4,1,src);
	mseek(src,12,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
