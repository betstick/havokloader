#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hclBoneSpaceDeformerLocalBlockPN
{
	public:
	vec4 localPosition;
	short localNormal;

	static hclBoneSpaceDeformerLocalBlockPN* hclBoneSpaceDeformerLocalBlockPNRead(MEM* src);
};
