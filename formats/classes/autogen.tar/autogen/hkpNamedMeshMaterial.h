#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpMeshMaterial.h"

class hkpNamedMeshMaterial
{
	public:
	hkpMeshMaterial base;
	unsigned long name;

	static hkpNamedMeshMaterial* hkpNamedMeshMaterialRead(MEM* src);
};
