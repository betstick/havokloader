#pragma once
#include "hkaiSplitGenerationUtilsSettings.h"

hkaiSplitGenerationUtilsSettings* hkaiSplitGenerationUtilsSettings::hkaiSplitGenerationUtilsSettingsRead(MEM* src)
{
	hkaiSplitGenerationUtilsSettings* x = new hkaiSplitGenerationUtilsSettings;

	mread(&x->simplificationOptions,1,1,src);
	mread(&x->splitMethod,1,1,src);
	mread(&x->generateClusterGraphs,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->desiredFacesPerCluster,4,1,src);
	mread(&x->costModifier,8,1,src);
	mread(&x->shelver,8,1,src);
	mread(&x->borderPreserveShrinkSize,4,1,src);
	mread(&x->streamingEdgeMatchTolerance,4,1,src);
	mread(&x->numX,4,1,src);
	mread(&x->numY,4,1,src);
	mread(&x->maxSplits,4,1,src);
	mread(&x->desiredTrisPerChunk,4,1,src);
	mread(&x->saveInputSnapshot,1,1,src);
	mseek(src,7,SEEK_CUR);
	mread(&x->snapshotFilename,8,1,src);

	return x;
};
