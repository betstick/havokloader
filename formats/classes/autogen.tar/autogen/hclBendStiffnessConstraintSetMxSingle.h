#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hclBendStiffnessConstraintSetMxSingle
{
	public:
	float weightA;
	float weightB;
	float weightC;
	float weightD;
	float bendStiffness;
	float restCurvature;
	float invMassA;
	float invMassB;
	float invMassC;
	float invMassD;
	unsigned short particleA;
	unsigned short particleB;
	unsigned short particleC;
	unsigned short particleD;

	static hclBendStiffnessConstraintSetMxSingle* hclBendStiffnessConstraintSetMxSingleRead(MEM* src);
};
