#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbModifier.h"

class hkbExtractRagdollPoseModifier
{
	public:
	hkbModifier base;
	short poseMatchingBone0;
	short poseMatchingBone1;
	short poseMatchingBone2;
	bool enableComputeWorldFromModel;

	static hkbExtractRagdollPoseModifier* hkbExtractRagdollPoseModifierRead(MEM* src);
};
