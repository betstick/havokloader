#pragma once
#include "hkaiNavMeshGenerationSettings.h"

hkaiNavMeshGenerationSettings* hkaiNavMeshGenerationSettings::hkaiNavMeshGenerationSettingsRead(MEM* src)
{
	hkaiNavMeshGenerationSettings* x = new hkaiNavMeshGenerationSettings;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->characterHeight,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->up,16,1,src);
	mread(&x->quantizationGridSize,4,1,src);
	mread(&x->maxWalkableSlope,4,1,src);
	mread(&x->triangleWinding,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->degenerateAreaThreshold,4,1,src);
	mread(&x->degenerateWidthThreshold,4,1,src);
	mread(&x->convexThreshold,4,1,src);
	mread(&x->maxNumEdgesPerFace,4,1,src);
	mread(&x->edgeMatchingParams,sizeof(hkaiNavMeshEdgeMatchingParameters),1,src);
	mread(&x->edgeMatchingMetric,4,1,src);
	mread(&x->edgeConnectionIterations,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->regionPruningSettings,sizeof(hkaiNavMeshGenerationSettingsRegionPruningSettings),1,src);
	mread(&x->wallClimbingSettings,sizeof(hkaiNavMeshGenerationSettingsWallClimbingSettings),1,src);
	mread(&x->boundsAabb,sizeof(hkAabb),1,src);
	mread(&x->carvers,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->painters,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->painterOverlapCallback,8,1,src);
	mread(&x->defaultConstructionProperties,sizeof(TYPE_FLAGS),1,src);
	mread(&x->materialMap,sizeof(hkaiNavMeshGenerationSettingsMaterialConstructionPair),1,src);
	mread(&x->fixupOverlappingTriangles,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->overlappingTrianglesSettings,sizeof(hkaiOverlappingTrianglesSettings),1,src);
	mread(&x->weldInputVertices,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->weldThreshold,4,1,src);
	mread(&x->minCharacterWidth,4,1,src);
	mread(&x->characterWidthUsage,1,1,src);
	mread(&x->enableSimplification,1,1,src);
	mseek(src,2,SEEK_CUR);
	mread(&x->simplificationSettings,sizeof(hkaiNavMeshSimplificationUtilsSettings),1,src);
	mread(&x->carvedMaterialDeprecated,4,1,src);
	mread(&x->carvedCuttingMaterialDeprecated,4,1,src);
	mread(&x->setBestFaceCenters,1,1,src);
	mread(&x->checkEdgeGeometryConsistency,1,1,src);
	mread(&x->saveInputSnapshot,1,1,src);
	mseek(src,5,SEEK_CUR);
	mread(&x->snapshotFilename,8,1,src);
	mread(&x->overrideSettings,sizeof(hkaiNavMeshGenerationSettingsOverrideSettings),1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
