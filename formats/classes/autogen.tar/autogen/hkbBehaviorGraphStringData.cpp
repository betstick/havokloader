#pragma once
#include "hkbBehaviorGraphStringData.h"

hkbBehaviorGraphStringData* hkbBehaviorGraphStringData::hkbBehaviorGraphStringDataRead(MEM* src)
{
	hkbBehaviorGraphStringData* x = new hkbBehaviorGraphStringData;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->eventNames,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->attributeNames,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->variableNames,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->characterPropertyNames,8,1,src);
	mseek(src,8,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
