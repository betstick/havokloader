#pragma once
#include "hkaiStreamingSetNavMeshConnection.h"

hkaiStreamingSetNavMeshConnection* hkaiStreamingSetNavMeshConnection::hkaiStreamingSetNavMeshConnectionRead(MEM* src)
{
	hkaiStreamingSetNavMeshConnection* x = new hkaiStreamingSetNavMeshConnection;

	mread(&x->faceIndex,4,1,src);
	mread(&x->edgeIndex,4,1,src);
	mread(&x->oppositeFaceIndex,4,1,src);
	mread(&x->oppositeEdgeIndex,4,1,src);

	return x;
};
