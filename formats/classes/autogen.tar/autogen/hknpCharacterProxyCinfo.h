#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hknpCharacterProxyCinfo
{
	public:
	hkReferencedObject base;
	vec4 position;
	TYPE_QUATERNION orientation;
	vec4 velocity;
	float dynamicFriction;
	float staticFriction;
	float keepContactTolerance;
	vec4 up;
	unsigned long shape;
	unsigned long userData;
	unsigned long world;
	unsigned int collisionFilterInfo;
	float keepDistance;
	float contactAngleSensitivity;
	unsigned int userPlanes;
	float maxCharacterSpeedForSolver;
	float characterStrength;
	float characterMass;
	float maxSlope;
	float penetrationRecoverySpeed;
	int maxCastIterations;
	bool refreshManifoldInCheckSupport;
	bool presenceInWorld;

	static hknpCharacterProxyCinfo* hknpCharacterProxyCinfoRead(MEM* src);
};
