#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpMeshMaterial.h"

class hkpStorageExtendedMeshShapeMaterial
{
	public:
	hkpMeshMaterial base;
	TYPE_HALF restitution;
	TYPE_HALF friction;
	unsigned long userData;

	static hkpStorageExtendedMeshShapeMaterial* hkpStorageExtendedMeshShapeMaterialRead(MEM* src);
};
