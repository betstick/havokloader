#pragma once
#include "hkbRealEventPayload.h"

hkbRealEventPayload* hkbRealEventPayload::hkbRealEventPayloadRead(MEM* src)
{
	hkbRealEventPayload* x = new hkbRealEventPayload;

	x->base = *hkbEventPayload::hkbEventPayloadRead(src);
	mread(&x->data,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,16,SEEK_CUR);

	return x;
};
