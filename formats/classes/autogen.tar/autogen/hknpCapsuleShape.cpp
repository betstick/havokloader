#pragma once
#include "hknpCapsuleShape.h"

hknpCapsuleShape* hknpCapsuleShape::hknpCapsuleShapeRead(MEM* src)
{
	hknpCapsuleShape* x = new hknpCapsuleShape;

	x->base = *hknpConvexPolytopeShape::hknpConvexPolytopeShapeRead(src);
	mread(&x->a,16,1,src);
	mread(&x->b,16,1,src);
	mseek(src,80,SEEK_CUR);

	return x;
};
