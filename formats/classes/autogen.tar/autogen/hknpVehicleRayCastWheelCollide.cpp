#pragma once
#include "hknpVehicleRayCastWheelCollide.h"

hknpVehicleRayCastWheelCollide* hknpVehicleRayCastWheelCollide::hknpVehicleRayCastWheelCollideRead(MEM* src)
{
	hknpVehicleRayCastWheelCollide* x = new hknpVehicleRayCastWheelCollide;

	x->base = *hknpVehicleWheelCollide::hknpVehicleWheelCollideRead(src);
	mseek(src,24,SEEK_CUR);

	return x;
};
