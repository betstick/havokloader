#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpStorageExtendedMeshShape.h"

class CustomParamStorageExtendedMeshShape
{
	public:
	hkpStorageExtendedMeshShape base;
	unsigned long* materialArray;

	static CustomParamStorageExtendedMeshShape* CustomParamStorageExtendedMeshShapeRead(MEM* src);
};
