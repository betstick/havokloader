#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkpEntitySpuCollisionCallback
{
	public:
	unsigned long util;
	unsigned short capacity;
	unsigned char eventFilter;
	unsigned char userFilter;

	static hkpEntitySpuCollisionCallback* hkpEntitySpuCollisionCallbackRead(MEM* src);
};
