#pragma once
#include "hkxEnumItem.h"

hkxEnumItem* hkxEnumItem::hkxEnumItemRead(MEM* src)
{
	hkxEnumItem* x = new hkxEnumItem;

	mread(&x->value,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->name,8,1,src);

	return x;
};
