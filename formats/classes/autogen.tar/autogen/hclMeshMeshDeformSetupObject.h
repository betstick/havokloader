#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclOperatorSetupObject.h"

class hclMeshMeshDeformSetupObject
{
	public:
	hclOperatorSetupObject base;
	unsigned long name;
	unsigned long inputBufferSetupObject;
	hclTriangleSelectionInput inputTriangleSelection;
	unsigned long outputBufferSetupObject;
	hclVertexSelectionInput outputVertexSelection;
	hclVertexFloatInput influenceRadiusPerVertex;
	unsigned int scaleNormalBehaviour;
	unsigned int maxTrianglesPerVertex;
	float minimumTriangleWeight;
	bool deformNormals;
	bool deformTangents;
	bool deformBiTangents;
	bool useMeshTopology;

	static hclMeshMeshDeformSetupObject* hclMeshMeshDeformSetupObjectRead(MEM* src);
};
