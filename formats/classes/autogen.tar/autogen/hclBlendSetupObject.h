#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclOperatorSetupObject.h"

class hclBlendSetupObject
{
	public:
	hclOperatorSetupObject base;
	unsigned long name;
	unsigned long A;
	unsigned long B;
	unsigned long C;
	hclVertexSelectionInput vertexSelection;
	hclVertexFloatInput blendWeights;
	bool mapToScurve;
	bool blendNormals;
	bool blendTangents;
	bool blendBitangents;

	static hclBlendSetupObject* hclBlendSetupObjectRead(MEM* src);
};
