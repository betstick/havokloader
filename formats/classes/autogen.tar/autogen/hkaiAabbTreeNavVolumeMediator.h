#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkaiNavVolumeMediator.h"

class hkaiAabbTreeNavVolumeMediator
{
	public:
	hkaiNavVolumeMediator base;
	unsigned long navVolume;
	unsigned long tree;

	static hkaiAabbTreeNavVolumeMediator* hkaiAabbTreeNavVolumeMediatorRead(MEM* src);
};
