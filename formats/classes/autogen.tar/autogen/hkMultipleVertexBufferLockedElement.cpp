#pragma once
#include "hkMultipleVertexBufferLockedElement.h"

hkMultipleVertexBufferLockedElement* hkMultipleVertexBufferLockedElement::hkMultipleVertexBufferLockedElementRead(MEM* src)
{
	hkMultipleVertexBufferLockedElement* x = new hkMultipleVertexBufferLockedElement;

	mread(&x->vertexBufferIndex,1,1,src);
	mread(&x->elementIndex,1,1,src);
	mread(&x->lockedBufferIndex,1,1,src);
	mread(&x->vertexFormatIndex,1,1,src);
	mread(&x->lockFlags,1,1,src);
	mread(&x->outputBufferIndex,1,1,src);
	mread(&x->emulatedIndex,1,1,src);

	return x;
};
