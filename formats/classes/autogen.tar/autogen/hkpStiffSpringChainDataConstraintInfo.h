#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkpStiffSpringChainDataConstraintInfo
{
	public:
	vec4 pivotInA;
	vec4 pivotInB;
	float springLength;

	static hkpStiffSpringChainDataConstraintInfo* hkpStiffSpringChainDataConstraintInfoRead(MEM* src);
};
