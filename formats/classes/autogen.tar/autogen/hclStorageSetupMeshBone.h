#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hclStorageSetupMeshBone
{
	public:
	unsigned long name;
	TYPE_MATRIX4 boneFromSkin;

	static hclStorageSetupMeshBone* hclStorageSetupMeshBoneRead(MEM* src);
};
