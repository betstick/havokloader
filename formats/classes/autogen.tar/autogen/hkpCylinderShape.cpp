#pragma once
#include "hkpCylinderShape.h"

hkpCylinderShape* hkpCylinderShape::hkpCylinderShapeRead(MEM* src)
{
	hkpCylinderShape* x = new hkpCylinderShape;

	x->base = *hkpConvexShape::hkpConvexShapeRead(src);
	mread(&x->cylRadius,4,1,src);
	mread(&x->cylBaseRadiusFactorForHeightFieldCollisions,4,1,src);
	mread(&x->vertexA,16,1,src);
	mread(&x->vertexB,16,1,src);
	mread(&x->perpendicular1,16,1,src);
	mread(&x->perpendicular2,16,1,src);
	mseek(src,40,SEEK_CUR);

	return x;
};
