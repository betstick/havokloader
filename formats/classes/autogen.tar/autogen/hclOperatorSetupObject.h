#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hclOperatorSetupObject
{
	public:
	hkReferencedObject base;

	static hclOperatorSetupObject* hclOperatorSetupObjectRead(MEM* src);
};
