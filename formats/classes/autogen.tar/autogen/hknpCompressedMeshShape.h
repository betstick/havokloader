#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hknpCompositeShape.h"

class hknpCompressedMeshShape
{
	public:
	hknpCompositeShape base;
	unsigned long data;
	hkBitField quadIsFlat;
	hkBitField triangleIsInterior;
	int numTriangles;
	int numConvexShapes;

	static hknpCompressedMeshShape* hknpCompressedMeshShapeRead(MEM* src);
};
