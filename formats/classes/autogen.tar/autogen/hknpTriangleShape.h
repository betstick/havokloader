#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hknpConvexPolytopeShape.h"

class hknpTriangleShape
{
	public:
	hknpConvexPolytopeShape base;

	static hknpTriangleShape* hknpTriangleShapeRead(MEM* src);
};
