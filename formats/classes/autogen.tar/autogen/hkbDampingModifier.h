#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbModifier.h"

class hkbDampingModifier
{
	public:
	hkbModifier base;
	float kP;
	float kI;
	float kD;
	bool enableScalarDamping;
	bool enableVectorDamping;
	float rawValue;
	float dampedValue;
	vec4 rawVector;
	vec4 dampedVector;
	vec4 vecErrorSum;
	vec4 vecPreviousError;
	float errorSum;
	float previousError;

	static hkbDampingModifier* hkbDampingModifierRead(MEM* src);
};
