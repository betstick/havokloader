#pragma once
#include "hknpBodyCinfo.h"

hknpBodyCinfo* hknpBodyCinfo::hknpBodyCinfoRead(MEM* src)
{
	hknpBodyCinfo* x = new hknpBodyCinfo;

	mread(&x->shape,8,1,src);
	mread(&x->reservedBodyId,4,1,src);
	mread(&x->motionId,4,1,src);
	mread(&x->qualityId,1,1,src);
	mseek(src,1,SEEK_CUR);
	mread(&x->materialId,2,1,src);
	mread(&x->collisionFilterInfo,4,1,src);
	mread(&x->flags,4,1,src);
	mread(&x->collisionLookAheadDistance,4,1,src);
	mread(&x->name,8,1,src);
	mread(&x->userData,8,1,src);
	mread(&x->position,16,1,src);
	mread(&x->orientation,sizeof(TYPE_QUATERNION),1,src);
	mread(&x->spuFlags,sizeof(TYPE_FLAGS),1,src);
	mread(&x->localFrame,8,1,src);

	return x;
};
