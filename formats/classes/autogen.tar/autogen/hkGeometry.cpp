#pragma once
#include "hkGeometry.h"

hkGeometry* hkGeometry::hkGeometryRead(MEM* src)
{
	hkGeometry* x = new hkGeometry;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->vertices,16,1,src);
	mread(&x->triangles,sizeof(hkGeometryTriangle),1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
