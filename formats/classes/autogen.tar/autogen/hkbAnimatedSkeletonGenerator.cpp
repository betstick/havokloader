#pragma once
#include "hkbAnimatedSkeletonGenerator.h"

hkbAnimatedSkeletonGenerator* hkbAnimatedSkeletonGenerator::hkbAnimatedSkeletonGeneratorRead(MEM* src)
{
	hkbAnimatedSkeletonGenerator* x = new hkbAnimatedSkeletonGenerator;

	x->base = *hkbGenerator::hkbGeneratorRead(src);
	mread(&x->animatedSkeleton,8,1,src);
	mseek(src,136,SEEK_CUR);

	return x;
};
