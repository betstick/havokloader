#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbGenerator.h"
enum BlenderFlags
{
	FLAG_SYNC = 1,
	FLAG_SMOOTH_GENERATOR_WEIGHTS = 4,
	FLAG_DONT_DEACTIVATE_CHILDREN_WITH_ZERO_WEIGHTS = 8,
	FLAG_PARAMETRIC_BLEND = 16,
	FLAG_IS_PARAMETRIC_BLEND_CYCLIC = 32,
	FLAG_FORCE_DENSE_POSE = 64,
	FLAG_BLEND_MOTION_OF_ADDITIVE_ANIMATIONS = 128,
	FLAG_USE_VELOCITY_SYNCHRONIZATION = 256,
};

class hkbBlenderGenerator
{
	public:
	hkbGenerator base;
	float referencePoseWeightThreshold;
	float blendParameter;
	float minCyclicBlendParameter;
	float maxCyclicBlendParameter;
	short indexOfSyncMasterChild;
	short flags;
	bool subtractLastChild;
	unsigned long* children;
	void* childrenInternalStates;
	void* sortedChildren;
	float endIntervalWeight;
	int numActiveChildren;
	short beginIntervalIndex;
	short endIntervalIndex;
	bool initSync;
	bool doSubtractiveBlend;

	static hkbBlenderGenerator* hkbBlenderGeneratorRead(MEM* src);
};
