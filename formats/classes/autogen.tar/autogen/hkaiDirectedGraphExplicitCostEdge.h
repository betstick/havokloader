#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkaiDirectedGraphExplicitCostEdge
{
	public:
	TYPE_HALF cost;
	TYPE_FLAGS flags;
	unsigned int target;

	static hkaiDirectedGraphExplicitCostEdge* hkaiDirectedGraphExplicitCostEdgeRead(MEM* src);
};
