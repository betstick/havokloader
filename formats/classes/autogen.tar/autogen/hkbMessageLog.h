#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkbMessageLog
{
	public:
	unsigned long messages;
	int maxMessages;

	static hkbMessageLog* hkbMessageLogRead(MEM* src);
};
