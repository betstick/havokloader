#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkaiPathfindingUtilFindPathOutput
{
	public:
	hkReferencedObject base;
	unsigned int* visitedEdges;
	hkaiPathPathPoint* pathOut;
	hkaiAstarOutputParameters outputParameters;

	static hkaiPathfindingUtilFindPathOutput* hkaiPathfindingUtilFindPathOutputRead(MEM* src);
};
