#pragma once
#include "hkbWorldFromModelModeData.h"

hkbWorldFromModelModeData* hkbWorldFromModelModeData::hkbWorldFromModelModeDataRead(MEM* src)
{
	hkbWorldFromModelModeData* x = new hkbWorldFromModelModeData;

	mread(&x->poseMatchingBone0,2,1,src);
	mread(&x->poseMatchingBone1,2,1,src);
	mread(&x->poseMatchingBone2,2,1,src);
	mread(&x->mode,1,1,src);
	mseek(src,1,SEEK_CUR);

	return x;
};
