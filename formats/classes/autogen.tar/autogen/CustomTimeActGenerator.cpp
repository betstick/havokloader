#pragma once
#include "CustomTimeActGenerator.h"

CustomTimeActGenerator* CustomTimeActGenerator::CustomTimeActGeneratorRead(MEM* src)
{
	CustomTimeActGenerator* x = new CustomTimeActGenerator;

	x->base = *hkbGenerator::hkbGeneratorRead(src);
	mread(&x->generator,8,1,src);
	mread(&x->offsetType,4,1,src);
	mread(&x->taeId,4,1,src);
	mread(&x->valIndex,4,1,src);
	mread(&x->valRate,4,1,src);
	mread(&x->preLocalTime,4,1,src);
	mread(&x->localTime,4,1,src);
	mread(&x->animeDuration,4,1,src);
	mread(&x->argTaeId,4,1,src);
	mseek(src,136,SEEK_CUR);

	return x;
};
