#pragma once
#include "hkbFootIkGains.h"

hkbFootIkGains* hkbFootIkGains::hkbFootIkGainsRead(MEM* src)
{
	hkbFootIkGains* x = new hkbFootIkGains;

	mread(&x->onOffGain,4,1,src);
	mread(&x->groundAscendingGain,4,1,src);
	mread(&x->groundDescendingGain,4,1,src);
	mread(&x->footPlantedGain,4,1,src);
	mread(&x->footRaisedGain,4,1,src);
	mread(&x->footLockingGain,4,1,src);
	mread(&x->worldFromModelFeedbackGain,4,1,src);
	mread(&x->errorUpDownBias,4,1,src);
	mread(&x->alignWorldFromModelGain,4,1,src);
	mread(&x->hipOrientationGain,4,1,src);

	return x;
};
