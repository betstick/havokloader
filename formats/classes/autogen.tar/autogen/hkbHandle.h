#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbHandle
{
	public:
	hkReferencedObject base;
	unsigned long frame;
	unsigned long rigidBody;
	unsigned long character;
	short animationBoneIndex;

	static hkbHandle* hkbHandleRead(MEM* src);
};
