#pragma once
#include "hkbModifier.h"

hkbModifier* hkbModifier::hkbModifierRead(MEM* src)
{
	hkbModifier* x = new hkbModifier;

	x->base = *hkbNode::hkbNodeRead(src);
	mread(&x->enable,1,1,src);
	mread(&x->padModifier,1,1,src);
	mseek(src,6,SEEK_CUR);
	mseek(src,80,SEEK_CUR);

	return x;
};
