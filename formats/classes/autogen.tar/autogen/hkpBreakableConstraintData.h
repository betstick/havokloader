#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpWrappedConstraintData.h"

class hkpBreakableConstraintData
{
	public:
	hkpWrappedConstraintData base;
	hkpBridgeAtoms atoms;
	unsigned short childRuntimeSize;
	unsigned short childNumSolverResults;
	float solverResultLimit;
	bool removeWhenBroken;
	bool revertBackVelocityOnBreak;

	static hkpBreakableConstraintData* hkpBreakableConstraintDataRead(MEM* src);
};
