#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkcdFourAabb.h"
enum Flags
{
	HAS_INTERNALS = 1,
	HAS_LEAVES = 2,
	HAS_NULLS = 4,
};

class hkcdSimdTreeNode
{
	public:
	hkcdFourAabb base;
	unsigned int data;

	static hkcdSimdTreeNode* hkcdSimdTreeNodeRead(MEM* src);
};
