#pragma once
#include "hkbPoweredRagdollControlsModifier.h"

hkbPoweredRagdollControlsModifier* hkbPoweredRagdollControlsModifier::hkbPoweredRagdollControlsModifierRead(MEM* src)
{
	hkbPoweredRagdollControlsModifier* x = new hkbPoweredRagdollControlsModifier;

	x->base = *hkbModifier::hkbModifierRead(src);
	mread(&x->controlData,sizeof(hkbPoweredRagdollControlData),1,src);
	mread(&x->bones,8,1,src);
	mread(&x->worldFromModelModeData,sizeof(hkbWorldFromModelModeData),1,src);
	mread(&x->boneWeights,8,1,src);
	mread(&x->animationBlendFraction,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,96,SEEK_CUR);

	return x;
};
