#pragma once
#include "hkxBlobMeshShape.h"

hkxBlobMeshShape* hkxBlobMeshShape::hkxBlobMeshShapeRead(MEM* src)
{
	hkxBlobMeshShape* x = new hkxBlobMeshShape;

	x->base = *hkMeshShape::hkMeshShapeRead(src);
	mread(&x->blob,sizeof(hkxBlob),1,src);
	mread(&x->name,8,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
