#pragma once
#include "hkbStateChooserWrapper.h"

hkbStateChooserWrapper* hkbStateChooserWrapper::hkbStateChooserWrapperRead(MEM* src)
{
	hkbStateChooserWrapper* x = new hkbStateChooserWrapper;

	x->base = *hkbCustomIdSelector::hkbCustomIdSelectorRead(src);
	mread(&x->wrappedChooser,8,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
