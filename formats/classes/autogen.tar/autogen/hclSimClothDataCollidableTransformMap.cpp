#pragma once
#include "hclSimClothDataCollidableTransformMap.h"

hclSimClothDataCollidableTransformMap* hclSimClothDataCollidableTransformMap::hclSimClothDataCollidableTransformMapRead(MEM* src)
{
	hclSimClothDataCollidableTransformMap* x = new hclSimClothDataCollidableTransformMap;

	mread(&x->transformSetIndex,4,1,src);
	mseek(src,4,SEEK_CUR);
	mread(&x->transformIndices,4,1,src);
	mseek(src,12,SEEK_CUR);
	mread(&x->offsets,sizeof(TYPE_MATRIX4),1,src);

	return x;
};
