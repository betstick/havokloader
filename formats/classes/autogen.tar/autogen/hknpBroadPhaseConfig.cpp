#pragma once
#include "hknpBroadPhaseConfig.h"

hknpBroadPhaseConfig* hknpBroadPhaseConfig::hknpBroadPhaseConfigRead(MEM* src)
{
	hknpBroadPhaseConfig* x = new hknpBroadPhaseConfig;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mseek(src,16,SEEK_CUR);

	return x;
};
