#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkpShapeCollectionFilter
{
	public:

	static hkpShapeCollectionFilter* hkpShapeCollectionFilterRead(MEM* src);
};
