#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbModifier.h"

class hkbSetWorldFromModelModifier
{
	public:
	hkbModifier base;
	vec4 translation;
	TYPE_QUATERNION rotation;
	bool setTranslation;
	bool setRotation;

	static hkbSetWorldFromModelModifier* hkbSetWorldFromModelModifierRead(MEM* src);
};
