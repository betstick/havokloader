#pragma once
#include "hkcdStaticTreeDynamicStorage4.h"

hkcdStaticTreeDynamicStorage4* hkcdStaticTreeDynamicStorage4::hkcdStaticTreeDynamicStorage4Read(MEM* src)
{
	hkcdStaticTreeDynamicStorage4* x = new hkcdStaticTreeDynamicStorage4;

	x->base = *hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis4::hkcdStaticTreeDynamicStoragehkcdStaticTreeCodec3Axis4Read(src);
	mseek(src,16,SEEK_CUR);

	return x;
};
