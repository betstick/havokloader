#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkMultipleVertexBufferLockedElement
{
	public:
	unsigned char vertexBufferIndex;
	unsigned char elementIndex;
	unsigned char lockedBufferIndex;
	unsigned char vertexFormatIndex;
	unsigned char lockFlags;
	unsigned char outputBufferIndex;
	signed char emulatedIndex;

	static hkMultipleVertexBufferLockedElement* hkMultipleVertexBufferLockedElementRead(MEM* src);
};
