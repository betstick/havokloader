#pragma once
#include "hkaiEdgeGeometryEdge.h"

hkaiEdgeGeometryEdge* hkaiEdgeGeometryEdge::hkaiEdgeGeometryEdgeRead(MEM* src)
{
	hkaiEdgeGeometryEdge* x = new hkaiEdgeGeometryEdge;

	mread(&x->a,4,1,src);
	mread(&x->b,4,1,src);
	mread(&x->face,4,1,src);
	mread(&x->data,4,1,src);

	return x;
};
