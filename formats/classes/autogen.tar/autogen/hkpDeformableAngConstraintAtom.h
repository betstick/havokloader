#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkpConstraintAtom.h"

class hkpDeformableAngConstraintAtom
{
	public:
	hkpConstraintAtom base;
	TYPE_QUATERNION offset;
	vec4 yieldStrengthDiag;
	vec4 yieldStrengthOffDiag;
	vec4 ultimateStrengthDiag;
	vec4 ultimateStrengthOffDiag;

	static hkpDeformableAngConstraintAtom* hkpDeformableAngConstraintAtomRead(MEM* src);
};
