#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hknpVehicleLinearCastWheelCollideWheelState
{
	public:
	hkAabb aabb;
	unsigned long shape;
	TYPE_TRANSFORM transform;
	vec4 to;

	static hknpVehicleLinearCastWheelCollideWheelState* hknpVehicleLinearCastWheelCollideWheelStateRead(MEM* src);
};
