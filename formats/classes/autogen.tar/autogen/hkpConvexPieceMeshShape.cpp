#pragma once
#include "hkpConvexPieceMeshShape.h"

hkpConvexPieceMeshShape* hkpConvexPieceMeshShape::hkpConvexPieceMeshShapeRead(MEM* src)
{
	hkpConvexPieceMeshShape* x = new hkpConvexPieceMeshShape;

	x->base = *hkpShapeCollection::hkpShapeCollectionRead(src);
	mread(&x->convexPieceStream,8,1,src);
	mread(&x->displayMesh,8,1,src);
	mread(&x->radius,4,1,src);
	mseek(src,4,SEEK_CUR);
	mseek(src,48,SEEK_CUR);

	return x;
};
