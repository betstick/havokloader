#pragma once
#include "hkcdStaticMeshTreeBaseSection.h"

hkcdStaticMeshTreeBaseSection* hkcdStaticMeshTreeBaseSection::hkcdStaticMeshTreeBaseSectionRead(MEM* src)
{
	hkcdStaticMeshTreeBaseSection* x = new hkcdStaticMeshTreeBaseSection;

	x->base = *hkcdStaticTreeTreehkcdStaticTreeDynamicStorage4::hkcdStaticTreeTreehkcdStaticTreeDynamicStorage4Read(src);
	mread(&x->codecParms,4,1,src);
	mseek(src,20,SEEK_CUR);
	mread(&x->firstPackedVertex,4,1,src);
	mread(&x->sharedVertices,sizeof(hkcdStaticMeshTreeBaseSectionSharedVertices),1,src);
	mread(&x->primitives,sizeof(hkcdStaticMeshTreeBaseSectionPrimitives),1,src);
	mread(&x->dataRuns,sizeof(hkcdStaticMeshTreeBaseSectionDataRuns),1,src);
	mread(&x->numPackedVertices,1,1,src);
	mread(&x->numSharedIndices,1,1,src);
	mread(&x->leafIndex,2,1,src);
	mread(&x->page,1,1,src);
	mread(&x->flags,1,1,src);
	mread(&x->layerData,1,1,src);
	mread(&x->unusedData,1,1,src);
	mseek(src,48,SEEK_CUR);

	return x;
};
