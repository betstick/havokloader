#pragma once
#include "hkResourceHandle.h"

hkResourceHandle* hkResourceHandle::hkResourceHandleRead(MEM* src)
{
	hkResourceHandle* x = new hkResourceHandle;

	x->base = *hkResourceBase::hkResourceBaseRead(src);
	mseek(src,16,SEEK_CUR);

	return x;
};
