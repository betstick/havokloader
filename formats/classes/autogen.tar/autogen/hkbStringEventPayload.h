#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkbEventPayload.h"

class hkbStringEventPayload
{
	public:
	hkbEventPayload base;
	unsigned long data;

	static hkbStringEventPayload* hkbStringEventPayloadRead(MEM* src);
};
