#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkpCompressedMeshShapeChunk
{
	public:
	vec4 offset;
	unsigned short* vertices;
	unsigned short* indices;
	unsigned short* stripLengths;
	unsigned short* weldingInfo;
	unsigned int materialInfo;
	unsigned short reference;
	unsigned short transformIndex;

	static hkpCompressedMeshShapeChunk* hkpCompressedMeshShapeChunkRead(MEM* src);
};
