#pragma once
#include "hkaiSplitGenerationUtils.h"

hkaiSplitGenerationUtils* hkaiSplitGenerationUtils::hkaiSplitGenerationUtilsRead(MEM* src)
{
	hkaiSplitGenerationUtils* x = new hkaiSplitGenerationUtils;

	mseek(src,1,SEEK_CUR);

	return x;
};
