#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hkReferencedObject.h"

class hkbDetectCloseToGroundModifierInternalState
{
	public:
	hkReferencedObject base;
	bool isCloseToGround;

	static hkbDetectCloseToGroundModifierInternalState* hkbDetectCloseToGroundModifierInternalStateRead(MEM* src);
};
