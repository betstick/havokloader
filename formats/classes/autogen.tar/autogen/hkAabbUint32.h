#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkAabbUint32
{
	public:
	unsigned int min;
	unsigned char expansionMin;
	unsigned char expansionShift;
	unsigned int max;
	unsigned char expansionMax;
	unsigned char shapeKeyByte;

	static hkAabbUint32* hkAabbUint32Read(MEM* src);
};
