#pragma once
#include "hkbEvaluateHandleModifier.h"

hkbEvaluateHandleModifier* hkbEvaluateHandleModifier::hkbEvaluateHandleModifierRead(MEM* src)
{
	hkbEvaluateHandleModifier* x = new hkbEvaluateHandleModifier;

	x->base = *hkbModifier::hkbModifierRead(src);
	mread(&x->handle,8,1,src);
	mread(&x->handlePositionOut,16,1,src);
	mread(&x->handleRotationOut,sizeof(TYPE_QUATERNION),1,src);
	mread(&x->isValidOut,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->extrapolationTimeStep,4,1,src);
	mread(&x->handleChangeSpeed,4,1,src);
	mread(&x->handleChangeMode,1,1,src);
	mseek(src,3,SEEK_CUR);
	mread(&x->oldHandle,sizeof(hkbHandle),1,src);
	mread(&x->oldHandlePosition,16,1,src);
	mread(&x->oldHandleRotation,sizeof(TYPE_QUATERNION),1,src);
	mread(&x->timeSinceLastModify,4,1,src);
	mread(&x->smoothlyChangingHandles,1,1,src);
	mseek(src,11,SEEK_CUR);
	mseek(src,88,SEEK_CUR);

	return x;
};
