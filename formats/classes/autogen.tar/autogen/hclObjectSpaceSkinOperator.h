#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclOperator.h"

class hclObjectSpaceSkinOperator
{
	public:
	hclOperator base;
	TYPE_MATRIX4* boneFromSkinMeshTransforms;
	unsigned short* transformSubset;
	unsigned int outputBufferIndex;
	unsigned int transformSetIndex;
	hclObjectSpaceDeformer objectSpaceDeformer;

	static hclObjectSpaceSkinOperator* hclObjectSpaceSkinOperatorRead(MEM* src);
};
