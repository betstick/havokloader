#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkxEnumItem
{
	public:
	int value;
	unsigned long name;

	static hkxEnumItem* hkxEnumItemRead(MEM* src);
};
