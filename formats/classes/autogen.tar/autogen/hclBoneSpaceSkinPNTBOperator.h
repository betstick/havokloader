#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"
#include "hclBoneSpaceSkinOperator.h"

class hclBoneSpaceSkinPNTBOperator
{
	public:
	hclBoneSpaceSkinOperator base;
	hclBoneSpaceDeformerLocalBlockPNTB* localPNTBs;
	hclBoneSpaceDeformerLocalBlockUnpackedPNTB* localUnpackedPNTBs;

	static hclBoneSpaceSkinPNTBOperator* hclBoneSpaceSkinPNTBOperatorRead(MEM* src);
};
