#pragma once
#include "hclStandardLinkConstraintSet.h"

hclStandardLinkConstraintSet* hclStandardLinkConstraintSet::hclStandardLinkConstraintSetRead(MEM* src)
{
	hclStandardLinkConstraintSet* x = new hclStandardLinkConstraintSet;

	x->base = *hclConstraintSet::hclConstraintSetRead(src);
	mread(&x->links,sizeof(hclStandardLinkConstraintSetLink),1,src);
	mseek(src,32,SEEK_CUR);

	return x;
};
