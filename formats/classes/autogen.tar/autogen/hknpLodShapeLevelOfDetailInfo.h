#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hknpLodShapeLevelOfDetailInfo
{
	public:
	float maxDistance;
	float maxShrink;

	static hknpLodShapeLevelOfDetailInfo* hknpLodShapeLevelOfDetailInfoRead(MEM* src);
};
