#pragma once
#include "hknpPhysicsSceneData.h"

hknpPhysicsSceneData* hknpPhysicsSceneData::hknpPhysicsSceneDataRead(MEM* src)
{
	hknpPhysicsSceneData* x = new hknpPhysicsSceneData;

	x->base = *hkReferencedObject::hkReferencedObjectRead(src);
	mread(&x->systemDatas,8,1,src);
	mseek(src,8,SEEK_CUR);
	mread(&x->worldCinfo,8,1,src);
	mseek(src,16,SEEK_CUR);

	return x;
};
