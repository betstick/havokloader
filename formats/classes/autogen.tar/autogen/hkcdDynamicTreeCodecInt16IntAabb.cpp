#pragma once
#include "hkcdDynamicTreeCodecInt16IntAabb.h"

hkcdDynamicTreeCodecInt16IntAabb* hkcdDynamicTreeCodecInt16IntAabb::hkcdDynamicTreeCodecInt16IntAabbRead(MEM* src)
{
	hkcdDynamicTreeCodecInt16IntAabb* x = new hkcdDynamicTreeCodecInt16IntAabb;

	x->base = *hkAabb16::hkAabb16Read(src);
	mseek(src,16,SEEK_CUR);

	return x;
};
