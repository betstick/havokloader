#pragma once
#include <stdio.h>
#include "cmem.h"
#include "stdafx.h"

class hkcdStaticTreeCodecRaw
{
	public:
	hkAabb aabb;

	static hkcdStaticTreeCodecRaw* hkcdStaticTreeCodecRawRead(MEM* src);
};
